/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx } from 'react/jsx-runtime';
import ImageView from '../../ViewVersionDialog/FieldTypesViews/ImageView';
import DiffViewLayout from './DiffViewLayout';
import Box from '@mui/material/Box';
export function ImageDiffView(props) {
	const { aXml, bXml, field } = props;
	return _jsx(DiffViewLayout, {
		aXml: aXml,
		bXml: bXml,
		field: field,
		renderContent: (xml) =>
			_jsx(Box, {
				sx: { height: 'calc(50% - 9px)', textAlign: 'center' },
				children: _jsx(ImageView, { xml: xml, field: field, sxs: { image: { maxHeight: 'calc(100% - 40px)' } } })
			})
	});
}
export default ImageDiffView;
