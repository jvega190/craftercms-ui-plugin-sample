/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsxs as _jsxs, jsx as _jsx, Fragment as _Fragment } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2026 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import { useMemo, useState } from 'react';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import ListItemText from '@mui/material/ListItemText';
import { buildActionGroups, invokeActionChoice, invokeResolvedAction } from '../dataSources/actionAdapters';
/**
 * Menu items for Forms Engine data-source actions, grouped by intent.
 *
 * Turns a flat {@link ResolvedDataSourceAction} list into the “add / browse / upload / …” menu
 * used by media and item pickers:
 *
 * - **Standard kinds** (`browse`, `search`, `upload`, `create`) are collapsed by
 *   {@link buildActionGroups} into one top-level item per binding property + kind (e.g. a single
 *   “Browse” even when several data sources offer browse).
 * - A group with **one** choice runs immediately via {@link invokeActionChoice}.
 * - A group with **multiple** choices opens a nested submenu so the author picks the concrete
 *   data source / create target.
 * - **Custom** actions (`MenuItem`, `Dialog`, or non-standard `kind`) stay ungrouped: custom
 *   `MenuItem` components render as-is; `Dialog` actions mount their dialog on click; otherwise
 *   {@link invokeResolvedAction} runs.
 *
 * Used by ImagePicker, VideoPicker, TranscodedVideoPicker, RichTextEditor, and NodeSelector
 * (custom actions). Pair with `useFieldDataSources` (or equivalent) for the `actions` /
 * `context` inputs.
 *
 * @example
 * ```tsx
 * <Menu open={open} onClose={() => setOpen(false)}>
 *   <GroupedDataSourceActionMenuItems
 *     actions={dataSources.actions}
 *     context={dataSources.context}
 *     onResult={applySelection}
 *     onError={console.error}
 *     onMenuClose={() => setOpen(false)}
 *   />
 * </Menu>
 * ```
 */
export function GroupedDataSourceActionMenuItems({
	actions,
	context,
	disabled,
	onResult,
	onError,
	onMenuClose,
	autoFocus,
	tabIndex
}) {
	const { groups, customActions } = useMemo(() => buildActionGroups(actions), [actions]);
	const [choiceAnchor, setChoiceAnchor] = useState(null);
	const [choiceGroup, setChoiceGroup] = useState(null);
	const [dialogAction, setDialogAction] = useState(null);
	const focusProps = { autoFocus, tabIndex };
	const closeChoices = () => {
		setChoiceAnchor(null);
		setChoiceGroup(null);
	};
	const handleResult = (selection) => {
		onResult(selection);
		onMenuClose?.();
	};
	const handleError = (error) => {
		onError(error);
		onMenuClose?.();
	};
	const runGroup = (group, event) => {
		if (group.choices.length === 1) {
			invokeActionChoice(group.choices[0], context).then(handleResult).catch(handleError);
		} else {
			setChoiceGroup(group);
			setChoiceAnchor(event.currentTarget);
		}
	};
	const runCustom = (action) => {
		if (action.Dialog) {
			setDialogAction(action);
		} else {
			invokeResolvedAction(action, context).then(handleResult).catch(handleError);
		}
	};
	return _jsxs(_Fragment, {
		children: [
			groups.map((group, index) =>
				_jsxs(
					MenuItem,
					{
						...(index === 0 ? focusProps : undefined),
						disabled: disabled || group.choices.length === 0,
						onClick: (e) => runGroup(group, e),
						children: [group.icon, group.label]
					},
					group.key
				)
			),
			customActions.map((action, index) =>
				action.MenuItem
					? _jsx(
							action.MenuItem,
							{
								...(groups.length === 0 && index === 0 ? focusProps : undefined),
								action: action,
								context: context,
								disabled: disabled,
								onResult: handleResult,
								onError: handleError
							},
							action.actionKey
						)
					: _jsxs(
							MenuItem,
							{
								...(groups.length === 0 && index === 0 ? focusProps : undefined),
								disabled: disabled,
								onClick: () => runCustom(action),
								children: [action.icon, action.label]
							},
							action.actionKey
						)
			),
			_jsx(Menu, {
				anchorEl: choiceAnchor,
				open: Boolean(choiceAnchor),
				onClose: closeChoices,
				children: choiceGroup?.choices.map((choice) =>
					_jsx(
						MenuItem,
						{
							disabled: disabled,
							onClick: () => {
								closeChoices();
								invokeActionChoice(choice, context).then(handleResult).catch(handleError);
							},
							children: _jsx(ListItemText, { primary: choice.label, secondary: choice.description })
						},
						choice.key
					)
				)
			}),
			dialogAction?.Dialog &&
				_jsx(dialogAction.Dialog, {
					action: dialogAction,
					context: context,
					disabled: disabled,
					onResult: (selection) => {
						handleResult(selection);
						setDialogAction(null);
					},
					onError: (error) => {
						handleError(error);
						setDialogAction(null);
					}
				})
		]
	});
}
export default GroupedDataSourceActionMenuItems;
