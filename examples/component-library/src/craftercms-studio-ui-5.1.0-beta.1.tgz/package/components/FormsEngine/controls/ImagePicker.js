/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2024 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import { useEffect, useState } from 'react';
import Box from '@mui/material/Box';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';
import CardMedia from '@mui/material/CardMedia';
import IconButton from '@mui/material/IconButton';
import { DeleteOutlined, DownloadOutlined, EditOutlined } from '@mui/icons-material';
import { FormsEngineField } from '../components/FormsEngineField';
import useEnv from '../../../hooks/useEnv';
import { FormattedMessage, useIntl } from 'react-intl';
import { menuItemClasses } from '@mui/material/MenuItem';
import { listItemIconClasses } from '@mui/material/ListItemIcon';
import Menu from '@mui/material/Menu';
import { useImageInfo } from '../../../hooks/useImageInfo';
import { svgIconClasses } from '@mui/material/SvgIcon';
import { ensureSingleSlash } from '../../../utils/string';
import { useDispatch } from 'react-redux';
import Tooltip from '@mui/material/Tooltip';
import { downloadMedia, getImageRestrictionMessages, showImageCropDialog } from '../lib/controlHelpers';
import Skeleton from '@mui/material/Skeleton';
import { nnou, nou } from '../../../utils/object';
import { validateImageRestrictions } from '../../../utils/content';
import GroupedDataSourceActionMenuItems from '../components/GroupedDataSourceActionMenuItems';
import { showSystemNotification } from '../../../state/actions/system';
import { EmptyState } from '../../EmptyState';
export function ImagePicker(props) {
	const { field, value: valueProp, setValue, autoFocus, readonly: formReadonly, dataSources } = props;
	const { guestBase } = useEnv();
	const { formatMessage } = useIntl();
	const dispatch = useDispatch();
	// region field properties/validations
	const readonly = formReadonly || field.properties?.readonly?.value;
	const defaultValue = field.defaultValue;
	const restrictions = {
		height: field.validations?.height?.value,
		width: field.validations?.width?.value,
		maxHeight: field.validations?.maxHeight?.value,
		maxWidth: field.validations?.maxWidth?.value,
		minHeight: field.validations?.minHeight?.value,
		minWidth: field.validations?.minWidth?.value
	};
	// endregion
	const value = nnou(valueProp) ? valueProp : (defaultValue ?? '');
	const { imageInfo, isFetchingDimensions, isFetchingMetadata, errorDimensions, errorMetadata } = useImageInfo(
		value ? ensureSingleSlash(`${guestBase}${value}`) : ''
	);
	const hasValue = Boolean(value);
	const actions = dataSources?.actions ?? [];
	const dataSourcesLoading = dataSources?.status === 'loading';
	const dataSourcesError = dataSources?.status === 'error';
	const actionsReady = Boolean(dataSources?.context) && actions.length > 0 && !dataSourcesLoading;
	const [anchorEl, setAnchorEl] = useState(null);
	const [addMenuOpen, setAddMenuOpen] = useState(false);
	useEffect(() => {
		// If there's a default value and no value has been set yet, set it as the value.
		if (nou(valueProp) && defaultValue != null) {
			setValue(defaultValue);
		}
	}, [defaultValue, setValue, valueProp]);
	const imageRestrictionMessages = getImageRestrictionMessages(restrictions);
	const applySelection = (selection) => {
		const selected = Array.isArray(selection) ? selection[0] : selection;
		const path =
			selected?.kind === 'asset' && typeof selected.relativeUrl === 'string'
				? selected.relativeUrl
				: selected?.kind === 'item' && typeof selected.path === 'string'
					? selected.path
					: undefined;
		if (!path) return;
		validateImageRestrictions(path, restrictions)
			.then((meetsRestrictions) => {
				if (!meetsRestrictions) {
					showImageCropDialog({
						dispatch,
						path,
						mimeType:
							selected.kind === 'asset' && typeof selected.mimeType === 'string' ? selected.mimeType : undefined,
						restrictions,
						writeContent: true,
						onCrop: (_blob, newPath) => setValue(newPath ?? path)
					});
				} else {
					setValue(path);
				}
			})
			.catch(() => {
				dispatch(
					showSystemNotification({
						message: formatMessage({ defaultMessage: 'Unable to validate image restrictions.' })
					})
				);
			});
	};
	const actionMenuItems = actionsReady
		? _jsx(GroupedDataSourceActionMenuItems, {
				actions: actions,
				context: dataSources.context,
				disabled: readonly,
				onResult: applySelection,
				onError: console.error,
				onMenuClose: () => setAddMenuOpen(false)
			})
		: null;
	const handleRemoveImage = () => {
		setValue(null);
	};
	return _jsxs(_Fragment, {
		children: [
			_jsx(Menu, {
				anchorEl: anchorEl,
				open: addMenuOpen,
				onClose: () => setAddMenuOpen(false),
				sx: {
					[`.${menuItemClasses.root}`]: { pl: 3 }
				},
				children: actionMenuItems
			}),
			_jsx(FormsEngineField, {
				field: field,
				children: hasValue
					? _jsxs(Card, {
							sx: { display: 'flex' },
							children: [
								_jsx(CardMedia, {
									component: 'img',
									sx: { width: '40%' },
									image: `${guestBase}${value}`,
									alt: 'Live from space album cover'
								}),
								_jsx(Box, {
									sx: { display: 'flex', flexDirection: 'column' },
									children: _jsxs(CardContent, {
										sx: { flex: '1 0 auto' },
										children: [
											_jsx(Typography, { component: 'div', variant: 'body1', marginBottom: 1, children: value }),
											_jsxs(Typography, {
												variant: 'body2',
												component: 'div',
												color: 'textSecondary',
												marginBottom: 1,
												children: [
													isFetchingMetadata
														? _jsxs(_Fragment, {
																children: [_jsx(Skeleton, { variant: 'text' }), _jsx(Skeleton, { variant: 'text' })]
															})
														: errorMetadata
															? _jsx(Typography, {
																	color: 'error',
																	variant: 'body2',
																	children: _jsx(FormattedMessage, { defaultMessage: 'Error loading image metadata' })
																})
															: _jsxs(_Fragment, {
																	children: [
																		imageInfo?.contentType,
																		_jsx('br', {}),
																		imageInfo?.size ? `${imageInfo.size} Kb` : '',
																		_jsx('br', {})
																	]
																}),
													isFetchingDimensions
														? _jsx(Skeleton, { variant: 'text' })
														: errorDimensions
															? _jsx(Typography, {
																	color: 'error',
																	variant: 'body2',
																	children: _jsx(FormattedMessage, { defaultMessage: 'Error loading image dimensions' })
																})
															: `${imageInfo?.width} x ${imageInfo?.height}`
												]
											}),
											Object.values(restrictions).some((restriction) => restriction) &&
												_jsxs(_Fragment, {
													children: [
														_jsx(Typography, {
															variant: 'caption',
															fontWeight: 'bold',
															children: _jsx(FormattedMessage, { defaultMessage: 'Image Requirements:' })
														}),
														_jsxs(Typography, {
															variant: 'caption',
															component: 'div',
															color: 'textSecondary',
															marginBottom: 1,
															children: [
																_jsx(FormattedMessage, { defaultMessage: 'Width: ' }),
																imageRestrictionMessages.width,
																_jsx('br', {}),
																_jsx(FormattedMessage, { defaultMessage: 'Height:' }),
																imageRestrictionMessages.height
															]
														})
													]
												}),
											_jsxs(Box, {
												children: [
													_jsx(Tooltip, {
														title: _jsx(FormattedMessage, { defaultMessage: 'Replace' }),
														children: _jsx(IconButton, {
															size: 'small',
															disabled: readonly || !actionsReady,
															autoFocus: autoFocus,
															onClick: (event) => {
																if (actionsReady) {
																	setAnchorEl(event.currentTarget);
																	setAddMenuOpen(true);
																}
															},
															children: _jsx(EditOutlined, {})
														})
													}),
													_jsx(Tooltip, {
														title: _jsx(FormattedMessage, { defaultMessage: 'Download' }),
														children: _jsx(IconButton, {
															size: 'small',
															onClick: () => {
																if (value) downloadMedia(guestBase, value);
															},
															children: _jsx(DownloadOutlined, {})
														})
													}),
													_jsx(Tooltip, {
														title: _jsx(FormattedMessage, { defaultMessage: 'Delete' }),
														children: _jsx(IconButton, {
															size: 'small',
															onClick: handleRemoveImage,
															disabled: readonly,
															children: _jsx(DeleteOutlined, {})
														})
													})
												]
											})
										]
									})
								})
							]
						})
					: dataSourcesLoading
						? _jsx(Skeleton, { variant: 'rounded', height: 56 })
						: dataSourcesError
							? _jsx(Typography, {
									color: 'error',
									variant: 'body2',
									children: _jsx(FormattedMessage, { defaultMessage: 'Error loading image sources' })
								})
							: !actionsReady
								? _jsx(EmptyState, {
										title: _jsx(FormattedMessage, { defaultMessage: 'No options are available for this control' }),
										subtitle: _jsx(FormattedMessage, {
											defaultMessage: 'Update the content type definition to add options to this control'
										})
									})
								: _jsx(Box, {
										sx: {
											p: 1,
											gap: 1,
											py: 0.5,
											display: 'flex',
											flexDirection: 'row',
											flexWrap: 'wrap',
											color: 'primary.main',
											justifyContent: 'center',
											[`.${svgIconClasses.root}`]: {
												color: 'primary.main'
											},
											[`.${menuItemClasses.root}`]: {
												flexDirection: 'column',
												justifyContent: 'center',
												borderRadius: 1
											},
											[`.${listItemIconClasses.root}`]: {
												justifyContent: 'center'
											}
										},
										children: actionMenuItems
									})
			})
		]
	});
}
export default ImagePicker;
