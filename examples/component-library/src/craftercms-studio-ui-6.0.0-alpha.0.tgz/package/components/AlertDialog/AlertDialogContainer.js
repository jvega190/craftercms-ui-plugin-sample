/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { Fragment as _Fragment, jsx as _jsx, jsxs as _jsxs } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2023 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import * as React from 'react';
import questionGraphicUrl from '../../assets/question.svg';
import useUnmount from '../../hooks/useUnmount';
import DialogContent from '@mui/material/DialogContent';
import Typography from '@mui/material/Typography';
import DialogContentText from '@mui/material/DialogContentText';
import Box from '@mui/material/Box';
import { DialogFooter } from '../DialogFooter';
import { nnou } from '../../utils/object';
export function AlertDialogContainer(props) {
	const { onClosed, body, title, children, imageUrl = questionGraphicUrl, buttons, sxs } = props;
	const fallbackId = React.useId();
	const {
		titleId = `${fallbackId}-title`,
		bodyId = `${fallbackId}-body`,
		bodyTextId = `${fallbackId}-body-text`
	} = props;
	useUnmount(onClosed);
	return _jsxs(_Fragment, {
		children: [
			_jsxs(DialogContent, {
				id: bodyId,
				sx: {
					textAlign: 'center',
					padding: '40px 20px 25px !important',
					...sxs?.body
				},
				children: [
					imageUrl &&
						_jsx(Box, {
							component: 'img',
							src: imageUrl,
							alt: '',
							sx: {
								margin: 'auto',
								display: 'block',
								paddingBottom: '35px',
								...sxs?.image
							}
						}),
					title &&
						_jsx(Typography, {
							id: titleId,
							variant: 'body1',
							component: 'h2',
							sx: {
								paddingBottom: '5px',
								...sxs?.title
							},
							children: title
						}),
					body && _jsx(DialogContentText, { id: bodyTextId, color: 'textPrimary', variant: 'body2', children: body }),
					children
				]
			}),
			nnou(buttons) &&
				_jsx(DialogFooter, {
					sx: {
						borderTop: 'none',
						display: 'flex',
						flexDirection: 'column',
						padding: '0 40px 35px',
						backgroundColor: null,
						'& > :not(:first-child)': {
							marginTop: '10px',
							marginLeft: 0
						},
						...sxs?.footer
					},
					children: buttons
				})
		]
	});
}
export default AlertDialogContainer;
