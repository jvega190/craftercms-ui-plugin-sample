/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { Fragment as _Fragment, jsx as _jsx, jsxs as _jsxs } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import DialogContentText from '@mui/material/DialogContentText';
import { defineMessages, FormattedMessage, useIntl } from 'react-intl';
import DialogContent from '@mui/material/DialogContent';
import TextField from '@mui/material/TextField';
import DialogActions from '@mui/material/DialogActions';
import Button from '@mui/material/Button';
import { useEffect, useRef, useState } from 'react';
import { useDispatch } from 'react-redux';
import { login, loginComplete, logout, sharedWorkerExtendSession } from '../../state/actions/auth';
import { messageSharedWorker } from '../../state/actions/system';
import loginGraphicUrl from '../../assets/authenticate.svg';
import { isBlank } from '../../utils/string';
import Typography from '@mui/material/Typography';
import OpenInNewRounded from '@mui/icons-material/OpenInNewRounded';
import LogInForm from '../LoginForm';
import { me } from '../../services/users';
import ApiResponseErrorState from '../ApiResponseErrorState';
import ErrorState from '../ErrorState/ErrorState';
import { useSelection } from '../../hooks/useSelection';
import Box from '@mui/material/Box';
import { INCORRECT_CREDENTIALS_ERROR_CODE } from '../../state/reducers/auth';
import { SESSION_TIMEOUT_WARNING_MS } from '../../utils/constants';
import { useSessionTimeoutWarning } from '../../hooks/useSessionTimeoutWarning';
import { getXSRFToken } from '../../utils/auth';
import CredentialsErrorBanner from '../CredentialsErrorBanner/CredentialsErrorBanner';
const authMonitorCredentialsErrorId = 'authMonitorCredentialsError';
const translations = defineMessages({
	sessionExpired: {
		id: 'authMonitor.sessionExpiredMessage',
		defaultMessage: 'Your session has expired. Please log back in.'
	},
	incorrectPasswordMessage: {
		id: 'authMonitor.incorrectPasswordMessage',
		defaultMessage: 'Incorrect username or password. Please try again.'
	},
	postSSOLoginMismatch: {
		id: 'authMonitor.postSSOLoginMismatchMessage',
		defaultMessage:
			"Looks like you've logged in with a user different from the owner of this session. For security reasons, your screen will now be refreshed."
	}
});
export function AuthMonitor() {
	const dispatch = useDispatch();
	const { formatMessage } = useIntl();
	const { username, authenticationType } = useSelection((state) => state.user) ?? {
		username: '',
		authenticationType: 'db'
	};
	const { authoringBase, logoutUrl } = useSelection((state) => state.env);
	const { active } = useSelection((state) => state.auth);
	const isSSO = authenticationType === 'saml' || authenticationType === 'auth_headers';
	const firstRender = useRef(true);
	useEffect(() => {
		// On regular login dialog, the username is locked to the user whose session expired; on the
		// SSO form however, users can enter any username/password. So this check ensures that if a
		// different user logs in after timeout, he won't be working on top of the previous user's work/session.
		if (firstRender.current) {
			firstRender.current = false;
		} else if (active) {
			// Move this call to the next tick to avoid it getting dispatched
			// before the epics set the new JWT header.
			setTimeout(() => {
				me().subscribe((user) => {
					if (user.username !== username) {
						alert(formatMessage(translations.postSSOLoginMismatch));
						window.location.reload();
					}
				});
			}, 0);
		}
	}, [active, dispatch, formatMessage, username]);
	return _jsxs(_Fragment, {
		children: [
			_jsx(SessionTimeoutWarning, {}),
			_jsx(Dialog, {
				open: !active,
				id: 'authMonitorDialog',
				'aria-labelledby': 'craftercmsReLoginDialog',
				children: _jsx(AuthMonitorBody, {
					isSSO: isSSO,
					username: username,
					logoutUrl: logoutUrl,
					authoringUrl: authoringBase,
					dispatch: dispatch,
					formatMessage: formatMessage
				})
			})
		]
	});
}
// WCAG 2.1 SC 2.2.1 Timing Adjustable: warns before the session expires and lets the user extend it. The number of
// extensions is limited (server side), so the last warning only tells the user to save their work.
function SessionTimeoutWarning() {
	const dispatch = useDispatch();
	const { active, sessionExpiresAt, canExtendSession } = useSelection((state) => state.auth);
	const { visible, secondsLeft, dismiss } = useSessionTimeoutWarning(
		active,
		sessionExpiresAt,
		SESSION_TIMEOUT_WARNING_MS
	);
	// The extension requested by the user, for the session expiry and extension cap in effect at that moment. Only a new
	// session expiry (or the cap being reached) means the extend landed, so a routine token refresh that lands first
	// must not re-enable the button. The timeout below covers a failed request.
	const [extendRequest, setExtendRequest] = useState(null);
	const currentRequest =
		extendRequest?.sessionExpiresAt === sessionExpiresAt && extendRequest?.canExtendSession === canExtendSession
			? extendRequest
			: null;
	const extending = currentRequest != null && !currentRequest.failed;
	const extendFailed = currentRequest?.failed === true;
	useEffect(() => {
		if (extending) {
			const timeout = setTimeout(() => {
				setExtendRequest((request) => request && { ...request, failed: true });
			}, 10000);
			return () => clearTimeout(timeout);
		}
	}, [extending]);
	const onStaySignedIn = () => {
		if (!extending) {
			setExtendRequest({ sessionExpiresAt, canExtendSession, failed: false });
			dispatch(messageSharedWorker(sharedWorkerExtendSession({ xsrfToken: getXSRFToken() })));
		}
	};
	return _jsxs(
		Dialog,
		// Remounts when the user runs out of extensions so the new warning is announced.
		{
			open: visible,
			// Escape or clicking outside keeps the user working rather than leaving them with a dismissed warning.
			onClose: canExtendSession ? onStaySignedIn : dismiss,
			role: 'alertdialog',
			'aria-labelledby': 'sessionTimeoutWarningTitle',
			'aria-describedby': 'sessionTimeoutWarningMessage',
			children: [
				_jsx(DialogTitle, {
					id: 'sessionTimeoutWarningTitle',
					children: _jsx(FormattedMessage, {
						id: 'authMonitor.sessionExpiringTitle',
						defaultMessage: 'Your session is about to expire'
					})
				}),
				_jsxs(DialogContent, {
					sx: { width: '400px' },
					children: [
						_jsx(DialogContentText, {
							id: 'sessionTimeoutWarningMessage',
							children: canExtendSession
								? _jsx(FormattedMessage, {
										id: 'authMonitor.sessionExpiringMessage',
										defaultMessage:
											'For your security, your session will expire in {seconds, plural, one {# second} other {# seconds}}. Select Stay signed in to keep working.',
										values: { seconds: secondsLeft }
									})
								: _jsx(FormattedMessage, {
										id: 'authMonitor.sessionExpiringFinalMessage',
										defaultMessage:
											"For your security, your session will expire in {seconds, plural, one {# second} other {# seconds}} and it can't be extended any more. Close this message and save your work, then log in again.",
										values: { seconds: secondsLeft }
									})
						}),
						_jsx(Typography, {
							variant: 'body2',
							role: 'status',
							children:
								extending &&
								_jsx(FormattedMessage, {
									id: 'authMonitor.sessionExtendingMessage',
									defaultMessage: 'Extending your session\u2026'
								})
						}),
						extendFailed &&
							_jsx(Typography, {
								variant: 'body2',
								role: 'alert',
								sx: { marginTop: (theme) => theme.spacing(1) },
								children: _jsx(FormattedMessage, {
									id: 'authMonitor.sessionExtendFailedMessage',
									defaultMessage: 'Your session could not be extended. Select Stay signed in to try again.'
								})
							})
					]
				}),
				_jsxs(DialogActions, {
					children: [
						_jsx(Button, {
							color: 'primary',
							variant: 'text',
							onClick: () => dispatch(logout()),
							children: _jsx(FormattedMessage, { id: 'authMonitor.logOutButtonLabel', defaultMessage: 'Log Out' })
						}),
						canExtendSession
							? _jsx(Button, {
									autoFocus: true,
									color: 'primary',
									variant: 'contained',
									'aria-disabled': extending,
									onClick: onStaySignedIn,
									children: _jsx(FormattedMessage, {
										id: 'authMonitor.staySignedInButtonLabel',
										defaultMessage: 'Stay signed in'
									})
								})
							: _jsx(Button, {
									autoFocus: true,
									color: 'primary',
									variant: 'contained',
									onClick: dismiss,
									children: _jsx(FormattedMessage, { id: 'words.close', defaultMessage: 'Close' })
								})
					]
				})
			]
		},
		canExtendSession ? 'extendable' : 'final'
	);
}
function AuthMonitorBody(props) {
	const { authoringUrl, username, isSSO, dispatch, formatMessage } = props;
	const { error, isFetching } = useSelection((state) => state.auth);
	const credentialsError = error?.code === INCORRECT_CREDENTIALS_ERROR_CODE;
	const [password, setPassword] = useState('');
	const [ssoButtonClicked, setSSOButtonClicked] = useState(false);
	const styles = isFetching ? { visibility: 'hidden' } : {};
	const onSubmit = (e) => {
		e.preventDefault();
		e.stopPropagation();
		if (isSSO) {
			dispatch(loginComplete());
			setSSOButtonClicked(false);
		} else {
			!isBlank(password) && dispatch(login({ username, password }));
		}
	};
	const onClose = () => dispatch(logout());
	return _jsxs(_Fragment, {
		children: [
			_jsx(DialogTitle, {
				id: 'craftercmsReLoginDialog',
				sx: { textAlign: 'center' },
				style: styles,
				children: _jsx(FormattedMessage, { id: 'authMonitor.dialogTitleText', defaultMessage: 'Session Expired' })
			}),
			_jsx(DialogContent, {
				sx: { width: '400px' },
				children: _jsxs(_Fragment, {
					children: [
						error
							? credentialsError
								? _jsx(CredentialsErrorBanner, {
										id: authMonitorCredentialsErrorId,
										sx: { marginBottom: (theme) => theme.spacing(2) },
										children: formatMessage(translations.incorrectPasswordMessage)
									})
								: _jsx(ApiResponseErrorState, { error: error, sxs: { image: { width: 150 } } })
							: _jsx(ErrorState, {
									imageUrl: loginGraphicUrl,
									sxs: { image: { width: 150 } },
									message: formatMessage(translations.sessionExpired)
								}),
						isSSO
							? _jsx(SSOForm, {
									authoringUrl: authoringUrl,
									username: username,
									onSubmit: onSubmit,
									ssoButtonClicked: ssoButtonClicked,
									onSetSSOButtonClicked: setSSOButtonClicked
								})
							: _jsx(LogInForm, {
									username: username,
									isFetching: isFetching,
									onSubmit: onSubmit,
									password: password,
									onSetPassword: setPassword,
									invalidCredentials: credentialsError,
									credentialsErrorId: authMonitorCredentialsErrorId
								})
					]
				})
			}),
			_jsxs(DialogActions, {
				sx: { placeContent: 'center space-between' },
				style: styles,
				children: [
					isSSO &&
						_jsx(Button, {
							fullWidth: true,
							type: 'button',
							color: 'primary',
							onClick: onSubmit,
							disabled: isFetching,
							variant: 'contained',
							children: _jsx(FormattedMessage, {
								id: 'authMonitor.validateSessionButtonLabel',
								defaultMessage: 'Resume'
							})
						}),
					_jsx(Button, {
						fullWidth: true,
						type: 'button',
						color: 'primary',
						onClick: onClose,
						disabled: isFetching,
						variant: 'text',
						children: _jsx(FormattedMessage, { id: 'authMonitor.logOutButtonLabel', defaultMessage: 'Log Out' })
					})
				]
			})
		]
	});
}
function SSOForm(props) {
	const { username, onSubmit, authoringUrl, ssoButtonClicked, onSetSSOButtonClicked, classes, sxs } = props;
	const onOpenLogin = () => {
		window.open(`${authoringUrl}/login/resume`, '_blank', 'toolbar=0,location=0,menubar=0,dependent=true');
		onSetSSOButtonClicked(true);
	};
	return _jsxs('form', {
		onSubmit: onSubmit,
		children: [
			_jsx(TextField, {
				fullWidth: true,
				disabled: true,
				type: 'email',
				value: username,
				className: classes?.input,
				sx: sxs?.input,
				label: _jsx(FormattedMessage, { id: 'authMonitor.usernameTextFieldLabel', defaultMessage: 'Username' })
			}),
			_jsxs(Box, {
				component: 'section',
				className: classes?.ssoAction,
				sx: {
					textAlign: 'center',
					display: 'flex',
					flexDirection: 'column',
					marginTop: (theme) => theme.spacing(1),
					...sxs?.ssoAction
				},
				children: [
					_jsx(Button, {
						type: 'button',
						color: 'primary',
						variant: ssoButtonClicked ? 'outlined' : 'contained',
						onClick: onOpenLogin,
						endIcon: _jsx(OpenInNewRounded, {}),
						children: _jsx(FormattedMessage, {
							id: 'authMonitor.openSSOLoginButtonLabel',
							defaultMessage: 'Open Login Form'
						})
					}),
					_jsx(Typography, {
						variant: 'caption',
						children: _jsx(FormattedMessage, {
							id: 'authMonitor.ssoOpenPopupMessage',
							defaultMessage:
								'Make sure pop ups are not blocked. Once you log in, come back to ' +
								'this window and click on `Resume` button below.'
						})
					})
				]
			})
		]
	});
}
export default AuthMonitor;
