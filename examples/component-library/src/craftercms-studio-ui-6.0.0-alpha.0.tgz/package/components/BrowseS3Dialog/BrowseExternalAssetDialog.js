/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { Fragment as _Fragment, jsx as _jsx, jsxs as _jsxs } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2026 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { EnhancedDialog } from '../EnhancedDialog';
import { FormattedMessage, useIntl } from 'react-intl';
import useActiveSiteId from '../../hooks/useActiveSiteId';
import { list as listAws } from '../../services/aws';
import { list as listWebdav } from '../../services/webdav';
import { parseExternalItemToMediaItem } from './utils';
import { DialogBody } from '../DialogBody';
import Box from '@mui/material/Box';
import MediaCard from '../MediaCard';
import { EmptyState } from '../EmptyState';
import { DialogFooter } from '../DialogFooter';
import SecondaryButton from '../SecondaryButton';
import PrimaryButton from '../PrimaryButton';
import Paper from '@mui/material/Paper';
import Toolbar from '@mui/material/Toolbar';
import IconButton from '@mui/material/IconButton';
import RefreshIcon from '@mui/icons-material/Refresh';
import Tooltip from '@mui/material/Tooltip';
import Divider from '@mui/material/Divider';
import SearchBar from '../SearchBar';
import ListViewIcon from '@mui/icons-material/ViewStreamRounded';
import ReorderRoundedIcon from '@mui/icons-material/ReorderRounded';
import GridViewIcon from '@mui/icons-material/GridOnRounded';
import { getStoredBrowseDialogViewMode, setStoredBrowseDialogViewMode } from '../../utils/state';
import useActiveUser from '../../hooks/useActiveUser';
import { MEDIA_CARD_GRID_TEMPLATE_COLUMNS, viewModes } from '../BrowseFilesDialog';
import { SimpleTreeView } from '@mui/x-tree-view';
import { TreeItem } from '@mui/x-tree-view/TreeItem';
import { cancelTreeItemKey, isOwnTreeItemEvent } from '../../utils/treeKeyboard';
import BrowseFilesDialogContainerSkeleton from '../BrowseFilesDialog/BrowseFilesDialogContainerSkeleton';
import Checkbox from '@mui/material/Checkbox';
import useEnv from '../../hooks/useEnv';
import useUpdateRefs from '../../hooks/useUpdateRefs';
import { getFocusRingSx } from '../../styles/focusRing';
function BrowseExternalAssetDialogBody(props) {
	const { path, profileId, multiSelect, preselectedPaths = [], profileType = 'aws', type, onClose, onSuccess } = props;
	const [isFetchingItems, setIsFetchingItems] = useState(false);
	const [error, setError] = useState(null);
	const [items, setItems] = useState();
	const [foldersByPath, setFoldersByPath] = useState({});
	const [selectedCard, setSelectedCard] = useState();
	const [selectedLookup, setSelectedLookup] = useState({});
	const selectedArray = Object.keys(selectedLookup).filter((key) => selectedLookup[key]);
	const allItemsSelected = items?.length && items.every((item) => selectedLookup[item.path]);
	const someItemsSelected = items?.length && items.some((item) => selectedLookup[item.path]) && !allItemsSelected;
	const siteId = useActiveSiteId();
	const { formatMessage } = useIntl();
	const { username } = useActiveUser();
	const [keyword, setKeyword] = useState('');
	const [viewMode, setViewMode] = useState(getStoredBrowseDialogViewMode(username) ?? viewModes[0]);
	const filteredItems = items?.filter((item) => item.name.toLowerCase().includes(keyword.toLowerCase()));
	const [currentPath, setCurrentPath] = useState(path);
	const disableSubmit = isFetchingItems || (!selectedArray.length && !selectedCard);
	const { guestBase } = useEnv();
	const requestSeq = useRef(0);
	const currentSub = useRef(null);
	const fetchItems = useCallback(
		(path, profileId) => {
			const fetchService = profileType === 'aws' ? listAws : listWebdav;
			requestSeq.current += 1;
			const seq = requestSeq.current;
			currentSub.current?.unsubscribe?.();
			setIsFetchingItems(true);
			currentSub.current = fetchService(siteId, profileId, {
				path,
				type
			}).subscribe({
				next: (items) => {
					if (seq !== requestSeq.current) return;
					setIsFetchingItems(false);
					const folders = [];
					const files = [];
					items.forEach((item) => {
						if (item.folder) {
							folders.push(parseExternalItemToMediaItem(item));
						} else {
							files.push(parseExternalItemToMediaItem(item));
						}
					});
					setItems(files);
					if (multiSelect) {
						setSelectedLookup((prev) => {
							const next = { ...prev };
							files.forEach((file) => {
								if (preselectedPaths.includes(file.path) && !(file.path in next)) {
									next[file.path] = file;
								}
							});
							return next;
						});
					} else {
						const preSelectedFile = files.find((file) => preselectedPaths.includes(file.path));
						if (preSelectedFile) {
							setSelectedCard(preSelectedFile);
						}
					}
					setFoldersByPath((prev) => ({ ...prev, [path]: folders }));
				},
				error: (error) => {
					if (seq !== requestSeq.current) return;
					setIsFetchingItems(false);
					setItems([]);
					setError(error);
				}
			});
		},
		[siteId, setSelectedLookup, setSelectedCard, multiSelect, preselectedPaths, profileType, type]
	);
	const fnRefs = useUpdateRefs({ fetchItems });
	useEffect(() => {
		fnRefs.current.fetchItems(path, profileId);
	}, [profileId, path, fnRefs]);
	const onCardSelected = (item) => {
		if (multiSelect) {
			setSelectedLookup((prev) => {
				const isSelected = !!prev[item.path];
				const updated = { ...prev };
				if (isSelected) {
					delete updated[item.path];
				} else {
					updated[item.path] = item;
				}
				return updated;
			});
		} else {
			setSelectedCard(selectedCard?.path === item.path ? null : item);
		}
	};
	const onSelectAll = () => {
		if (multiSelect) {
			const newSelectedLookup = { ...selectedLookup };
			items.forEach((item) => {
				newSelectedLookup[item.path] = allItemsSelected ? null : item;
			});
			setSelectedLookup(newSelectedLookup);
		}
	};
	function handleSearchKeyword(keyword) {
		setKeyword(keyword);
	}
	const onCloseButtonClick = (e) => onClose(e, null);
	const onRefresh = () => fetchItems(currentPath, profileId);
	const switchViewMode = () => {
		const currentIndex = viewModes.indexOf(viewMode);
		let nextIndex;
		if (currentIndex === viewModes.length - 1) {
			nextIndex = 0;
		} else {
			nextIndex = currentIndex + 1;
		}
		setStoredBrowseDialogViewMode(username, viewModes[nextIndex]);
		setViewMode(viewModes[nextIndex]);
	};
	const onSelectButtonClick = () => {
		onSuccess?.(multiSelect ? Object.values(selectedLookup).filter(Boolean) : selectedCard);
	};
	return _jsxs(_Fragment, {
		children: [
			_jsx(DialogBody, {
				sx: { padding: 0 },
				children: _jsxs(Box, {
					sx: { display: 'flex', overflow: 'hidden', minHeight: '60vh' },
					children: [
						_jsx(Box, {
							sx: {
								width: '270px',
								minWidth: '270px',
								padding: '16px',
								overflow: 'auto',
								rowGap: (theme) => theme.spacing(1)
							},
							children: _jsx(SimpleTreeView, {
								'aria-label': formatMessage({ defaultMessage: 'Folders' }),
								disableSelection: true,
								children: _jsx(ExternalAssetFoldersTreeView, {
									foldersByPath: foldersByPath,
									path: path,
									currentPath: currentPath,
									onFolderClick: (e, folderPath) => {
										e.stopPropagation();
										setCurrentPath(folderPath);
										fetchItems(folderPath, profileId);
									}
								})
							})
						}),
						isFetchingItems
							? _jsx(BrowseFilesDialogContainerSkeleton, {})
							: _jsx(Box, {
									component: 'section',
									sx: { display: 'flex', flexDirection: 'column', flexGrow: 1, padding: '16px', overflow: 'auto' },
									children: _jsxs(_Fragment, {
										children: [
											_jsx(Paper, {
												sx: {
													paddingLeft: (theme) => theme.spacing(1),
													marginBottom: (theme) => theme.spacing(3),
													borderRadius: 4
												},
												children: _jsxs(Toolbar, {
													disableGutters: true,
													variant: 'dense',
													children: [
														_jsxs(Box, {
															sx: { flexGrow: 1, display: 'flex' },
															children: [
																multiSelect &&
																	_jsxs(_Fragment, {
																		children: [
																			_jsx(Tooltip, {
																				title: _jsx(FormattedMessage, { defaultMessage: 'Select All on this page' }),
																				children: _jsx(Checkbox, {
																					checked: allItemsSelected,
																					indeterminate: someItemsSelected,
																					onChange: onSelectAll,
																					slotProps: {
																						input: { 'aria-label': formatMessage({ defaultMessage: 'Select all' }) }
																					}
																				})
																			}),
																			_jsx(Divider, {
																				orientation: 'vertical',
																				flexItem: true,
																				sx: { marginTop: '-3px', marginBottom: '-3px' }
																			})
																		]
																	}),
																_jsx(Tooltip, {
																	title: formatMessage({ id: 'word.refresh', defaultMessage: 'Refresh' }),
																	children: _jsx(IconButton, {
																		onClick: onRefresh,
																		'aria-label': formatMessage({ id: 'word.refresh', defaultMessage: 'Refresh' }),
																		children: _jsx(RefreshIcon, {})
																	})
																}),
																_jsx(Divider, {
																	orientation: 'vertical',
																	flexItem: true,
																	sx: { marginTop: '-3px', marginBottom: '-3px' }
																}),
																_jsx(SearchBar, {
																	keyword: keyword,
																	onChange: handleSearchKeyword,
																	showDecoratorIcon: true,
																	showActionButton: Boolean(keyword),
																	sxs: {
																		root: {
																			maxWidth: '200px',
																			background: 'none !important',
																			border: 'none !important',
																			borderRadius: 0,
																			boxShadow: 'none'
																		},
																		inputInput: { padding: '8px 5px' }
																	}
																})
															]
														}),
														_jsx(Box, {
															sx: { display: 'flex', flexGrow: 0 },
															children: _jsx(IconButton, {
																onClick: switchViewMode,
																sx: { mr: 1 },
																'aria-label': formatMessage({ defaultMessage: 'Switch view mode' }),
																children:
																	viewMode === 'card'
																		? _jsx(ListViewIcon, {})
																		: viewMode === 'compact'
																			? _jsx(ReorderRoundedIcon, {})
																			: _jsx(GridViewIcon, {})
															})
														})
													]
												})
											}),
											error
												? _jsx(EmptyState, {
														title: _jsx(FormattedMessage, { defaultMessage: 'Unable to load items.' }),
														sxs: { root: { flexGrow: 1 } }
													})
												: filteredItems?.length
													? _jsx(Box, {
															sx: [
																{
																	display: 'grid',
																	gridTemplateColumns: MEDIA_CARD_GRID_TEMPLATE_COLUMNS,
																	gridGap: '16px',
																	padding: 'initial'
																},
																viewMode === 'row' && { display: 'flex !important', flexFlow: 'wrap' }
															],
															children: filteredItems.map((item) =>
																_jsx(
																	MediaCard,
																	{
																		viewMode: viewMode,
																		item: { ...item, path: item.previewUrl },
																		previewAppBaseUri: guestBase,
																		onClick: !multiSelect ? () => onCardSelected(item) : null,
																		selected: multiSelect ? [...selectedArray] : [],
																		onSelect: multiSelect ? () => onCardSelected(item) : null,
																		isSelected: multiSelect ? undefined : item.path === selectedCard?.path,
																		onPreview: null,
																		sxs: {
																			root: {
																				cursor: 'pointer',
																				...(item.path === selectedCard?.path
																					? {
																							boxShadow: (theme) => `0px 0px 4px 4px ${theme.palette.primary.main}`
																						}
																					: {})
																			}
																		}
																	},
																	item.previewUrl
																)
															)
														})
													: _jsx(EmptyState, {
															title: _jsx(FormattedMessage, { defaultMessage: 'No items found.' }),
															sxs: { root: { flexGrow: 1 } }
														})
										]
									})
								})
					]
				})
			}),
			_jsxs(DialogFooter, {
				children: [
					_jsx(SecondaryButton, {
						onClick: onCloseButtonClick,
						children: _jsx(FormattedMessage, { defaultMessage: 'Cancel' })
					}),
					_jsx(PrimaryButton, {
						disabled: disableSubmit,
						onClick: onSelectButtonClick,
						children: _jsx(FormattedMessage, { defaultMessage: 'Select' })
					})
				]
			})
		]
	});
}
export function BrowseExternalAssetDialog(props) {
	const { path, profileId, onClose, onSuccess, multiSelect, preselectedPaths, profileType, type, ...rest } = props;
	return _jsx(EnhancedDialog, {
		title: _jsx(FormattedMessage, { defaultMessage: 'Select an item' }),
		onClose: onClose,
		maxWidth: 'lg',
		...rest,
		children: _jsx(BrowseExternalAssetDialogBody, {
			path: path,
			profileId: profileId,
			multiSelect: multiSelect,
			preselectedPaths: preselectedPaths,
			profileType: profileType,
			onClose: onClose,
			onSuccess: onSuccess,
			type: type
		})
	});
}
function ExternalAssetFoldersTreeView({ foldersByPath, path, folder, currentPath, level = 1, onFolderClick }) {
	const label = folder?.name ?? path ?? '/';
	const labelId = React.useId();
	return _jsx(TreeItem, {
		itemId: path,
		'aria-level': level,
		'aria-selected': path === currentPath,
		'aria-labelledby': labelId,
		onClick: (event) => {
			if (!isOwnTreeItemEvent(event)) {
				return;
			}
			event.stopPropagation();
			if (event.target.closest('.MuiTreeItem-iconContainer')) {
				return;
			}
			onFolderClick(event, path);
		},
		onKeyDown: (event) => {
			if (!isOwnTreeItemEvent(event)) {
				return;
			}
			if (event.key === 'Enter') {
				cancelTreeItemKey(event);
				onFolderClick(event, path);
			}
		},
		label: _jsx(Box, { id: labelId, children: label }),
		sx: {
			'&:focus-visible > .MuiTreeItem-content': getFocusRingSx({ inset: true })
		},
		children: foldersByPath[path]?.map((child) =>
			_jsx(
				ExternalAssetFoldersTreeView,
				{
					foldersByPath: foldersByPath,
					path: child.path,
					folder: child,
					currentPath: currentPath,
					level: level + 1,
					onFolderClick: onFolderClick
				},
				child.path
			)
		)
	});
}
export default BrowseExternalAssetDialog;
