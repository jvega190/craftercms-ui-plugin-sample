/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { Fragment as _Fragment, jsx as _jsx, jsxs as _jsxs } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import { useEffect, useState } from 'react';
import EnhancedDialog from '../EnhancedDialog';
import DialogBody from '../DialogBody/DialogBody';
import DialogFooter from '../DialogFooter/DialogFooter';
import { FormattedMessage, useIntl } from 'react-intl';
import { diffConflictedFile } from '../../services/repositories';
import ConflictedPathDiffDialogUI from './ConflictedPathDiffDialogUI';
import SecondaryButton from '../SecondaryButton';
import ConfirmDropdown from '../ConfirmDropdown';
import { messages } from '../GitManagement/RepoStatus/translations';
import Tab, { tabClasses } from '@mui/material/Tab';
import Tabs from '@mui/material/Tabs';
import { useActiveSiteId } from '../../hooks/useActiveSiteId';
import { ApiResponseErrorState } from '../ApiResponseErrorState';
import { LoadingState } from '../LoadingState';
export function ConflictedPathDiffDialog(props) {
	const { path, onResolveConflict, onClose, ...dialogProps } = props;
	const siteId = useActiveSiteId();
	const [tab, setTab] = useState(0);
	const [fileDiff, setFileDiff] = useState(null);
	const [fetching, setFetching] = useState(false);
	const [error, setError] = useState();
	const { formatMessage } = useIntl();
	useEffect(() => {
		if (path) {
			setFetching(true);
			diffConflictedFile(siteId, path).subscribe({
				next(fileDiff) {
					setFileDiff(fileDiff);
					setFetching(false);
				},
				error({ response }) {
					setError(response);
					setFetching(false);
				}
			});
		}
	}, [path, siteId]);
	const handleTabChange = (event, newValue) => {
		setTab(newValue);
	};
	return _jsxs(EnhancedDialog, {
		title: _jsxs(_Fragment, {
			children: [_jsx(FormattedMessage, { id: 'words.diff', defaultMessage: 'Diff' }), ': ', path]
		}),
		maxWidth: 'lg',
		dialogHeaderProps: {
			sxs: {
				root: {
					paddingBottom: 0
				},
				subtitleWrapper: {
					padding: 0
				}
			},
			children: _jsxs(Tabs, {
				value: tab,
				indicatorColor: 'primary',
				textColor: 'primary',
				onChange: handleTabChange,
				sx: {
					minHeight: 'inherit',
					[`& .${tabClasses.root}`]: {
						minWidth: '80px',
						minHeight: '0',
						padding: '0 0 5px 0',
						marginRight: '20px',
						opacity: 1,
						'& span': {
							textTransform: 'none'
						}
					}
				},
				children: [
					_jsx(Tab, { label: _jsx(FormattedMessage, { id: 'words.diff', defaultMessage: 'Diff' }) }),
					_jsx(Tab, { label: _jsx(FormattedMessage, { id: 'repositories.splitView', defaultMessage: 'Split View' }) })
				]
			})
		},
		onClose: onClose,
		...dialogProps,
		children: [
			_jsx(DialogBody, {
				sx: { padding: 0 },
				children: error
					? _jsx(ApiResponseErrorState, { error: error })
					: fetching
						? _jsx(LoadingState, {})
						: fileDiff
							? _jsx(ConflictedPathDiffDialogUI, { fileDiff: fileDiff, tab: tab })
							: null
			}),
			_jsxs(DialogFooter, {
				children: [
					_jsx(SecondaryButton, {
						onClick: (e) => onClose?.(e, null),
						children: _jsx(FormattedMessage, { id: 'words.close', defaultMessage: 'Close' })
					}),
					_jsx(ConfirmDropdown, {
						sx: {
							button: {
								color: (theme) => theme.palette.warning.dark,
								borderColor: (theme) => theme.palette.warning.main
							}
						},
						text: formatMessage(messages.acceptRemote),
						cancelText: formatMessage(messages.no),
						confirmText: formatMessage(messages.yes),
						confirmHelperText: formatMessage(messages.acceptRemoteHelper),
						onConfirm: () => onResolveConflict('theirs', path)
					}),
					_jsx(ConfirmDropdown, {
						sx: {
							button: {
								color: (theme) => theme.palette.warning.dark,
								borderColor: (theme) => theme.palette.warning.main
							}
						},
						text: formatMessage(messages.keepLocal),
						cancelText: formatMessage(messages.no),
						confirmText: formatMessage(messages.yes),
						confirmHelperText: formatMessage(messages.keepLocalHelper),
						onConfirm: () => onResolveConflict('ours', path)
					})
				]
			})
		]
	});
}
export default ConflictedPathDiffDialog;
