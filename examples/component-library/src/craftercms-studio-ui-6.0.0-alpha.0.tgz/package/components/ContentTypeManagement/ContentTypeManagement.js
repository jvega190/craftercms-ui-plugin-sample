/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { Fragment as _Fragment, jsx as _jsx, jsxs as _jsxs } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import { useState } from 'react';
import EditTypeView from './components/EditTypeView';
import { TypeListingView } from './components/TypeListingView';
import Fade from '@mui/material/Fade';
export function ContentTypeManagement(props) {
	const { embedded = false, showAppsButton, onSubmittingAndOrPendingChange, mountMode, onClose, onMinimize } = props;
	const [view, setView] = useState('list');
	const [selectedType, setSelectedType] = useState(null);
	const handleTypeSelected = (_, item) => {
		setSelectedType(item);
		setView('edit');
	};
	const handleBackToList = () => {
		setSelectedType(null);
		setView('list');
	};
	return _jsxs(_Fragment, {
		children: [
			view === 'list' &&
				_jsx(Fade, {
					in: true,
					children: _jsx(TypeListingView, {
						sx: { height: '100%' },
						renderAppBar: !embedded,
						onTypeSelected: handleTypeSelected,
						showOpenLauncherButton: showAppsButton
					})
				}),
			view === 'edit' &&
				_jsx(Fade, {
					in: true,
					children: _jsx(EditTypeView, {
						type: selectedType,
						onExit: handleBackToList,
						mountMode: mountMode,
						onClose: onClose,
						onMinimize: onMinimize,
						onSubmittingAndOrPendingChange: onSubmittingAndOrPendingChange
					})
				})
		]
	});
}
export default ContentTypeManagement;
