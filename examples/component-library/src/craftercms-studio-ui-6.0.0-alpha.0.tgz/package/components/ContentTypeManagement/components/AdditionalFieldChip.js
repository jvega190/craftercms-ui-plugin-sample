/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2026 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import SubdirectoryArrowRightRoundedIcon from '@mui/icons-material/SubdirectoryArrowRightRounded';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import useIsDarkModeTheme from '../../../hooks/useIsDarkModeTheme';
import { FormattedMessage } from 'react-intl';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import Tooltip from '@mui/material/Tooltip';
import { processAdditionalFieldMacro } from '../../FormsEngine/lib/formUtils';
export function AdditionalFieldChip(props) {
	const { fieldId, parentFieldId } = props;
	const isDark = useIsDarkModeTheme();
	const additionalFieldId = processAdditionalFieldMacro(parentFieldId, fieldId);
	return _jsxs(Box, {
		sx: {
			display: 'flex',
			alignItems: 'center',
			mb: 1
		},
		children: [
			_jsx(SubdirectoryArrowRightRoundedIcon, { sx: { ml: 3 } }),
			_jsxs(Box, {
				sx: [
					{
						width: '100%',
						bgcolor: isDark ? 'grey.800' : 'grey.200',
						borderRadius: 10,
						overflow: 'hidden',
						border: '1px solid transparent',
						px: 1.5,
						py: 0.5,
						display: 'flex',
						justifyContent: 'space-between'
					}
				],
				children: [
					_jsx(Typography, { component: 'span', variant: 'body2', children: additionalFieldId }),
					_jsxs(Box, {
						sx: { display: 'flex', alignItems: 'center', gap: 0.5 },
						children: [
							_jsx(Typography, {
								variant: 'body2',
								component: 'span',
								children: _jsx(FormattedMessage, { defaultMessage: 'Additional Field' })
							}),
							_jsx(Tooltip, {
								title: _jsx(FormattedMessage, {
									defaultMessage:
										'An additional field is a field that this control has permission to edit, beyond its main value. '
								}),
								placement: 'top',
								children: _jsx(InfoOutlinedIcon, { fontSize: 'small' })
							})
						]
					})
				]
			})
		]
	});
}
export default AdditionalFieldChip;
