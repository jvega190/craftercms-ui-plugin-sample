/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs } from 'react/jsx-runtime';
import { createElement, forwardRef, useEffect, useMemo, useRef, useState } from 'react';
import {
	applyTranslations,
	buildContentTypeXml,
	CONTENT_TYPES_BASE_PATH,
	createDataSourceValuesObject,
	createEmptyTypeStructure,
	createFieldFormContextApi,
	createTypeFieldValuesObject,
	createTypeFormValuesObject,
	createTypeTemplate,
	createVirtualTypeForDataSource,
	createVirtualTypeForField,
	createVirtualTypeFormContext,
	createVirtualTypeForSection,
	editTypeTemplate,
	getFieldFromType,
	getPropertiesAndValidationsFromDescriptor,
	getSectionFromType,
	getDataSourceSiblingIds,
	getFieldIdSet,
	getSiblingFieldIds,
	isComposedPath,
	typeForNextArtefactForm,
	NEW_DATASOURCE_ID,
	NEW_FIELD_ID,
	prepareSerializeToXmlTypeObject,
	reverseTypeFieldValuesObject,
	systemFieldsIdsMap,
	systemFieldsTypesMap,
	TYPE_TEMPLATE_BASE_PATH,
	typePropsToEdit
} from '../utils';
import { EMPTY_CHANGED_FIELD_IDS, extractAtomValues, useShowAlert } from '../../FormsEngine/lib/formUtils';
import TypeBuilderFormsEngine from './TypeBuilderFormsEngine';
import controlDescriptors from '../descriptors/controls';
import dataSourceDescriptors from '../descriptors/dataSources';
import TypeDetailsView from './TypeDetailsView';
import useContentTypes from '../../../hooks/useContentTypes';
import { createStore as createJotai, Provider } from 'jotai';
import { debounceTime, forkJoin, map, Subject, tap } from 'rxjs';
import EditTypeViewLayout from './EditTypeViewLayout';
import useUpdateRefs from '../../../hooks/useUpdateRefs';
import useActiveSiteId from '../../../hooks/useActiveSiteId';
import { FormattedMessage, useIntl } from 'react-intl';
import { createLookupTable, nnou, pluckProps, reversePluckProps } from '../../../utils/object';
import Box from '@mui/material/Box';
import useEnhancedDialogContext from '../../EnhancedDialog/useEnhancedDialogContext';
import { fetchSiteUiConfig, writeConfiguration } from '../../../services/configuration';
import { createFormDefinitionPathFromTypeId } from '../../../utils/contentType';
import { useDispatch } from 'react-redux';
import { popDialog, pushDialog } from '../../../state/actions/dialogStack';
import { nanoid } from 'nanoid';
import useEnv from '../../../hooks/useEnv';
import { deserialize, fromString, serialize } from '../../../utils/xml';
import useSpreadState from '../../../hooks/useSpreadState';
import { asArray } from '../../../utils/array';
import { fetchContentItem } from '../../../services/content';
import { queueFormDefinitionWrite } from '../../../services/contentTypes';
import { batchActions } from '../../../state/actions/misc';
import { fetchItemVersions } from '../../../state/actions/versions';
import { getRootPath } from '../../../utils/path';
import { showHistoryDialog } from '../../../state/actions/dialogs';
import { XmlViewerDialog } from './XmlViewerDialog';
import {
	assignCreatedTypeTemplate,
	createTypeWorkingCopy,
	deleteDataSourceFromType,
	insertDataSourceIntoType,
	reorderTypeSections,
	typeTemplatePathFromCreatedItem
} from './editTypeWorkingCopy';
import useEnhancedDialogState from '../../../hooks/useEnhancedDialogState';
import { XmlDiffDialog } from './XmlDiffDialog';
import PickControlDialog from './PickControlDialog';
import PickDataSourceDialog from './PickDataSourceDialog';
import { TypeControllerFlagContext } from '../typeControllerFlagContext';
import { FieldNamePostfixContext } from '../fieldNamePostfixContext';
import { collectTopLevelFieldNamePostfixViolations, formatPostfixList } from '../fieldNamePostfix';
import { fetchContentTypes } from '../../../state/actions/preview';
import useSelection from '../../../hooks/useSelection';
import { valueSerializersLookup } from '../../FormsEngine/lib/valueSerializers';
import { pushErrorDialog } from '../../../utils/system';
import {
	contentTypeCreated,
	contentTypeDeleted,
	emitSystemEvent,
	showSystemNotification
} from '../../../state/actions/system';
import { extractErrorPayload } from '../../../utils/ajax';
import Typography from '@mui/material/Typography';
import { sectionDescriptor, typeBasicDetailsDescriptor } from '../descriptors/controls/commonDescriptors';
export const EditTypeView = forwardRef((props, ref) => {
	const { onExit, onClose, onMinimize, mountMode, onSubmittingAndOrPendingChange } = props;
	const site = useActiveSiteId();
	const contentTypesLookup = useContentTypes();
	const showAlert = useShowAlert();
	const { formatMessage } = useIntl();
	const jotai = useMemo(() => createJotai(), []); // TODO: Use stable memo?
	const dispatch = useDispatch();
	const { activeEnvironment } = useEnv();
	const dialogContext = useEnhancedDialogContext();
	const stateRef = useRef(null);
	if (!stateRef.current) stateRef.current = createContextObject();
	// Deep-clone so nested fields/sections/dataSources are not shared with `props.type`
	// (rollback baseline / diff source). A shallow spread would leak in-place mutations.
	const [type, setType] = useState(() => createTypeWorkingCopy(props.type));
	const typeRef = useRef(type);
	typeRef.current = type;
	// `<controller>` written straight to the saved form-definition this session. Rollback and diff
	// start from `props.type`, which predates that write, so they apply this on top.
	const persistedJsControllerRef = useRef(null);
	const withPersistedJsController = (baseType) =>
		persistedJsControllerRef.current === null
			? baseType
			: { ...baseType, hasJsController: persistedJsControllerRef.current };
	const typeControllerFlagContext = useMemo(
		() => ({
			onJsControllerPersisted(enabled) {
				persistedJsControllerRef.current = enabled;
				setType((current) =>
					current.hasJsController === enabled ? current : { ...current, hasJsController: enabled }
				);
				// If the type properties form was reopened after the write started, its atom was seeded
				// from the old working copy and would write that back when the form commits.
				const { activeFormContext, selectedField, selectedSection, selectedDataSource } = stateRef.current;
				if (selectedField || selectedSection || selectedDataSource) return;
				const flagAtom = activeFormContext?.atoms?.valueByFieldId?.hasJsController;
				if (flagAtom && jotai.get(flagAtom) !== enabled) {
					jotai.set(flagAtom, enabled);
				}
			}
		}),
		[jotai]
	);
	const formEngine = useSelection((state) => state.uiConfig.formEngine);
	const fieldNamePostfixContext = useMemo(
		() => ({
			fieldNamePostfix: formEngine.fieldNamePostfix,
			ignorePostfixFields: formEngine.ignorePostfixFields
		}),
		[formEngine.fieldNamePostfix, formEngine.ignorePostfixFields]
	);
	const [open, setOpen] = useState(false);
	const xmlViewerDialogState = useEnhancedDialogState();
	const [xmlViewerContent, setXmlViewerContent] = useState(undefined);
	const xmlDiffDialogState = useEnhancedDialogState();
	const [xmlDiffContent, setXmlDiffContent] = useState(undefined);
	const [selectedFieldIdPath, setSelectedFieldIdPath] = useState(null);
	/** Id of the field that was open when closeAndCleanup last committed (post-rename). Used to rewrite child paths. */
	const committedSelectedFieldIdOnCloseRef = useRef(null);
	const [hasPendingChanges, setHasPendingChanges] = useState(false);
	const [virtualContentType, setVirtualContentType] = useState(null);
	const [fieldFormViewProps, setFieldFormViewProps] = useState(null);
	const [fieldPathsWithErrors, setFieldPathsWithErrors] = useState({});
	const [config, setConfig] = useSpreadState({
		controls: null,
		controlExclusions: null,
		dataSources: null,
		dataSourceExclusions: null
	});
	const [drawerOpenTransitionEnded, setDrawerOpenTransitionEnded] = useState(false);
	const [insertFieldData, setInsertFieldData] = useState({
		sectionId: null,
		fieldPath: null
	});
	const [openDataSourceInserter, setOpenDataSourceInserter] = useState(false);
	const [activeFormHasErrors, setActiveFormHasErrors] = useState(false);
	const [contentItem, setContentItem] = useState(null);
	// Bumped after save of an existing type so the effect re-fetches (and cancels any in-flight request).
	const [contentItemReloadToken, setContentItemReloadToken] = useState(0);
	const openRef = useRef(open);
	openRef.current = open;
	const configDescriptors = useMemo(() => {
		const controlDescriptors = Object.values(config?.controls ?? {}).map(({ descriptor }) => descriptor);
		const dataSourceDescriptors = Object.values(config?.dataSources ?? {}).map(({ descriptor }) => descriptor);
		return {
			controlDescriptors: controlDescriptors.length ? createLookupTable(controlDescriptors) : null,
			dataSourceDescriptors: dataSourceDescriptors.length ? createLookupTable(dataSourceDescriptors) : null
		};
	}, [config?.controls, config?.dataSources]);
	const { configControlDescriptors, configDataSourceDescriptors } = useMemo(() => {
		return {
			configControlDescriptors: config?.controls
				? Object.values(config?.controls)
						.map(({ descriptor }) => descriptor)
						.filter((descriptor) => nnou(descriptor))
				: [],
			configDataSourceDescriptors: config?.dataSources
				? Object.values(config?.dataSources)
						.map(({ descriptor }) => descriptor)
						.filter((descriptor) => nnou(descriptor))
				: []
		};
	}, [config]);
	/** True when the open form has unsaved edits (derived from that form's synchronous changedFieldIds). */
	const activeFormHasChanges = () => {
		const formContext = stateRef.current.activeFormContext;
		return formContext?.changedFieldIds ? jotai.get(formContext.changedFieldIds).size > 0 : false;
	};
	/** Saves and commits the state changes. Returns undefined if no changes occurred. */
	const commitOpenFormChanges = () => {
		// No form open, nothing to commit. Or, a form was opened but no changes were made.
		// Derive dirty from the active form's changedFieldIds so commit is not gated on the
		// background-validation debounce that mirrors formFieldsChanged.
		const currentType = typeRef.current;
		if (!open || !activeFormHasChanges()) return;
		const formContext = stateRef.current.activeFormContext;
		let updatedType;
		const values = extractAtomValues(jotai, formContext.atoms.valueByFieldId);
		if (stateRef.current.selectedField) {
			updatedType = updateTypeFromFieldUpdate(
				currentType,
				stateRef.current,
				values,
				selectedFieldIdPath,
				configDescriptors.controlDescriptors
			);
		} else if (stateRef.current.selectedSection) {
			updatedType = updateTypeFromSectionUpdate(currentType, stateRef.current.selectedSection, values);
		} else if (stateRef.current.selectedDataSource) {
			const currentDataSource = stateRef.current.selectedDataSource;
			const descriptor =
				dataSourceDescriptors[currentDataSource.type] ?? config.dataSources?.[currentDataSource.type]?.descriptor;
			if (!descriptor) {
				console.error(`No data source descriptor found for type "${currentDataSource.type}"`);
				return type;
			}
			updatedType = updateTypeFromDataSourceUpdate(currentType, currentDataSource, values, descriptor);
		} else {
			// There's no selected field, section or data source, so assume the type itself is being edited.
			updatedType = updateTypeProps(currentType, values);
		}
		jotai.set(formContext.changedFieldIds, EMPTY_CHANGED_FIELD_IDS);
		stateRef.current.formFieldsChanged = false;
		// Keep typeRef in sync immediately so in-flight save completion can detect
		// structural divergence from typeToSave before the next render.
		typeRef.current = updatedType;
		setType(updatedType);
		return updatedType;
	};
	/**
	 * Returns true if no form is opened or if the active form is valid and can be committed/closed.
	 * Eagerly re-checks validation atoms so callers are not gated on the debounced activeFormHasErrors flag.
	 */
	const performCurrentFormErrorCheckAndWarning = async () => {
		if (!openRef.current) return true;
		const formContext = stateRef.current.activeFormContext;
		// Capture before await so a field switch cannot clear/update the wrong path.
		const fieldPath = selectedFieldIdPath;
		const hasErrors = await validityAtomsHaveErrors(jotai, formContext?.atoms?.validationByFieldId);
		// Form may have closed or been replaced while awaiting atom resolution.
		if (!openRef.current || stateRef.current.activeFormContext !== formContext) return false;
		setActiveFormHasErrors(hasErrors);
		// Clear eagerly on success so a debounced run discarded after switch cannot leave a stale error
		// that keeps disableSave true. Leave entries for other paths untouched.
		if (!hasErrors) {
			setFieldPathsWithErrors((prev) => {
				if (!prev[fieldPath]) return prev;
				const next = { ...prev };
				delete next[fieldPath];
				return next;
			});
		}
		if (hasErrors) {
			showAlert(formatMessage({ defaultMessage: 'Please resolve any issues prior to closing the form' }));
			return false;
		}
		return true;
	};
	/**
	 * Closes the active form and cleans up state.
	 * Returns the post-commit ContentType on success (or the current type when nothing was committed),
	 * so callers that immediately open another form can use up-to-date sibling IDs without waiting
	 * for the setType re-render. Returns false when the form has unresolved errors.
	 */
	const closeAndCleanup = async () => {
		if (!(await performCurrentFormErrorCheckAndWarning())) return false;
		const postCloseType = commitOpenFormChanges() ?? typeRef.current;
		// Capture after commit (rename applied to selectedField) before clearing for path rewrite.
		committedSelectedFieldIdOnCloseRef.current = stateRef.current.selectedField?.id ?? null;
		stateRef.current.selectedField = null;
		stateRef.current.selectedSection = null;
		stateRef.current.selectedDataSource = null;
		stateRef.current.formFieldsChanged = false;
		// `activeFormContext` is not nulled since without it, TypeBuilderFormsEngine would crash
		// stateRef.current.activeFormContext = null;
		setVirtualContentType(null);
		setSelectedFieldIdPath(null);
		setOpen(false);
		return postCloseType;
	};
	/** Performs the common steps that must occur when an artefact is selected for editing. */
	const handleArtefactSelected = (virtualType, stableFormContext, extraFormProps) => {
		setFieldFormViewProps({
			type,
			virtualType,
			stableFormContext,
			formApiContext: stateRef.current.formContextApi,
			onClose: async () => {
				const formValid = await effectRefs.current.closeAndCleanup();
				if (!formValid) return;
				setDrawerOpenTransitionEnded(false);
			},
			onDeleteField: handleDeleteField,
			onDeleteSection: handleDeleteSection,
			onDeleteDataSource: handleDeleteDataSource,
			onMoveFieldToSection: handleMoveFieldToSection,
			onReorderSectionFields: handleReorderSectionFields,
			onReorderTypeSections: handleReorderTypeSections,
			onReorderRepGroupFields: handleReorderRepGroupFields,
			onSwapField: handleSwapFileNameField,
			...extraFormProps
		});
		// Note: things set here should be cleaned up in closeAndCleanup
		stateRef.current.activeFormContext = stableFormContext;
		// New form starts clean; do not inherit dirty from a prior form's emissions.
		stateRef.current.formFieldsChanged = false;
		setVirtualContentType(virtualType);
		setOpen(true);
	};
	const handleFieldSelected = async (fieldIdPath, field, sectionId, overrideType) => {
		// Capture before closeAndCleanup clears selectedFieldIdPath (React state still closed over,
		// but be explicit). Committed id is stashed by closeAndCleanup after rename commit.
		const openFieldIdPath = selectedFieldIdPath;
		const postCloseType = await closeAndCleanup();
		if (!postCloseType) return;
		const typeForForm = typeForNextArtefactForm(overrideType, postCloseType);
		// Path was captured pre-commit; if the open form renamed the parent (or an ancestor), rewrite that segment.
		let resolvedFieldIdPath = fieldIdPath;
		const committedOpenFieldId = committedSelectedFieldIdOnCloseRef.current;
		if (
			openFieldIdPath &&
			committedOpenFieldId &&
			(fieldIdPath === openFieldIdPath || fieldIdPath.startsWith(`${openFieldIdPath}.`))
		) {
			const segments = fieldIdPath.split('.');
			segments[openFieldIdPath.split('.').length - 1] = committedOpenFieldId;
			resolvedFieldIdPath = segments.join('.');
		}
		// Prefer the field from typeForForm so nested child edits committed by closeAndCleanup
		// are preserved (e.g. selecting a parent after editing one of its children).
		const fieldForForm = getFieldFromType(typeForForm, resolvedFieldIdPath) ?? field;
		const controlDescriptor = controlDescriptors[fieldForForm.type] ?? config.controls?.[fieldForForm.type]?.descriptor;
		if (!controlDescriptor)
			return showAlert(`No control descriptor found for field "${fieldForForm.name}" of type "${fieldForForm.type}"`);
		// Adding data sources to the virtual type to ensure they are available for rendering in the dataSourceSelector.
		const virtualType = createVirtualTypeForField(
			{ ...controlDescriptor, dataSources: typeForForm.dataSources },
			formatMessage
		);
		handleArtefactSelected(
			virtualType,
			createVirtualTypeFormContext(
				virtualType,
				createTypeFieldValuesObject(fieldForForm),
				contentTypesLookup,
				{
					fieldUpdates$: stateRef.current.fieldUpdates$
				},
				{
					siblingIds: getSiblingFieldIds(
						typeForForm,
						resolvedFieldIdPath,
						configDescriptors.controlDescriptors ?? undefined
					),
					currentIds: getFieldIdSet(
						fieldForForm.id,
						fieldForForm.type,
						configDescriptors.controlDescriptors ?? undefined
					),
					additionalFields: controlDescriptor.metadata?.additionalFields ?? undefined,
					// Nested fields (inside a repeat) are not postfix-checked; only the repeat itself is.
					...(!isComposedPath(resolvedFieldIdPath) &&
						formEngine.fieldNamePostfix && {
							fieldNamePostfix: {
								enabled: true,
								ignoreFields: formEngine.ignorePostfixFields,
								suffixes: controlDescriptor.metadata?.suffixes ?? []
							}
						})
				}
			),
			{
				field: fieldForForm,
				fieldIdPath: resolvedFieldIdPath,
				controlDescriptor: applyTranslations(controlDescriptor, formatMessage),
				sectionId,
				type: typeForForm
			}
		);
		setSelectedFieldIdPath(resolvedFieldIdPath);
		stateRef.current.selectedField = fieldForForm;
	};
	const handleSectionSelected = async (section, overrideType) => {
		const postCloseType = await closeAndCleanup();
		if (!postCloseType) return;
		const typeForForm = typeForNextArtefactForm(overrideType, postCloseType);
		const sectionIndex = typeForForm.sections.findIndex((s) => s.id === section.id);
		const virtualType = createVirtualTypeForSection(sectionDescriptor, formatMessage);
		handleArtefactSelected(
			virtualType,
			createVirtualTypeFormContext(virtualType, section, contentTypesLookup, {
				fieldUpdates$: stateRef.current.fieldUpdates$
			}),
			{ section, isMainSection: sectionIndex === 0, type: typeForForm }
		);
		stateRef.current.selectedSection = section;
	};
	const handleDataSourceSelected = async (dataSource) => {
		const postCloseType = await closeAndCleanup();
		if (!postCloseType) return;
		const typeForForm = postCloseType;
		const dataSourceDescriptor =
			dataSourceDescriptors[dataSource.type] ?? config.dataSources?.[dataSource.type]?.descriptor;
		if (!dataSourceDescriptor)
			return showAlert(`No control descriptor found for field "${dataSource.title}" of type "${dataSource.type}"`);
		const virtualType = createVirtualTypeForDataSource(dataSourceDescriptor, formatMessage);
		handleArtefactSelected(
			virtualType,
			createVirtualTypeFormContext(
				virtualType,
				createDataSourceValuesObject(dataSource),
				contentTypesLookup,
				{
					fieldUpdates$: stateRef.current.fieldUpdates$
				},
				{
					siblingIds: getDataSourceSiblingIds(typeForForm),
					currentIds: [dataSource.id]
				}
			),
			{ dataSource, type: typeForForm }
		);
		const dataSourceId = dataSource.id ? dataSource.id : NEW_DATASOURCE_ID;
		setSelectedFieldIdPath(dataSourceId);
		stateRef.current.selectedDataSource = dataSource;
	};
	const handleEditTypeProperties = async (overrideType) => {
		const postCloseType = await closeAndCleanup();
		if (!postCloseType) return;
		const typeForForm = typeForNextArtefactForm(overrideType, postCloseType);
		const virtualType = createEmptyTypeStructure(applyTranslations(typeBasicDetailsDescriptor, formatMessage));
		handleArtefactSelected(
			virtualType,
			createVirtualTypeFormContext(virtualType, createTypeFormValuesObject(typeForForm), contentTypesLookup, {
				fieldUpdates$: stateRef.current.fieldUpdates$
			}),
			{ type: typeForForm }
		);
	};
	const onUpdateHasPendingChanges = (hasPendingChanges) => {
		setHasPendingChanges(hasPendingChanges);
		const pendingState = { hasPendingChanges };
		dialogContext?.updateSubmittingOrHasPendingChanges(pendingState);
		onSubmittingAndOrPendingChange?.(pendingState);
	};
	const reportSubmittingOrPending = (value) => {
		dialogContext?.updateSubmittingOrHasPendingChanges(value);
		onSubmittingAndOrPendingChange?.(value);
	};
	const effectRefs = useUpdateRefs({
		jotai,
		open,
		selectedFieldIdPath,
		fieldPathsWithErrors,
		activeFormHasErrors,
		closeAndCleanup,
		handleEditTypeProperties,
		onUpdateHasPendingChanges
	});
	const handleCloseDrawer = () => effectRefs.current.closeAndCleanup();
	const handleEditTypeAction = (e, target) => {
		switch (target) {
			case 'properties': {
				handleEditTypeProperties();
				break;
			}
			case 'template': {
				const templatePath = type.displayTemplate;
				if (templatePath) {
					editTypeTemplate(templatePath, dispatch);
				} else {
					createTypeTemplate(TYPE_TEMPLATE_BASE_PATH, dispatch, (item) => {
						const path = typeTemplatePathFromCreatedItem(item);
						setType((current) => assignCreatedTypeTemplate(current, item));
						// Sync open type-properties form so TemplateSelector shows the path
						// and commit doesn't overwrite with the old empty atom value.
						const { activeFormContext, selectedField, selectedSection, selectedDataSource } = stateRef.current;
						if (openRef.current && !selectedField && !selectedSection && !selectedDataSource) {
							const templateAtom = activeFormContext?.atoms?.valueByFieldId?.displayTemplate;
							if (templateAtom && jotai.get(templateAtom) !== path) {
								jotai.set(templateAtom, path);
							}
						}
						onUpdateHasPendingChanges(true);
						editTypeTemplate(path, dispatch);
					});
				}
				break;
			}
			case 'deleted':
				onUpdateHasPendingChanges(false);
				dispatch(batchActions([emitSystemEvent(contentTypeDeleted()), fetchContentTypes()]));
				onExit?.();
				break;
		}
	};
	const handleToolbarActionClick = async (e, action) => {
		switch (action) {
			case 'exit':
				if (!(await performCurrentFormErrorCheckAndWarning())) break;
				if (hasPendingChanges) {
					const id = nanoid();
					dispatch(
						pushDialog({
							id,
							component: 'craftercms.components.ConfirmDialog',
							props: {
								title: _jsx(FormattedMessage, { defaultMessage: 'Discard changes?' }),
								onOk: () => {
									onExit?.();
									onUpdateHasPendingChanges(false);
									dispatch(popDialog({ id }));
								},
								onCancel: () => dispatch(popDialog({ id }))
							}
						})
					);
				} else {
					onExit?.();
				}
				break;
			case 'save':
			case 'saveAndClose':
			case 'saveAndMinimize': {
				if (!(await performCurrentFormErrorCheckAndWarning())) break;
				const latestUpdate = commitOpenFormChanges();
				const typeToSave = latestUpdate ?? typeRef.current;
				if (formEngine.fieldNamePostfix) {
					const postfixViolations = collectTopLevelFieldNamePostfixViolations(
						typeToSave,
						formEngine.ignorePostfixFields,
						(field) => (controlDescriptors[field.type] ?? config.controls?.[field.type]?.descriptor)?.metadata?.suffixes
					);
					if (postfixViolations.length) {
						showAlert({
							children: _jsxs(Box, {
								children: [
									_jsx(Typography, {
										sx: { marginBottom: 1 },
										children: _jsx(FormattedMessage, {
											defaultMessage:
												'Model fields require their respective data type postfix at the end of the variable name:'
										})
									}),
									_jsx(Box, {
										component: 'ul',
										sx: { m: 0, pl: 2 },
										children: postfixViolations.map((violation) =>
											_jsxs(
												Typography,
												{
													component: 'li',
													variant: 'body2',
													children: [
														_jsxs('strong', { children: [violation.title, ':'] }),
														' ',
														violation.suffixes.length > 1
															? _jsx(FormattedMessage, {
																	defaultMessage: 'options are {postfixes}',
																	values: { postfixes: formatPostfixList(violation.suffixes) }
																})
															: _jsx(FormattedMessage, {
																	defaultMessage: 'option is {postfixes}',
																	values: { postfixes: formatPostfixList(violation.suffixes) }
																})
													]
												},
												violation.id
											)
										)
									})
								]
							})
						});
						break;
					}
				}
				reportSubmittingOrPending({ isSubmitting: true });
				const isNew = Boolean(typeToSave.NEW);
				save(site, typeToSave.id, () => withPersistedJsController(typeToSave), configDescriptors).subscribe({
					next() {
						// Edits that landed after submit must keep pending state and must not close the dialog:
						// - open-form edits (fieldUpdates$ → changedFieldIds)
						// - structural working-type edits (delete/insert/move/etc. via setType) while save was in flight
						const postSubmitEdits = activeFormHasChanges() || typeRef.current !== typeToSave;
						onUpdateHasPendingChanges(postSubmitEdits);
						reportSubmittingOrPending({ isSubmitting: false, hasPendingChanges: postSubmitEdits });
						// If the type being saved is new, update the type state to remove the NEW property.
						// Clearing NEW triggers the contentItem effect to fetch once. For existing types, bump
						// the reload token so the same effect re-fetches (and cancels any in-flight request).
						// Use the current working copy so edits made while save was in flight are kept.
						if (isNew) {
							setType((current) => reversePluckProps(current, 'NEW'));
						} else {
							setContentItemReloadToken((token) => token + 1);
						}
						dispatch(
							batchActions([
								...(isNew ? [emitSystemEvent(contentTypeCreated())] : []),
								fetchContentTypes(),
								showSystemNotification({
									message: formatMessage({ defaultMessage: 'Save successful.' })
								})
							])
						);
						if (action === 'saveAndClose') {
							if (postSubmitEdits) {
								dispatch(
									showSystemNotification({
										message: formatMessage({
											defaultMessage: 'Saved. The dialog stayed open because there are newer unsaved changes.'
										})
									})
								);
							} else {
								onClose?.();
							}
						} else if (action === 'saveAndMinimize') {
							onMinimize?.();
						}
					},
					error(error) {
						reportSubmittingOrPending({ isSubmitting: false });
						showAlert({
							children: _jsxs(Box, {
								children: [
									_jsx(Typography, {
										sx: {
											marginBottom: 1
										},
										children: _jsx(FormattedMessage, { defaultMessage: 'Error saving content type' })
									}),
									_jsx(Typography, {
										variant: 'body2',
										color: 'textSecondary',
										children: extractErrorPayload(error).message ?? ''
									})
								]
							})
						});
					}
				});
				break;
			}
			case 'viewXml': {
				const xml = buildXmlFromType(type, configDescriptors);
				openViewXml(xml);
				break;
			}
			case 'diff': {
				const initialXml = buildXmlFromType(withPersistedJsController(props.type), configDescriptors);
				const currentXml = buildXmlFromType(type, configDescriptors);
				openDiffXml(initialXml, currentXml);
				break;
			}
			case 'history': {
				fetchContentItem(site, `${CONTENT_TYPES_BASE_PATH}${type.id}/form-definition.xml`).subscribe((item) => {
					dispatch(
						batchActions([
							fetchItemVersions({
								item,
								rootPath: getRootPath(item.path)
							}),
							showHistoryDialog({})
						])
					);
				});
				break;
			}
			case 'rollback': {
				const id = nanoid();
				dispatch(
					pushDialog({
						id,
						component: 'craftercms.components.ConfirmDialog',
						props: {
							body: _jsx(FormattedMessage, {
								defaultMessage: 'Are you sure you want to revert all changes made during this session?'
							}),
							onOk: () => {
								resetSelection();
								setType(withPersistedJsController(createTypeWorkingCopy(props.type)));
								dispatch(popDialog({ id }));
							},
							onCancel: () => dispatch(popDialog({ id }))
						}
					})
				);
				break;
			}
		}
	};
	const resetSelection = () => {
		setSelectedFieldIdPath(null);
		stateRef.current.selectedField = null;
		stateRef.current.formFieldsChanged = false;
		setVirtualContentType(null);
		setFieldFormViewProps(null);
		onUpdateHasPendingChanges(false);
		setDrawerOpenTransitionEnded(false);
		setOpen(false);
	};
	// region insert
	const onOpenInsertFieldDialog = async (sectionId, fieldPath) => {
		if (!(await performCurrentFormErrorCheckAndWarning())) return false;
		setInsertFieldData({ sectionId, fieldPath });
	};
	const onOpenInsertDataSourceDialog = async () => {
		if (!(await performCurrentFormErrorCheckAndWarning())) return false;
		setOpenDataSourceInserter(true);
	};
	const handleInsertSection = (section, position) => {
		setType((currentType) => insertSection(currentType, section, position));
		onUpdateHasPendingChanges(true);
		handleSectionSelected(section);
	};
	const handleInsertField = (fieldType, position) => {
		const { sectionId, fieldPath } = insertFieldData;
		setInsertFieldData({ sectionId: null });
		const configEntry = config.controls?.[fieldType];
		const descriptor = controlDescriptors[fieldType] ?? configEntry?.descriptor;
		if (!descriptor) {
			showAlert(`No control descriptor found for field type "${fieldType}"`);
			return;
		}
		// Commit open form first so a prior draft is no longer keyed as `{NEW}` before we add another.
		const baseType = commitOpenFormChanges() ?? typeRef.current;
		// Parent path was captured pre-commit; if the open form renamed the parent (or an ancestor), rewrite that segment.
		let resolvedParentPath = fieldPath;
		const committedId = stateRef.current.selectedField?.id;
		if (
			fieldPath &&
			selectedFieldIdPath &&
			committedId &&
			(fieldPath === selectedFieldIdPath || fieldPath.startsWith(`${selectedFieldIdPath}.`))
		) {
			const segments = fieldPath.split('.');
			segments[selectedFieldIdPath.split('.').length - 1] = committedId;
			resolvedParentPath = segments.join('.');
		}
		const parentField = resolvedParentPath
			? resolvedParentPath.split('.').reduce((parent, id) => parent?.fields?.[id], {
					fields: baseType.fields
				})
			: undefined;
		if (resolvedParentPath && !parentField) {
			showAlert(formatMessage({ defaultMessage: 'Unable to insert field: parent field was not found.' }));
			return;
		}
		const newField = getNewFieldFromDescriptor(fieldType, descriptor, configEntry);
		// Root drafts are keyed `{NEW}`; nested (addSubField) uses field.id when preset (e.g. file-name).
		const leafId = resolvedParentPath ? newField.id || NEW_FIELD_ID : NEW_FIELD_ID;
		// Preset IDs (system fields) must not replace an existing sibling in the target group.
		if (resolvedParentPath && newField.id && parentField.fields?.[newField.id]) {
			showAlert(formatMessage({ defaultMessage: 'That variable name is already in use.' }));
			return;
		}
		const newFieldPath = resolvedParentPath ? `${resolvedParentPath}.${leafId}` : leafId;
		const nextType = addField(baseType, newField, newFieldPath, sectionId, position);
		setType(nextType);
		onUpdateHasPendingChanges(true);
		handleFieldSelected(newFieldPath, newField, sectionId, nextType);
	};
	const handleInsertDataSource = (dataSourceType, position) => {
		const configEntry = config.dataSources?.[dataSourceType];
		const descriptor = dataSourceDescriptors[dataSourceType] ?? configEntry?.descriptor;
		if (!descriptor) {
			showAlert(`No data source descriptor found for type "${dataSourceType}"`);
			return;
		}
		const newDataSource = getNewDataSourceFromDescriptor(dataSourceType, descriptor, configEntry);
		setOpenDataSourceInserter(false);
		setType((currentType) => insertDataSourceIntoType(currentType, newDataSource, position));
		onUpdateHasPendingChanges(true);
		handleDataSourceSelected(newDataSource);
	};
	// endregion
	// region delete
	const handleDeleteSection = (section) => {
		resetSelection();
		onUpdateHasPendingChanges(true);
		setType((currentType) => deleteSection(currentType, section));
	};
	const handleDeleteField = (fieldIdPath, sectionId) => {
		resetSelection();
		onUpdateHasPendingChanges(true);
		setType((currentType) => deleteField(currentType, fieldIdPath, sectionId));
	};
	const handleDeleteDataSource = (dataSourceId) => {
		resetSelection();
		onUpdateHasPendingChanges(true);
		setType((currentType) => deleteDataSourceFromType(currentType, dataSourceId));
	};
	// endregion
	const handleSwapFileNameField = async (fieldId, sectionId, newField) => {
		if (!(await performCurrentFormErrorCheckAndWarning())) return;
		onUpdateHasPendingChanges(true);
		// Commit open form edits first so the swap runs on up-to-date type state.
		// commitOpenFormChanges clears the active form's changedFieldIds / formFieldsChanged
		// so a subsequent closeAndCleanup won't re-commit onto a stale type.
		const baseType = commitOpenFormChanges() ?? typeRef.current;
		// Field id may have changed during commit (rename); use the committed id for lookup/mutation.
		const committedFieldId = stateRef.current.selectedField?.id ?? fieldId;
		const nextType = {
			...baseType,
			fields: {
				...baseType.fields,
				[committedFieldId]: {
					...baseType.fields[committedFieldId],
					type: newField.id
				}
			}
		};
		setType(nextType);
		handleFieldSelected(committedFieldId, nextType.fields[committedFieldId], sectionId, nextType);
	};
	// region const fieldEditorView = ...
	const fieldEditorView = virtualContentType
		? _jsx(FieldNamePostfixContext.Provider, {
				value: fieldNamePostfixContext,
				children: _jsx(TypeControllerFlagContext.Provider, {
					value: typeControllerFlagContext,
					children: createElement(TypeBuilderFormsEngine, {
						...fieldFormViewProps,
						// Keep `type` current so delete-confirmation can list fields that still reference a data source.
						type,
						isPanelReady: drawerOpenTransitionEnded,
						onOpenInsertFieldDialog,
						performCurrentFormErrorCheckAndWarning
					})
				})
			})
		: null;
	// endregion
	const handleMoveFieldToSection = async (
		fieldIdPath,
		originSectionId,
		newSectionId,
		fieldIndex,
		isTargetRepeatGroup
	) => {
		if (!(await performCurrentFormErrorCheckAndWarning())) return;
		onUpdateHasPendingChanges(true);
		// Commit open form edits first so the move runs on up-to-date type state.
		// commitOpenFormChanges clears the active form's changedFieldIds / formFieldsChanged
		// so a subsequent closeAndCleanup won't re-commit onto a stale type.
		const baseType = commitOpenFormChanges() ?? typeRef.current;
		// Field id may have changed during commit (rename); replace only the leaf of composed paths.
		const committedFieldId = stateRef.current.selectedField?.id ?? getIdFromIdPath(fieldIdPath);
		const resolvedFieldIdPath = replaceIdPathLeaf(fieldIdPath, committedFieldId);
		const field = getFieldFromType(baseType, resolvedFieldIdPath);
		// Dialog eligibility used the pre-commit field.id. Same-scope moves are already covered by
		// rename validation; for a new parent scope, re-check the committed id set against destination siblings.
		const destinationPath = isTargetRepeatGroup ? `${newSectionId}.${committedFieldId}` : committedFieldId;
		if (destinationPath !== resolvedFieldIdPath) {
			const descriptors = configDescriptors.controlDescriptors ?? undefined;
			const siblingIds = getSiblingFieldIds(baseType, destinationPath, descriptors);
			if (getFieldIdSet(committedFieldId, field.type, descriptors).some((id) => siblingIds.includes(id))) {
				showAlert(formatMessage({ defaultMessage: 'That variable name is already in use.' }));
				// Rename may already be committed; keep the open form on the resolved id.
				if (resolvedFieldIdPath !== fieldIdPath) {
					handleFieldSelected(resolvedFieldIdPath, field, originSectionId, baseType);
				}
				return;
			}
		}
		if (isTargetRepeatGroup) {
			// For repeat groups as targets, newSectionId is the path of the selected repeating group
			const newFieldIdPath = `${newSectionId}.${committedFieldId}`;
			const fieldIdRoot = newFieldIdPath.split('.')[0];
			// Section where the field will be added (when moving to a repeat group, newSectionId is the path of the selected repeating group)
			const targetSectionId = baseType.sections.find((section) => section.fields.includes(fieldIdRoot)).id;
			let nextType = deleteField(baseType, resolvedFieldIdPath, originSectionId);
			nextType = addField(nextType, field, newFieldIdPath, targetSectionId, fieldIndex);
			setType(nextType);
			handleFieldSelected(newFieldIdPath, field, targetSectionId, nextType);
		} else {
			let nextType = deleteField(baseType, resolvedFieldIdPath, originSectionId);
			nextType = addField(nextType, field, field.id, newSectionId, fieldIndex);
			setType(nextType);
			handleFieldSelected(field.id, field, newSectionId, nextType);
		}
	};
	// region view/diff xml
	const openViewXml = (xml) => {
		setXmlViewerContent(xml);
		xmlViewerDialogState.onOpen();
	};
	const closeViewXml = () => {
		xmlViewerDialogState.onClose();
	};
	const openDiffXml = (initialContent, currentContent) => {
		setXmlDiffContent({ initialContent, currentContent });
		xmlDiffDialogState.onOpen();
	};
	const closeDiffXml = () => {
		xmlDiffDialogState.onClose();
	};
	// endregion
	// region reorder
	const handleReorderRepGroupFields = async (fields, fieldIdPath, sectionId) => {
		if (!(await performCurrentFormErrorCheckAndWarning())) return;
		onUpdateHasPendingChanges(true);
		// Commit open form edits first so the reorder runs on up-to-date type state.
		// commitOpenFormChanges clears the active form's changedFieldIds / formFieldsChanged
		// so a subsequent closeAndCleanup won't re-commit onto a stale type.
		const baseType = commitOpenFormChanges() ?? typeRef.current;
		// Field id may have changed during commit (rename); replace only the leaf of composed paths.
		const committedFieldId = stateRef.current.selectedField?.id ?? getIdFromIdPath(fieldIdPath);
		const resolvedFieldIdPath = replaceIdPathLeaf(fieldIdPath, committedFieldId);
		const nextType = reorderRepGroupFields(baseType, fields, resolvedFieldIdPath);
		setType(nextType);
		const field = getFieldFromType(nextType, resolvedFieldIdPath);
		handleFieldSelected(resolvedFieldIdPath, field, sectionId, nextType);
	};
	const handleReorderSectionFields = async (fields, sectionId) => {
		// Validate before committing so invalid forms leave type and dirty state unchanged.
		if (!(await performCurrentFormErrorCheckAndWarning())) return;
		onUpdateHasPendingChanges(true);
		// Commit open form edits first so the reorder runs on up-to-date type state.
		// commitOpenFormChanges clears the active form's changedFieldIds / formFieldsChanged
		// so a subsequent closeAndCleanup won't re-commit onto a stale type.
		const baseType = commitOpenFormChanges() ?? typeRef.current;
		// Dialog keys are pre-commit; replace any id missing from type.fields with the
		// committed selected field id (rename), preserving the requested order.
		const renamedId = stateRef.current.selectedField?.id;
		const nextType = reorderSectionFields(
			baseType,
			fields.map((f) => (baseType.fields[f.key] ? f : renamedId ? { ...f, key: renamedId } : f)),
			sectionId
		);
		setType(nextType);
		const openField = stateRef.current.selectedField;
		if (openField && selectedFieldIdPath) {
			// Field form still open: reopen with the committed path so it matches type.fields.
			const path = replaceIdPathLeaf(selectedFieldIdPath, openField.id);
			handleFieldSelected(path, getFieldFromType(nextType, path), fieldFormViewProps.sectionId, nextType);
		} else if (fieldFormViewProps?.section?.id === sectionId) {
			handleSectionSelected(getSectionFromType(nextType, sectionId), nextType);
		}
	};
	const handleReorderTypeSections = async (sections) => {
		if (!(await performCurrentFormErrorCheckAndWarning())) return;
		onUpdateHasPendingChanges(true);
		const baseType = commitOpenFormChanges() ?? typeRef.current;
		const nextType = reorderTypeSections(baseType, sections);
		setType(nextType);
		handleEditTypeProperties(nextType);
	};
	// endregion
	// `fieldUpdates$`: sync dirty via tap; debounce only background validation (no dirty side effects).
	useEffect(() => {
		const sub = stateRef.current.fieldUpdates$
			.pipe(
				// Track dirty synchronously from the active form's changedFieldIds so commit/save are not
				// gated on the validation debounce. Ignore emissions when no form is open (e.g. after close).
				tap(() => {
					if (!effectRefs.current.open) return;
					const formContext = stateRef.current.activeFormContext;
					const isDirty = formContext?.changedFieldIds ? jotai.get(formContext.changedFieldIds).size > 0 : false;
					stateRef.current.formFieldsChanged = isDirty;
					if (isDirty) {
						effectRefs.current.onUpdateHasPendingChanges(true);
					}
				}),
				debounceTime(500)
			)
			.subscribe(async () => {
				// Validation only — must not mark dirty; a queued emission from a previous form
				// must not flag the replacement form as changed.
				if (!effectRefs.current.open) return;
				const { fieldPathsWithErrors, selectedFieldIdPath, jotai } = effectRefs.current;
				// Capture the form and field path present when this debounced run starts so results
				// are discarded if either is replaced before validation resolves.
				const formContext = stateRef.current.activeFormContext;
				const originatingFieldPath = selectedFieldIdPath;
				const nextFieldPathsWithErrors = { ...fieldPathsWithErrors };
				const validationSeq = ++stateRef.current.validationSeq;
				const hasErrors = await validityAtomsHaveErrors(jotai, formContext?.atoms?.validationByFieldId);
				// `activeFormContext` is intentionally kept after close, so also re-check `open`.
				if (!effectRefs.current.open || stateRef.current.activeFormContext !== formContext) return;
				// A newer run for this same form started while awaiting; it owns the error state.
				if (validationSeq !== stateRef.current.validationSeq) return;
				// Selection moved while this form context was somehow retained; do not apply to the new path.
				if (effectRefs.current.selectedFieldIdPath !== originatingFieldPath) return;
				setActiveFormHasErrors(hasErrors);
				nextFieldPathsWithErrors[originatingFieldPath] = hasErrors;
				if (!nextFieldPathsWithErrors[originatingFieldPath]) delete nextFieldPathsWithErrors[originatingFieldPath];
				setFieldPathsWithErrors(nextFieldPathsWithErrors);
				// Live-sync draft thumbnailFileName while the type properties form is open,
				// so TypeCardMedia can reload by filename without waiting for form commit / save.
				const { selectedField, selectedSection, selectedDataSource } = stateRef.current;
				if (!selectedField && !selectedSection && !selectedDataSource && formContext) {
					const thumbnailAtom = formContext.atoms.valueByFieldId.thumbnailFileName;
					if (thumbnailAtom) {
						const thumbnailFileName = jotai.get(thumbnailAtom) || null;
						setType((current) =>
							current.thumbnailFileName === thumbnailFileName ? current : { ...current, thumbnailFileName }
						);
					}
				}
			});
		return () => {
			sub.unsubscribe();
		};
	}, [effectRefs]);
	useEffect(() => {
		if (type.NEW) {
			effectRefs.current.handleEditTypeProperties();
		}
	}, [type.NEW, effectRefs]);
	useEffect(() => {
		if (type.NEW) {
			setContentItem(null);
			return;
		}
		const sub = fetchContentItem(site, `${CONTENT_TYPES_BASE_PATH}${type.id}/form-definition.xml`).subscribe({
			next: setContentItem,
			error: () => setContentItem(null)
		});
		return () => sub.unsubscribe();
	}, [site, type.id, type.NEW, contentItemReloadToken]);
	useEffect(() => {
		const sub = fetchSiteUiConfig(site, activeEnvironment).subscribe({
			next: (config) => {
				const configDOM = fromString(config);
				const contentTypesConfigDOM = configDOM.querySelector(
					'widget[id="craftercms.components.ContentTypeManagement"] > configuration'
				);
				const contentTypesConfig = contentTypesConfigDOM ? deserialize(contentTypesConfigDOM).configuration : null;
				if (contentTypesConfig) {
					setConfig({
						controls: parseConfigPlugins(asArray(contentTypesConfig.controls?.control)),
						controlExclusions: asArray(contentTypesConfig.controlExclusions),
						dataSources: parseConfigPlugins(asArray(contentTypesConfig.dataSources?.dataSource)),
						dataSourceExclusions: asArray(contentTypesConfig.dataSourceExclusions)
					});
				}
			},
			error: ({ response }) => {
				dispatch(pushErrorDialog({ props: { error: response.response } }));
			}
		});
		return () => sub.unsubscribe();
	}, [site, activeEnvironment, setConfig, dispatch]);
	const disableSave = (!type.NEW && !hasPendingChanges) || Object.keys(fieldPathsWithErrors).length !== 0;
	return _jsxs(Provider, {
		store: jotai,
		children: [
			_jsx(EditTypeViewLayout, {
				sx: props.sx,
				ref: ref,
				style: props.style,
				open: open,
				onClose: handleCloseDrawer,
				disableSave: disableSave,
				mountMode: mountMode,
				onActionClick: handleToolbarActionClick,
				drawerContent: fieldEditorView,
				drawerProps: {
					// onTransitionEnd keeps triggering after the Drawer transition has finished on certain interactions (e.g. when hovering buttons)
					onTransitionEnd: (e) => {
						// Make sure it is the drawer paper that finished transitioning before considering the transition complete.
						// If 'EditTypeViewDrawer' transition ended, and 'open' is true, then the opening transition is complete.
						if (e.target.getAttribute('data-area-id') === 'EditTypeViewDrawer') {
							setDrawerOpenTransitionEnded(open);
						}
					},
					slotProps: {
						paper: {
							// @ts-expect-error Setting a html prop
							['data-area-id']: 'EditTypeViewDrawer'
						}
					}
				},
				mainContent: _jsx(TypeDetailsView, {
					type: type,
					contentItem: contentItem,
					onInsertSection: handleInsertSection,
					onOpenInsertFieldDialog: onOpenInsertFieldDialog,
					onOpenInsertDataSourceDialog: onOpenInsertDataSourceDialog,
					onEditTypeAction: handleEditTypeAction,
					onFieldSelected: handleFieldSelected,
					onDataSourceSelected: handleDataSourceSelected,
					onSectionSelected: handleSectionSelected,
					onReorderSectionFields: handleReorderSectionFields,
					fieldPathsWithErrors: fieldPathsWithErrors,
					selectedFieldIdPath: selectedFieldIdPath,
					performCurrentFormErrorCheckAndWarning: performCurrentFormErrorCheckAndWarning
				}),
				isNew: type.NEW
			}),
			_jsx(XmlViewerDialog, { xml: xmlViewerContent, open: xmlViewerDialogState.open, onClose: closeViewXml }),
			_jsx(XmlDiffDialog, {
				initialXml: xmlDiffContent?.initialContent,
				currentXml: xmlDiffContent?.currentContent,
				open: xmlDiffDialogState.open,
				onClose: closeDiffXml
			}),
			_jsx(PickControlDialog, {
				open: Boolean(insertFieldData.sectionId),
				type: type,
				sectionId: insertFieldData.sectionId,
				fieldIdPath: insertFieldData.fieldPath,
				onClose: () => setInsertFieldData({ sectionId: null }),
				onInsertField: handleInsertField,
				configControls: config?.controls,
				configDescriptors: configControlDescriptors,
				controlExclusions: config.controlExclusions
			}),
			_jsx(PickDataSourceDialog, {
				type: type,
				onInsert: handleInsertDataSource,
				open: openDataSourceInserter,
				onClose: () => setOpenDataSourceInserter(false),
				configDataSources: config?.dataSources,
				configDescriptors: configDataSourceDescriptors,
				dataSourceExclusions: config.dataSourceExclusions
			})
		]
	});
});
/** Fresh Type Builder edit state. `fieldUpdates$` is the internal stream the open form emits {@link FieldUpdate}s on. */
function createContextObject() {
	return {
		fieldUpdates$: new Subject(),
		formContextApi: createFieldFormContextApi(),
		activeFormContext: null,
		selectedField: null,
		selectedSection: null,
		selectedDataSource: null,
		formFieldsChanged: false,
		validationSeq: 0
	};
}
function getIdFromIdPath(idPath) {
	const pieces = idPath.split('.');
	return pieces.pop();
}
/** Replaces only the final segment of a (possibly composed) field id path. */
function replaceIdPathLeaf(idPath, newId) {
	const pieces = idPath.split('.');
	pieces[pieces.length - 1] = newId;
	return pieces.join('.');
}
function insertSection(type, section, position = 0) {
	const nextType = { ...type, sections: type.sections.concat() };
	nextType.sections.splice(position, 0, section);
	return nextType;
}
function deleteSection(type, section) {
	const nextType = { ...type, sections: type.sections.concat() };
	const sectionIndex = nextType.sections.findIndex((s) => s.id === section.id);
	nextType.sections.splice(sectionIndex, 1);
	return nextType;
}
function addSubField(parentField, newField, subFieldPath, position) {
	if (isComposedPath(subFieldPath)) {
		// If still composed, we need to find the root field and add the new field to it recursively
		const rootFieldId = subFieldPath.split('.').shift();
		return {
			...parentField,
			fields: {
				...(parentField.fields ?? {}),
				[rootFieldId]: addSubField(
					parentField.fields[rootFieldId],
					newField,
					subFieldPath.replace(`${rootFieldId}.`, ''),
					position
				)
			}
		};
	} else {
		// If not composed, we can add the field directly to the parent fields lookup.
		// Since the fields prop under a parentField is a lookupTable and we need to insert on a specific position, we first
		// convert it to an array, insert the new field and then convert it back to a lookupTable.
		const nextFieldsArray = Object.values(parentField.fields ?? {});
		nextFieldsArray.splice(position, 0, newField);
		const nextFields = {};
		nextFieldsArray.forEach((field) => {
			const fieldId = field.id ? field.id : NEW_FIELD_ID;
			nextFields[fieldId] = field;
		});
		return {
			...parentField,
			fields: nextFields
		};
	}
}
function addField(type, field, fieldIdPath, sectionId, position) {
	if (isComposedPath(fieldIdPath)) {
		// If the fieldIdPath is composed, we need to find the root field and add the new field to it recursively
		const rootFieldId = fieldIdPath.split('.').shift();
		// When fieldIdPath is composed (inside a rep-group), sections don't change since the root fields remain the same
		return {
			...type,
			fields: {
				...type.fields,
				[rootFieldId]: addSubField(
					type.fields[rootFieldId],
					field,
					fieldIdPath.replace(`${rootFieldId}.`, ''),
					position
				)
			}
		};
	} else {
		// If not composed, we can add the field directly to the fields lookup and to the sections list
		const nextFields = { ...type.fields, [fieldIdPath]: field };
		const nextSections = type.sections.concat();
		const sectionIndex = nextSections.findIndex((section) => section.id === sectionId);
		const section = nextSections[sectionIndex];
		const nextSectionFields = nextSections[sectionIndex].fields.concat();
		nextSectionFields.splice(position, 0, fieldIdPath);
		nextSections[sectionIndex] = {
			...section,
			fields: nextSectionFields
		};
		return { ...type, sections: nextSections, fields: nextFields };
	}
}
function deleteSubField(parentField, fieldIdPath) {
	if (isComposedPath(fieldIdPath)) {
		// If still composed, we need to find the root field and delete the field recursively
		const rootFieldId = fieldIdPath.split('.').shift();
		return {
			...parentField,
			fields: {
				...(parentField.fields ?? {}),
				[rootFieldId]: deleteSubField(parentField.fields[rootFieldId], fieldIdPath.replace(`${rootFieldId}.`, ''))
			}
		};
	} else {
		const nextFields = { ...(parentField.fields ?? {}) };
		delete nextFields[fieldIdPath];
		return { ...parentField, fields: nextFields };
	}
}
function deleteField(type, fieldIdPath, sectionId) {
	if (isComposedPath(fieldIdPath)) {
		// If the fieldIdPath is composed, we need to find the root field and remove the field recursively
		const rootFieldId = fieldIdPath.split('.').shift();
		// When fieldIdPath is composed (inside a rep-group), sections don't change since the root fields remain the same
		return {
			...type,
			fields: {
				...type.fields,
				[rootFieldId]: deleteSubField(type.fields[rootFieldId], fieldIdPath.replace(`${rootFieldId}.`, ''))
			}
		};
	} else {
		const nextFields = { ...type.fields };
		delete nextFields[fieldIdPath];
		const nextSections = type.sections.concat();
		const sectionIndex = nextSections.findIndex((section) => section.id === sectionId);
		if (sectionIndex !== -1) {
			const section = nextSections[sectionIndex];
			const nextSectionFields = section.fields.concat();
			const fieldIndex = nextSectionFields.findIndex((fieldId) => fieldId === fieldIdPath);
			if (fieldIndex !== -1) {
				nextSectionFields.splice(fieldIndex, 1);
				nextSections[sectionIndex] = {
					...section,
					fields: nextSectionFields
				};
			}
		}
		return { ...type, sections: nextSections, fields: nextFields };
	}
}
function updateTypeProps(type, updatedTypeDetails) {
	const newProps = pluckProps(updatedTypeDetails, ...typePropsToEdit);
	// If the sections property have not changed, retain the current type's sections to prevent unintentional
	// data loss (e.g., sections being set to 'undefined').
	if (!newProps.sections) {
		newProps.sections = type.sections;
	}
	return { ...type, ...newProps };
}
function updateTypeFromSubFieldUpdate(fields, state, updatedValues, fieldIdPath, descriptor) {
	if (isComposedPath(fieldIdPath)) {
		const rootFieldId = fieldIdPath.split('.').shift();
		return {
			...fields,
			[rootFieldId]: {
				...fields[rootFieldId],
				fields: updateTypeFromSubFieldUpdate(
					fields[rootFieldId].fields,
					state,
					updatedValues,
					fieldIdPath.replace(`${rootFieldId}.`, ''),
					descriptor
				)
			}
		};
	} else {
		const updatedField = reverseTypeFieldValuesObject(state.selectedField, updatedValues, descriptor);
		let updatedFields = { ...fields };
		// Drafts are keyed as `{NEW}` while `field.id` is still null — same as root-level updateTypeFromFieldUpdate.
		const selectedFieldId = state.selectedField.id || NEW_FIELD_ID;
		if (updatedField.id !== selectedFieldId) {
			// Replace in place (don't insert + delete): createLookupTable re-keys by field.id, so a
			// draft would become `null` and delete(`{NEW}`) would leave both entries.
			const updatedFieldsArray = Object.values(updatedFields);
			const originalFieldIndex = Object.keys(updatedFields).indexOf(selectedFieldId);
			updatedFieldsArray.splice(originalFieldIndex, 1, updatedField);
			updatedFields = updatedFieldsArray.reduce((lookup, field) => {
				lookup[field.id || NEW_FIELD_ID] = field;
				return lookup;
			}, {});
		} else {
			updatedFields[updatedField.id] = updatedField;
		}
		state.selectedField = updatedField;
		return updatedFields;
	}
}
function updateTypeFromFieldUpdate(type, state, updatedValues, fieldIdPath, configDescriptors) {
	if (!state.selectedField) return;
	const fieldType = state.selectedField.type;
	const descriptor = configDescriptors?.[fieldType] ?? controlDescriptors[fieldType];
	if (isComposedPath(fieldIdPath)) {
		// When the field is not on the root level (composed fieldIdPath), the field is under another field, where each
		// field contains a lookupTable of fields. In that screnario sections should not be updated.
		const rootFieldId = fieldIdPath.split('.').shift();
		return {
			...type,
			fields: {
				...type.fields,
				[rootFieldId]: {
					...type.fields[rootFieldId],
					fields: updateTypeFromSubFieldUpdate(
						type.fields[rootFieldId].fields,
						state,
						updatedValues,
						fieldIdPath.replace(`${rootFieldId}.`, ''),
						descriptor
					)
				}
			}
		};
	} else {
		const isNewField = state.selectedField.NEW;
		const selectedFieldId = isNewField ? NEW_FIELD_ID : state.selectedField.id;
		// If the field is on the root level, the edition is different since the structure of `type` has sections with the
		// fields (string array) and the lookupTable of the fields. Both properties need to be updated.
		const updatedType = { ...type, fields: { ...type.fields } };
		const updatedField = reverseTypeFieldValuesObject(state.selectedField, updatedValues, descriptor);
		updatedType.fields[updatedField.id] = updatedField;
		if (updatedField.id !== selectedFieldId) {
			// Delete the old id
			delete updatedType.fields[selectedFieldId];
			// Find the section in which the field is located
			const sectionIndex = updatedType.sections.findIndex((section) => section.fields.includes(selectedFieldId));
			const section = {
				...updatedType.sections[sectionIndex],
				fields: updatedType.sections[sectionIndex].fields.concat()
			};
			// Replace the field in the section
			const fieldIndex = section.fields.findIndex((fieldId) => fieldId === selectedFieldId);
			section.fields[fieldIndex] = updatedField.id;
			updatedType.sections = updatedType.sections.concat();
			updatedType.sections[sectionIndex] = section;
		}
		state.selectedField = updatedField;
		return updatedType;
	}
}
function updateTypeFromSectionUpdate(type, selectedSection, updatedValues) {
	const updatedType = { ...type, sections: type.sections.concat() };
	const index = updatedType.sections.findIndex((item) => item.id === selectedSection.id);
	updatedType.sections[index] = { ...selectedSection, ...updatedValues };
	return updatedType;
}
function updateTypeFromDataSourceUpdate(type, selectedDataSource, updatedValues, descriptor) {
	const updatedType = { ...type, dataSources: type.dataSources.concat() };
	const index = updatedType.dataSources.findIndex((item) => {
		if (selectedDataSource.id) {
			return item.id === selectedDataSource.id;
		} else {
			return item.NEW;
		}
	});
	const descriptorFields = descriptor?.fields ?? {};
	// Serialize datasource values
	const serializedValues = {};
	Object.entries(updatedValues).forEach(([key, value]) => {
		const field = descriptorFields[key];
		const fieldType = field?.type;
		const serializer = fieldType ? valueSerializersLookup[fieldType] : undefined;
		serializedValues[key] = serializer ? serializer(value, { field, contentTypesById: {} }) : value;
	});
	const nextDataSource = { ...selectedDataSource };
	// When updating a new data source, we need to exclude NEW prop from the new datasource content
	delete nextDataSource.NEW;
	const { title, id, plugin, ...properties } = serializedValues;
	updatedType.dataSources[index] = {
		...nextDataSource,
		id: id,
		title: title,
		properties,
		...(plugin ? { plugin: plugin } : {})
	};
	return updatedType;
}
function buildXmlFromType(type, configDescriptors) {
	const typeStructure = prepareSerializeToXmlTypeObject(type, configDescriptors);
	return buildContentTypeXml(typeStructure);
}
// merge the basic details, the non-edited field values, the manipulated field atoms into a single object
// that gets serialized to XML and stored
// `getType` is read when the write's turn comes, after any queued `<controller>` write for this type
// has landed, so the full definition carries the latest persisted flag instead of reverting it.
function save(siteId, typeId, getType, configDescriptors) {
	return queueFormDefinitionWrite(siteId, typeId, () => {
		const type = getType();
		let xml = buildXmlFromType(type, configDescriptors);
		xml = cleanupStaleDatasourceValuesFromXml(xml, type);
		const requests = [writeConfiguration(siteId, createFormDefinitionPathFromTypeId(type.id), 'studio', xml)];
		return forkJoin(requests).pipe(map(() => xml));
	});
}
/**
 * Checks if any of the validity atoms in the provided `atoms` object have errors.
 *
 * This function asynchronously evaluates the validity of all atoms by retrieving their values
 * using the `jotai.get` method. It then determines if any of the atoms are invalid based on their
 * `isValid` property.
 *
 * @async
 * @function
 * @param {JotaiStore} jotai - The Jotai store instance used to retrieve atom values.
 * @param {FormsEngineAtoms['validationByFieldId']} [atoms={}] - A lookup table of validation atoms by field ID.
 * @returns {Promise<boolean>} - Resolves to `true` if any atom is invalid, otherwise `false`.
 *
 */
async function validityAtomsHaveErrors(jotai, atoms = {}) {
	try {
		const results = await Promise.all(Object.values(atoms).map((atom) => jotai.get(atom)));
		return results.some((validity) => !validity.isValid);
	} catch (error) {
		console.error('Error checking field validity:', error);
		return true;
	}
}
function parseConfigPlugins(plugins) {
	if (!plugins) return {};
	const parsedPlugins = asArray(plugins).map((plugin) => {
		if (plugin.descriptor) {
			const fields = Object.values(plugin.descriptor.fields ?? {})?.map((field) => {
				return {
					...field,
					validations: field.validations ?? {}
				};
			});
			return {
				...plugin,
				descriptor: {
					...plugin.descriptor,
					metadata: {
						...plugin.descriptor.metadata,
						additionalFields: asArray(plugin.descriptor.metadata?.additionalFields)
					},
					fields: createLookupTable(fields),
					sections:
						asArray(plugin.descriptor?.sections).map((section) => ({
							...section,
							fields: asArray(section.fields) ?? []
						})) ?? []
				}
			};
		} else {
			return plugin;
		}
	});
	return createLookupTable(parsedPlugins);
}
function getNewFieldFromDescriptor(fieldType, descriptor, configEntry) {
	const newField = {
		NEW: true,
		id: systemFieldsIdsMap[fieldType] ?? null,
		name: '',
		helpText: '',
		description: '',
		type: systemFieldsTypesMap[fieldType] ?? fieldType,
		validations: {},
		defaultValue: '',
		properties: {}
	};
	if (!descriptor) return newField;
	if (descriptor.id === 'repeat') newField.fields = {};
	const { properties, validations } = getPropertiesAndValidationsFromDescriptor(descriptor);
	newField.properties = properties;
	newField.validations = validations;
	const plugin = extractPluginLocatorFromConfigEntry(configEntry);
	if (plugin) {
		Object.assign(newField.properties, { plugin });
	}
	return newField;
}
function getNewDataSourceFromDescriptor(dataSourceType, descriptor, configEntry) {
	const newDataSource = {
		NEW: true,
		id: '',
		title: '',
		type: dataSourceType,
		interface: '',
		properties: {}
	};
	if (!descriptor) return newDataSource;
	const sections = createLookupTable(descriptor.sections);
	newDataSource.interface = descriptor.type;
	const propertiesFieldIds = sections.properties?.fields ?? [];
	const properties = {};
	propertiesFieldIds.forEach((field) => (properties[field] = descriptor.fields[field]?.defaultValue));
	newDataSource.properties = properties;
	const plugin = extractPluginLocatorFromConfigEntry(configEntry);
	if (plugin) {
		newDataSource.plugin = plugin;
	}
	return newDataSource;
}
function extractPluginLocatorFromConfigEntry(configEntry) {
	if (!configEntry?.plugin || typeof configEntry.plugin !== 'object') return undefined;
	const raw = configEntry.plugin;
	// ui.xml attribute form: <plugin id type name fileName />; form-definition uses pluginId/filename.
	const type = raw.type;
	const name = raw.name;
	const filename = raw.filename ?? raw.fileName ?? raw.file;
	const pluginId = raw.pluginId ?? raw.id;
	if (
		typeof type === 'string' &&
		typeof name === 'string' &&
		typeof filename === 'string' &&
		typeof pluginId === 'string' &&
		type &&
		name &&
		filename &&
		pluginId
	) {
		return { type, name, filename, pluginId };
	}
	return undefined;
}
function reorderSectionFields(type, fields, sectionId) {
	const newFields = fields.map((field) => field.key);
	const nextSections = type.sections.map((section) => {
		if (section.id !== sectionId) return section;
		return {
			...section,
			fields: newFields
		};
	});
	return { ...type, sections: nextSections };
}
function reorderRepGroupSubFields(field, fields, subFieldPath) {
	if (isComposedPath(subFieldPath)) {
		const rootFieldId = subFieldPath.split('.').shift();
		return {
			...field,
			fields: {
				...field.fields,
				[rootFieldId]: reorderRepGroupSubFields(
					field.fields[rootFieldId],
					fields,
					subFieldPath.replace(`${rootFieldId}.`, '')
				)
			}
		};
	} else {
		const fieldsContainer = field.fields[subFieldPath];
		const newFields = fields.map(({ key }) => fieldsContainer.fields[key]);
		return {
			...field,
			fields: {
				...field.fields,
				[subFieldPath]: {
					...field.fields[subFieldPath],
					fields: createLookupTable(newFields)
				}
			}
		};
	}
}
function reorderRepGroupFields(type, fields, fieldIdPath) {
	if (isComposedPath(fieldIdPath)) {
		const rootFieldId = fieldIdPath.split('.').shift();
		return {
			...type,
			fields: {
				...type.fields,
				[rootFieldId]: reorderRepGroupSubFields(
					type.fields[rootFieldId],
					fields,
					fieldIdPath.replace(`${rootFieldId}.`, '')
				)
			}
		};
	} else {
		const fieldsContainer = type.fields[fieldIdPath];
		const newFields = fields.map(({ key }) => fieldsContainer.fields[key]);
		return {
			...type,
			fields: {
				...type.fields,
				[fieldIdPath]: {
					...type.fields[fieldIdPath],
					fields: createLookupTable(newFields)
				}
			}
		};
	}
}
/**
 * Cleans up stale datasource references in the provided XML string.
 *
 * This function parses the XML, finds all <type> elements whose text content starts with 'datasource:',
 * and then checks their sibling <value> elements. The <value> element contains a comma-separated list
 * of datasource IDs. Any IDs that do not exist in the current list of datasource IDs (from the type object)
 * are removed. If all IDs are invalid, the <value> element is cleared.
 *
 * @param {string} xml - The XML string to clean up.
 * @param {ContentType} type - The content type object containing the current list of datasource IDs.
 * @returns {string} - The cleaned XML string with only valid datasource references.
 */
function cleanupStaleDatasourceValuesFromXml(xml, type) {
	let cleanXml = xml;
	try {
		const dataSourceIds = (type.dataSources ?? []).map((ds) => ds.id);
		const dom = fromString(xml);
		const parseError = dom?.getElementsByTagName('parsererror')[0];
		if (dom && !parseError) {
			// Find all <type> elements
			const typeElements = Array.from(dom.getElementsByTagName('type'));
			for (const typeEl of typeElements) {
				const typeText = typeEl.textContent?.trim() ?? '';
				if (typeText.startsWith('datasource:')) {
					// Find sibling <value> element
					const parent = typeEl.parentElement;
					let valueEl = null;
					if (parent) {
						valueEl = parent.querySelector(':scope > value');
					}
					if (valueEl && valueEl.textContent) {
						const values = valueEl.textContent
							.split(',')
							.map((v) => v.trim())
							.filter(Boolean);
						const filtered = values.filter((id) => dataSourceIds.includes(id));
						if (filtered.length !== values.length) {
							if (filtered.length > 0) {
								valueEl.textContent = filtered.join(',');
							} else {
								valueEl.textContent = '';
							}
						}
					}
				}
			}
			cleanXml = serialize(dom);
		}
	} catch (e) {
		// If XML parsing fails, fallback to original xml (already set to xml at the beginning of the function)
		console.error('Error parsing XML for cleanup, returning original XML', e);
	}
	return cleanXml;
}
export default EditTypeView;
