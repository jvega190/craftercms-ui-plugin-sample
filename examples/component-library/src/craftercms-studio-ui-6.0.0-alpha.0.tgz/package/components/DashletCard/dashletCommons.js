/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { Fragment as _Fragment, jsx as _jsx, jsxs as _jsxs } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import { styled } from '@mui/material/styles';
import MuiList from '@mui/material/List';
import MuiListItemAvatar from '@mui/material/ListItemAvatar';
import Checkbox from '@mui/material/Checkbox';
import MuiCheckbox from '@mui/material/Checkbox';
import ListItemText from '@mui/material/ListItemText';
import Skeleton from '@mui/material/Skeleton';
import Typography from '@mui/material/Typography';
import { useCallback, useEffect } from 'react';
import MuiListItem from '@mui/material/ListItem';
import MuiListItemIcon from '@mui/material/ListItemIcon';
import MuiListSubheader from '@mui/material/ListSubheader';
import CheckRounded from '@mui/icons-material/CheckRounded';
import Box from '@mui/material/Box';
import { UNDEFINED } from '../../utils/constants';
import { getInitials, toColor } from '../../utils/string';
import Avatar from '@mui/material/Avatar';
import Select from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';
import { defineMessages, FormattedMessage, useIntl } from 'react-intl';
import { Pagination } from '../Pagination';
import { useDispatch } from 'react-redux';
import { getOffsetLeft, getOffsetTop } from '@mui/material/Popover';
import IconButton from '@mui/material/IconButton';
import MoreVertRoundedIcon from '@mui/icons-material/MoreVertRounded';
import Tooltip from '@mui/material/Tooltip';
import { getPersonFullName } from '../../utils/object';
import { showItemMegaMenu } from '../../state/actions/dialogs';
import useSpreadState from '../../hooks/useSpreadState';
import { ContextMenu } from '../ContextMenu';
import { generatePackageOptions, packageActionDispatcher } from '../../utils/packageActions';
import { LIVE_COLOUR, STAGING_COLOUR } from '../ItemPublishingTargetIcon/styles';
import { asLocalizedDateTime } from '../../utils/datetime';
import useLocale from '../../hooks/useLocale';
import { useTheme } from '@mui/material/styles';
export const actionsToBeShown = ['edit', 'delete', 'publish', 'requestPublish', 'dependencies', 'history'];
export const List = styled(MuiList)({ paddingTop: 0 });
export const ListSubheader = styled(MuiListSubheader)({ paddingLeft: 0, paddingRight: 0, lineHeight: 2 });
export const ListItem = styled(MuiListItem)({ padding: 0 });
export const ListItemIcon = styled(MuiListItemIcon)({ marginRight: 0 });
export const ListItemAvatar = styled(MuiListItemAvatar)({ minWidth: 50 });
export const DenseCheckbox = styled(MuiCheckbox)({ padding: '5px' });
export const DashletAvatar = styled(Avatar)({ width: 40, height: 40 });
export function PersonAvatar(props) {
	const { person, sx } = props;
	const backgroundColor = toColor(person.username);
	return _jsx(DashletAvatar, {
		src: person.avatar ?? UNDEFINED,
		children: person.avatar ? UNDEFINED : getInitials(person),
		sx: { backgroundColor, color: (theme) => theme.palette.getContrastText(backgroundColor), ...sx }
	});
}
export const getItemSkeleton = ({ numOfItems = 1, showCheckbox = false, showAvatar = false }) =>
	_jsx(List, {
		children: new Array(numOfItems).fill(null).map((nothing, index) =>
			_jsxs(
				ListItem,
				{
					sx: { pl: 2, pr: 2 },
					children: [
						showCheckbox && _jsx(ListItemIcon, { children: _jsx(Checkbox, { edge: 'start', disabled: true }) }),
						showAvatar && _jsx(ListItemAvatar, { children: _jsx(DashletAvatar, {}) }),
						_jsx(ListItemText, {
							primary: _jsx(Skeleton, { variant: 'text' }),
							secondary: _jsx(Typography, {
								variant: 'body2',
								sx: {
									color: 'text.secondary'
								},
								children: _jsx(Skeleton, { variant: 'text' })
							})
						})
					]
				},
				index
			)
		)
	});
export const DashletEmptyMessage = ({ children, sx }) =>
	_jsxs(Box, {
		sx: {
			display: 'flex',
			flexDirection: 'column',
			alignItems: 'center',
			mt: 2,
			...sx
		},
		children: [
			_jsx(CheckRounded, { sx: { color: 'success.main', mb: 1 } }),
			_jsx(Typography, {
				variant: 'body2',
				sx: {
					color: 'text.secondary'
				},
				children: children
			})
		]
	});
export function PersonFullName({ person }) {
	return _jsx(Typography, { variant: 'h6', children: getPersonFullName(person) });
}
export function Pager(props) {
	const { totalPages, totalItems, currentPage, rowsPerPage, onPagePickerChange, onPageChange, onRowsPerPageChange } =
		props;
	const { formatMessage } = useIntl();
	return _jsxs(_Fragment, {
		children: [
			_jsx(Select, {
				variant: 'standard',
				disableUnderline: true,
				value: `${currentPage}`,
				onChange: (e) => onPagePickerChange(parseInt(e.target.value)),
				inputProps: {
					// "Page N" is the closed select's value, not its label, so the name stays the word Page.
					'aria-label': formatMessage({ id: 'words.page', defaultMessage: 'Page' })
				},
				sx: { fontSize: (theme) => theme.typography.fontSize },
				children: new Array(totalPages)
					.fill(null)
					.map((nothing, index) =>
						_jsx(
							MenuItem,
							{
								value: index,
								sx: { fontSize: (theme) => theme.typography.fontSize },
								children:
									currentPage === index
										? _jsx(FormattedMessage, { defaultMessage: 'Page {pageNumber}', values: { pageNumber: index + 1 } })
										: _jsx(FormattedMessage, {
												defaultMessage: 'Go to page {pageNumber}',
												values: { pageNumber: index + 1 }
											})
							},
							index
						)
					)
			}),
			_jsx(Pagination, {
				count: totalItems,
				onPageChange: (e, page) => onPageChange(page),
				page: currentPage,
				rowsPerPage: rowsPerPage,
				onRowsPerPageChange: (e) => onRowsPerPageChange(parseInt(e.target.value)),
				mode: 'table'
			})
		]
	});
}
/**
 * Styles for a dashlet row that selects itself when clicked. The row is not a button: the checkbox inside it is the
 * keyboard (and assistive technology) way to select, so the click is a pointer convenience. Making the row a button
 * would nest the checkbox and the row's other controls inside it (axe `nested-interactive`).
 */
export const dashletSelectableRowSx = {
	pt: 0,
	pb: 0,
	cursor: 'pointer',
	'&:hover': { bgcolor: 'action.hover' }
};
/**
 * Hides a dashlet options button until its row is hovered, while keeping it available to keyboard focus and to touch
 * (or any coarse or hover-less pointer). `pointer-events: none` stops a hidden button from taking the row's click; the
 * button stays in the tab order.
 */
export const getDashletRevealOnHoverSx = (visible) => ({
	opacity: visible ? 1 : 0,
	pointerEvents: visible ? 'auto' : 'none',
	'&:focus-visible': { opacity: 1, pointerEvents: 'auto' },
	'@media (hover: none), (any-pointer: coarse)': { opacity: 1, pointerEvents: 'auto' }
});
export function DashletItemOptions(props) {
	const { path, iconButtonProps } = props;
	const dispatch = useDispatch();
	const { formatMessage } = useIntl();
	const onOpenItemMegaMenu = (element) => {
		const anchorRect = element.getBoundingClientRect();
		const top = anchorRect.top + getOffsetTop(anchorRect, 'top');
		const left = anchorRect.left + getOffsetLeft(anchorRect, 'left');
		dispatch(
			showItemMegaMenu({
				path,
				anchorReference: 'anchorPosition',
				anchorPosition: { top, left }
			})
		);
	};
	return _jsx(Tooltip, {
		title: formatMessage({ defaultMessage: 'Options' }),
		children: _jsx(IconButton, {
			size: 'small',
			onClick: (e) => {
				e.stopPropagation();
				onOpenItemMegaMenu(e.currentTarget);
			},
			'aria-label': formatMessage({ defaultMessage: 'Options' }),
			...iconButtonProps,
			children: _jsx(MoreVertRoundedIcon, {})
		})
	});
}
export function usePackageContextMenu() {
	const [contextMenu, setContextMenu] = useSpreadState({
		el: null,
		package: null,
		options: []
	});
	const { formatMessage } = useIntl();
	const dispatch = useDispatch();
	const position = contextMenu.el?.getBoundingClientRect();
	const theme = useTheme();
	const transitionDuration = theme.transitions.duration.standard;
	const handleContextMenuClick = useCallback(
		(e, publishPackage) => {
			const options = generatePackageOptions([publishPackage], {
				includeOnly: ['view', 'resubmit']
			}).map((option) => ({
				id: option.id,
				label: formatMessage(option.label)
			}));
			setContextMenu({ el: e.currentTarget, package: publishPackage, options });
		},
		[formatMessage, setContextMenu]
	);
	const handleContextMenuClose = useCallback(() => {
		setContextMenu({
			el: null,
			package: null
		});
	}, [setContextMenu]);
	const handleOptionClicked = useCallback(
		(option, pkg) => {
			handleContextMenuClose();
			packageActionDispatcher({
				pkg,
				option,
				dispatch
			});
		},
		[dispatch, handleContextMenuClose]
	);
	useEffect(() => {
		if (!contextMenu.el) {
			// If contextMenu.el is null (meaning the menu is closed), clear the options after the transition has ended.
			// This is done to prevent the 'No options available' to show while closing the menu (if options is cleared at the same time as el).
			const timeout = setTimeout(() => {
				setContextMenu({
					options: []
				});
			}, transitionDuration);
			return () => clearTimeout(timeout);
		}
	}, [contextMenu.el, setContextMenu, transitionDuration]);
	const contextMenuElement = _jsx(ContextMenu, {
		open: Boolean(contextMenu.el),
		anchorReference: 'anchorPosition',
		anchorPosition: { top: position?.bottom ?? 0, left: position?.left ?? 0 },
		onClose: handleContextMenuClose,
		options: [contextMenu.options],
		onMenuItemClicked: (option) => handleOptionClicked(option, contextMenu.package),
		transitionDuration: transitionDuration
	});
	return {
		contextMenu,
		openContextMenu: handleContextMenuClick,
		closeContextMenu: handleContextMenuClose,
		setContextMenu,
		contextMenuElement
	};
}
const submittedPackageDetailMessages = defineMessages({
	staging: { id: 'words.staging', defaultMessage: 'Staging' },
	live: { id: 'words.live', defaultMessage: 'Live' }
});
/**
 * Displays details about a submitted package, including the submitter's name,
 * the publishing target (live or staging), and the submission date.
 *
 * @param {Object} props - The component props.
 * @param {PublishPackage} props.pkg - The package data containing submission details.
 */
export function SubmittedPackageDetail({ pkg }) {
	const { formatMessage } = useIntl();
	const locale = useLocale();
	return _jsx(FormattedMessage, {
		defaultMessage:
			'Submitted by {name} to go {publishingTarget, select, live { <render_target>live</render_target>} other {<render_target>staging</render_target>}} on {submittedDate}',
		values: {
			name: pkg.submitter?.username,
			publishingTarget: pkg.target,
			render_target(target) {
				return _jsx(Box, {
					component: 'span',
					sx: {
						color: target[0] === 'live' ? LIVE_COLOUR : STAGING_COLOUR
					},
					children: submittedPackageDetailMessages[target[0]]
						? formatMessage(submittedPackageDetailMessages[target[0]]).toLowerCase()
						: target[0]
				});
			},
			submittedDate: asLocalizedDateTime(
				pkg.schedule ?? pkg.submittedOn,
				locale.localeCode,
				locale.dateTimeFormatOptions
			)
		}
	});
}
