/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import { useState } from 'react';
import { useIntl } from 'react-intl';
import Box from '@mui/material/Box';
import ListItemAvatar from '@mui/material/ListItemAvatar';
import Avatar from '@mui/material/Avatar';
import DragIndicatorRounded from '@mui/icons-material/DragIndicatorRounded';
import ListItemText from '@mui/material/ListItemText';
import IconButton from '@mui/material/IconButton';
import MoreVertRounded from '@mui/icons-material/MoreVertRounded';
import { darken, useTheme } from '@mui/material/styles';
import { getAvatarWithIconColors } from '../../utils/contentType';
export function DraggablePanelListItem(props) {
	const {
		onMenu,
		primaryText,
		avatarSrc,
		avatarColorBase,
		secondaryText,
		onDragStart,
		onDragEnd,
		isBeingDragged = false
	} = props;
	const hasMenu = Boolean(onMenu);
	const theme = useTheme();
	const { formatMessage } = useIntl();
	const { backgroundColor, textColor } = getAvatarWithIconColors(avatarColorBase ?? primaryText, theme, darken);
	const [over, setOver] = useState(false);
	return _jsxs(Box, {
		component: 'li',
		onMouseEnter: () => setOver(true),
		onMouseLeave: () => setOver(false),
		sx: {
			display: 'flex',
			alignItems: 'center',
			border: `1px solid ${isBeingDragged ? backgroundColor : 'transparent'}`,
			borderRadius: isBeingDragged ? 2 : 0
		},
		children: [
			_jsxs(Box, {
				draggable: true,
				onDragStart: onDragStart,
				onDragEnd: onDragEnd,
				sx: (theme) => ({
					display: 'flex',
					alignItems: 'center',
					flex: 1,
					minWidth: 0,
					py: 1,
					pl: 1.5,
					pr: 2,
					cursor: isBeingDragged ? 'grabbing' : 'grab',
					transition: theme.transitions.create('background-color', { duration: theme.transitions.duration.shortest }),
					'&:hover': { backgroundColor: theme.palette.action.hover }
				}),
				children: [
					_jsx(ListItemAvatar, {
						sx: { minWidth: 0 },
						children: _jsx(Avatar, {
							alt: '',
							src: avatarSrc,
							sx: {
								mr: 1.5,
								width: 30,
								height: 30,
								backgroundColor: over || avatarSrc ? 'transparent' : backgroundColor,
								transition: 'background-color 0.25s ease-in-out'
							},
							children: _jsx(DragIndicatorRounded, {
								fontSize: 'small',
								sx: {
									color: over ? backgroundColor : textColor,
									transition: 'color 0.25s ease-in-out'
								}
							})
						})
					}),
					_jsx(ListItemText, { primary: primaryText, secondary: secondaryText })
				]
			}),
			hasMenu &&
				_jsx(Box, {
					sx: { display: 'flex', flexShrink: 0, mr: 0.5 },
					children: _jsx(IconButton, {
						onClick: onMenu,
						size: 'small',
						'aria-label': formatMessage({ defaultMessage: 'Options for {name}' }, { name: primaryText }),
						children: _jsx(MoreVertRounded, {})
					})
				})
		]
	});
}
export default DraggablePanelListItem;
