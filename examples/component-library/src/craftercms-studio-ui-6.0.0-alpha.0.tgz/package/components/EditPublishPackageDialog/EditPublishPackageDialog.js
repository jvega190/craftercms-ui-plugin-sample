/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx } from 'react/jsx-runtime';
import { FormattedMessage } from 'react-intl';
import EnhancedDialog from '../EnhancedDialog';
import { EditPublishPackageDialogContainer } from './EditPublishPackageDialogContainer';
export function EditPublishPackageDialog(props) {
	const { pkg, isSubmitting, onSuccess, ...rest } = props;
	return _jsx(EnhancedDialog, {
		title: _jsx(FormattedMessage, { defaultMessage: 'Edit Publishing Package' }),
		maxWidth: 'lg',
		...rest,
		isSubmitting: isSubmitting,
		children: _jsx(EditPublishPackageDialogContainer, { pkg: pkg, onSuccess: onSuccess, isSubmitting: isSubmitting })
	});
}
export default EditPublishPackageDialog;
