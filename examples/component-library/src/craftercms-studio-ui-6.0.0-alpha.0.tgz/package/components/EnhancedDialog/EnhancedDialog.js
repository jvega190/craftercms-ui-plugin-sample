/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import * as React from 'react';
import { useId, useMemo, useRef } from 'react';
import { useOnClose } from '../../hooks/useOnClose';
import MuiDialog from '@mui/material/Dialog';
import { useUnmount } from '../../hooks/useUnmount';
import DialogHeader from '../DialogHeader';
import MinimizedBar from '../MinimizedBar';
import { EnhancedDialogContext } from './useEnhancedDialogContext';
import Suspencified from '../Suspencified';
import useUpdateRefs from '../../hooks/useUpdateRefs';
/**
 * Adds the dialog's labelling props to the caller's paper slot. The caller's own props win, so a slot that
 * already names the dialog keeps its name. A function slot is resolved first, so its label is seen too.
 */
function withPaperProps(paper, getProps) {
	if (typeof paper === 'function') {
		return (ownerState) => {
			const resolved = paper(ownerState);
			return { ...getProps(resolved), ...resolved };
		};
	}
	return { ...getProps(paper), ...paper };
}
export function EnhancedDialog(props) {
	// region const { ... } = props
	const {
		open,
		isSubmitting = false,
		hasPendingChanges = false,
		isMinimized = false,
		isFullScreen = false,
		title,
		subtitle,
		onClosed,
		onMinimize,
		onMaximize,
		onWithPendingChangesCloseRequest,
		updateSubmittingOrHasPendingChanges,
		children,
		dialogHeaderProps,
		omitHeader = false,
		'aria-label': ariaLabel,
		'aria-labelledby': ariaLabelledBy,
		slotProps,
		onFullScreen,
		onCancelFullScreen,
		...dialogProps
	} = props;
	// endregion
	const id = useId();
	const titleId = dialogHeaderProps?.titleId ?? dialogHeaderProps?.titleTypographyProps?.id ?? `${id}-title`;
	const headerTitle = title ?? dialogHeaderProps?.title;
	// Naming the dialog by its title only works while the title element holds text, so a dialog whose header
	// is omitted or has no title is left unnamed instead of pointing at an element that is not rendered.
	const hasTitle = headerTitle != null && typeof headerTitle !== 'boolean' && headerTitle !== '';
	const canUseTitle = !omitHeader && hasTitle;
	// MUI hands its aria-labelledby to its DialogContext, where a MUI DialogTitle (e.g. the one plugins get as
	// `craftercms.components.DialogTitle`) takes its id from. That id must not be the DialogHeader's title id,
	// or a DialogTitle in a dialog with a header would duplicate it.
	const muiTitleId = `${id}-dialog-title`;
	// MUI puts a top-level aria-label on the root instead of the element with the role, so a caller's name is
	// read from either place and lands on the paper, next to aria-labelledby.
	const getLabelling = (paper) => {
		const callerLabel = ariaLabel || paper?.['aria-label'];
		const callerLabelledBy = ariaLabelledBy || paper?.['aria-labelledby'];
		// An omitted header with no caller label keeps MUI's own reference, so a DialogTitle rendered by the
		// caller still names the dialog.
		const labelledBy =
			callerLabelledBy ?? (callerLabel ? undefined : canUseTitle ? titleId : omitHeader ? muiTitleId : undefined);
		return { callerLabel, labelledBy };
	};
	const staticPaper = typeof slotProps?.paper === 'function' ? undefined : slotProps?.paper;
	const dialogLabelledBy = ariaLabelledBy || staticPaper?.['aria-labelledby'] || muiTitleId;
	const getPaperOverrides = (paper) => {
		const { callerLabel, labelledBy } = getLabelling(paper);
		const overrides = {};
		if (labelledBy !== dialogLabelledBy) overrides['aria-labelledby'] = labelledBy;
		if (callerLabel) overrides['aria-label'] = callerLabel;
		return overrides;
	};
	const resolvedSlotProps =
		typeof slotProps?.paper === 'function' || Object.keys(getPaperOverrides(staticPaper)).length
			? { ...slotProps, paper: withPaperProps(slotProps?.paper, getPaperOverrides) }
			: slotProps;
	const onClose = useOnClose({
		onClose(e, reason) {
			if (hasPendingChanges) {
				onWithPendingChangesCloseRequest?.(e, reason);
			} else if (!isSubmitting) {
				dialogProps.onClose?.(e, reason);
			}
		},
		disableBackdropClick: isSubmitting,
		disableEscapeKeyDown: isSubmitting
	});
	const callbackRefs = useUpdateRefs({ onClose, updateSubmittingOrHasPendingChanges });
	const stableRefs = useRef({
		// When context is recreated, `stableRefs` remain stable and won't trigger
		// effects or have closure issues on the consumer components.
		onClose(e, reason) {
			callbackRefs.current.onClose?.(e, reason);
		},
		updateSubmittingOrHasPendingChanges(changes) {
			callbackRefs.current.updateSubmittingOrHasPendingChanges?.(changes);
		}
	});
	const context = useMemo(
		() => ({
			open,
			isMinimized,
			isFullScreen,
			isSubmitting,
			hasPendingChanges,
			onClose: stableRefs.current.onClose,
			updateSubmittingOrHasPendingChanges: stableRefs.current.updateSubmittingOrHasPendingChanges
		}),
		[hasPendingChanges, isFullScreen, isMinimized, isSubmitting, open]
	);
	return _jsxs(EnhancedDialogContext.Provider, {
		value: context,
		children: [
			_jsxs(MuiDialog, {
				open: open && !isMinimized,
				keepMounted: isMinimized,
				fullWidth: true,
				maxWidth: 'md',
				fullScreen: isFullScreen,
				...dialogProps,
				'aria-labelledby': dialogLabelledBy,
				slotProps: resolvedSlotProps,
				onClose: onClose,
				children: [
					!omitHeader &&
						_jsx(DialogHeader, {
							...dialogHeaderProps,
							titleId: titleId,
							title: headerTitle,
							subtitle: subtitle ?? dialogHeaderProps?.subtitle,
							disabled: isSubmitting,
							onMinimizeButtonClick: onMinimize,
							onFullScreenButtonClick: isFullScreen ? onCancelFullScreen : onFullScreen,
							onCloseButtonClick: (e) => onClose(e, null)
						}),
					_jsx(Suspencified, {
						children: React.Children.map(children, (child) => React.cloneElement(child, { onClose }))
					}),
					_jsx(OnClosedInvoker, { onClosed: onClosed })
				]
			}),
			_jsx(MinimizedBar, { open: isMinimized, onMaximize: onMaximize, title: title })
		]
	});
}
export default EnhancedDialog;
function OnClosedInvoker({ onClosed }) {
	useUnmount(onClosed);
	return null;
}
