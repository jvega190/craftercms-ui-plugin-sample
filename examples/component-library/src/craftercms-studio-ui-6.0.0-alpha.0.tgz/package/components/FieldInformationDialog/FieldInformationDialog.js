/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs } from 'react/jsx-runtime';
import { EnhancedDialog } from '../EnhancedDialog';
import { FormattedMessage, useIntl } from 'react-intl';
import Grid from '@mui/material/Grid';
import Typography from '@mui/material/Typography';
import { commonControlFieldsDescriptors } from '../ContentTypeManagement/descriptors/controls/commonDescriptors';
import { getPossibleTranslation } from '../../utils/i18n';
import Box from '@mui/material/Box';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import { Chip } from '@mui/material';
import inputDescriptor from '../ContentTypeManagement/descriptors/controls/input';
import { nnou } from '../../utils/object';
import useSelection from '../../hooks/useSelection';
import { resolveControlDescriptors } from '../FormsEngine/lib/formUtils';
import { controlTypeLabel } from './controlTypeLabel';
const basicPropsMap = {
	help: 'helpText',
	title: 'name'
};
export function FieldInformationDialog(props) {
	const { field, ...rest } = props;
	return _jsx(EnhancedDialog, {
		maxWidth: 'sm',
		title: _jsx(FormattedMessage, { defaultMessage: 'Field Information' }),
		...rest,
		children: _jsx(Body, { field: field })
	});
}
export default FieldInformationDialog;
function Body(props) {
	const { field } = props;
	const { formatMessage } = useIntl();
	const customControls = useSelection((state) => state.uiConfig.controls);
	const descriptors = resolveControlDescriptors(customControls);
	const typeLabel = controlTypeLabel(field.type, descriptors);
	// One lookup for the type name and the property sections. Input is only the stand-in when nothing matches.
	const descriptor = descriptors[field.type] ?? inputDescriptor;
	return _jsxs(Box, {
		sx: { p: 2, gap: 2, display: 'flex', flexDirection: 'column' },
		children: [
			_jsx(Card, {
				children: _jsxs(CardContent, {
					children: [
						_jsx(Typography, {
							variant: 'subtitle1',
							sx: {
								fontWeight: 'bold'
							},
							children: _jsx(FormattedMessage, { defaultMessage: 'Basic Properties' })
						}),
						_jsxs(Grid, {
							container: true,
							spacing: 2,
							sx: { mt: 0.5 },
							children: [
								_jsx(Grid, {
									size: { xs: 4 },
									children: _jsx(Typography, {
										sx: { color: 'text.secondary' },
										children: _jsx(FormattedMessage, { defaultMessage: 'Type' })
									})
								}),
								_jsx(Grid, {
									size: { xs: 8 },
									children: _jsx(Typography, { children: getPossibleTranslation(typeLabel, formatMessage) })
								})
							]
						}),
						Object.values(commonControlFieldsDescriptors).map((descriptor) => {
							const value = field[basicPropsMap[descriptor.id] ?? descriptor.id];
							const renderHtml = descriptor.id === 'help';
							return _jsxs(
								Grid,
								{
									container: true,
									spacing: 2,
									sx: { mt: 0.5 },
									children: [
										_jsx(Grid, {
											size: { xs: 4 },
											children: _jsx(Typography, {
												sx: {
													color: 'text.secondary'
												},
												children: getPossibleTranslation(descriptor.name, formatMessage)
											})
										}),
										_jsx(Grid, {
											size: { xs: 8 },
											children: renderHtml
												? _jsx(Typography, { component: 'section', dangerouslySetInnerHTML: { __html: value ?? '-' } })
												: _jsx(Typography, { children: nnou(value) && value !== '' ? value : '-' })
										})
									]
								},
								descriptor.id
							);
						})
					]
				})
			}),
			descriptor.sections?.map((section, index) =>
				_jsx(
					Card,
					{
						children: _jsxs(CardContent, {
							children: [
								_jsx(Typography, {
									variant: 'subtitle1',
									sx: {
										fontWeight: 'bold'
									},
									children: getPossibleTranslation(section.title, formatMessage)
								}),
								section.fields?.map((fieldName) => {
									let value = field.properties?.[fieldName]?.value ?? field.validations?.[fieldName]?.value;
									if (typeof value === 'boolean') {
										value = value
											? _jsx(Chip, { label: 'true', color: 'success', size: 'small' })
											: _jsx(Chip, { label: 'false', color: 'default', size: 'small' });
									}
									return _jsxs(
										Grid,
										{
											container: true,
											spacing: 2,
											sx: { mt: 0.5 },
											children: [
												_jsx(Grid, {
													size: { xs: 4 },
													children: _jsx(Typography, {
														sx: {
															color: 'text.secondary'
														},
														children: getPossibleTranslation(
															descriptor.fields?.[fieldName]?.name ?? fieldName,
															formatMessage
														)
													})
												}),
												_jsx(Grid, {
													size: { xs: 8 },
													children: _jsx(Typography, { children: nnou(value) && value !== '' ? value : '-' })
												})
											]
										},
										fieldName
									);
								})
							]
						})
					},
					`${section.title}_${index}`
				)
			)
		]
	});
}
