/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { Fragment as _Fragment, jsx as _jsx, jsxs as _jsxs } from 'react/jsx-runtime';
import CheckRounded from '@mui/icons-material/CheckRounded';
import WarningAmberRounded from '@mui/icons-material/WarningAmberRounded';
import Box from '@mui/material/Box';
import Tooltip from '@mui/material/Tooltip';
import { visuallyHidden } from '@mui/utils';
import { useAtomValue } from 'jotai';
import { useIntl } from 'react-intl';
import Asterisk from '../../../icons/Asterisk';
import { XmlKeys } from '../lib/formConsts';
import useLoadableAtom from '../lib/useLoadableAtom';
import { hasFieldValidator, hasValidationKeyValidator, isFieldRequired, isFieldValueEmpty } from '../lib/validators';
import { translateValidityMessage } from './FieldValidityMessages';
const iconByKind = {
	complete: CheckRounded,
	required: Asterisk,
	invalid: WarningAmberRounded
};
/**
 * Where the asterisk sits on each icon. `em` is the icon font size (the small icon, 20px in the label),
 * so a 16px table-of-contents icon keeps the same proportions.
 * The check's +0.15em drops the asterisk into its upper-left notch. The triangle's -0.02em is just inside
 * the left edge: -0.05em clears the apex but crowds the label.
 */
const badgeOffset = {
	success: { left: '0.1em', top: '0.15em' },
	error: { left: '-0.02em', top: '0em' }
};
/** Asterisk in the icon's empty upper-left. Size and nudge are fractions of the icon, so 16px and 20px share one placement. */
function badgeSx(color) {
	const offset = badgeOffset[color];
	return (theme) => ({
		position: 'absolute',
		width: '52%',
		height: '52%',
		left: offset.left,
		top: offset.top,
		transform: 'translate(0, -28%)',
		color: theme.palette[color].main,
		overflow: 'visible',
		pointerEvents: 'none',
		'& path': {
			stroke: theme.palette.background.paper,
			strokeWidth: 2,
			paintOrder: 'stroke',
			strokeLinejoin: 'round'
		}
	});
}
function RequiredBadge({ color, children }) {
	return _jsxs(Box, {
		component: 'span',
		sx: { display: 'inline-flex', position: 'relative', lineHeight: 0 },
		children: [children, _jsx(Asterisk, { 'aria-hidden': true, fontSize: 'small', sx: badgeSx(color) })]
	});
}
function fieldStateKind({ isValid, isRequired, isEmpty }) {
	// A check when the value passes. An asterisk only for a required field that is still empty.
	// Any other failure uses the warning triangle. A filled required field adds the asterisk badge.
	if (isValid) return 'complete';
	if (isRequired && isEmpty) return 'required';
	return 'invalid';
}
/**
 * The value and validation atoms the table of contents reads for `fieldId`.
 * `file-name` is the dedicated filename atom. A missing atom is left missing so the caller can skip the row.
 */
export function fieldIndicatorAtoms(fieldId, atoms) {
	return {
		valueAtom: fieldId === XmlKeys.fileName ? atoms.fileName : atoms.valueByFieldId[fieldId],
		validationAtom: atoms.validationByFieldId[fieldId]
	};
}
/**
 * The same required / validator / valid / empty values for a field label and its table-of-contents row.
 * While validation is still loading, the field counts as valid, matching the previous indicator.
 * `options.isValid` is only for the label that passes it. The table of contents calls this without it.
 */
export function useFieldStateIndicatorProps(field, atoms, options) {
	const { valueAtom, validationAtom } = fieldIndicatorAtoms(field.id, atoms);
	const value = useAtomValue(valueAtom ?? atoms.valueByFieldId[field.id]);
	const validityData = useLoadableAtom(validationAtom);
	// Loading counts as valid, matching the previous indicator. A failed validation run is not a pass.
	const derivedValid =
		validityData.state === 'hasData' ? Boolean(validityData.data?.isValid) : validityData.state !== 'hasError';
	// `options.isValid` is the label override. Undefined keeps the atom's verdict.
	const isValid = options?.isValid ?? derivedValid;
	const detail = validityData.state === 'hasData' ? validityData.data?.messages?.[0] : undefined;
	return {
		loading: validityData.state === 'loading',
		value,
		validityData,
		props: {
			isRequired: isFieldRequired(field),
			hasValidator: hasFieldValidator(field.type) || hasValidationKeyValidator(field),
			isValid,
			isEmpty: isFieldValueEmpty(field, value),
			detail
		}
	};
}
function stateWords(kind, isRequired, detail, formatMessage) {
	if (kind === 'required') return formatMessage({ defaultMessage: 'Required' });
	if (kind === 'complete' && isRequired) return formatMessage({ defaultMessage: 'Required, complete' });
	if (kind === 'complete') return formatMessage({ defaultMessage: 'Complete' });
	if (isRequired && detail) return formatMessage({ defaultMessage: 'Required. {detail}' }, { detail });
	if (isRequired) return formatMessage({ defaultMessage: 'Required. Invalid' });
	return formatMessage({ defaultMessage: 'Invalid' });
}
export function FieldStateIndicator({ isRequired, hasValidator, isValid, isEmpty, detail, announce = true }) {
	const { formatMessage } = useIntl();
	// If there is no requirement and no validator, and the field is empty, do not show any indicator
	if (!isRequired && !hasValidator && isEmpty) return undefined;
	const kind = fieldStateKind({ isRequired, hasValidator, isValid, isEmpty });
	const color = kind === 'complete' ? 'success' : 'error';
	const Icon = iconByKind[kind];
	const icon = _jsx(Icon, { fontSize: 'small', color: color, 'aria-hidden': true });
	// The full asterisk is the empty-required state. A filled required field keeps a small asterisk on that icon.
	const marked = isRequired && kind !== 'required';
	const detailText = detail ? translateValidityMessage(detail, formatMessage) : undefined;
	const words = stateWords(kind, isRequired, detailText, formatMessage);
	return _jsx(Tooltip, {
		title: _jsx(_Fragment, { children: words }),
		children: _jsxs(Box, {
			component: 'span',
			sx: {
				display: 'inline-flex',
				alignItems: 'center',
				verticalAlign: 'middle',
				lineHeight: 0,
				// Room so the badge, which sits in the icon's corner, does not meet the last letter.
				ml: 0.5
			},
			children: [
				marked ? _jsx(RequiredBadge, { color: color, children: icon }) : icon,
				announce && _jsxs(Box, { component: 'span', sx: visuallyHidden, children: [', ', words] })
			]
		})
	});
}
export default FieldStateIndicator;
