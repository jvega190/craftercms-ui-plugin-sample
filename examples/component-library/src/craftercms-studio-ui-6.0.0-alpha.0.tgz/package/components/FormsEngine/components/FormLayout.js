/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2025 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import { forwardRef, useCallback, useContext, useImperativeHandle, useLayoutEffect } from 'react';
import { useTheme } from '@mui/material/styles';
import { ItemMetaContext, StableFormContext, StableGlobalContext } from '../lib/formsEngineContext';
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import Divider from '@mui/material/Divider';
import Container from '@mui/material/Container';
import Grid from '@mui/material/Grid';
import { useAtomValue, useStore as useJotaiStore } from 'jotai';
import { UIBlocker } from '../../UIBlocker';
import { getScrollContainer } from '../lib/formUtils';
import { stackFormCountAtom } from '../lib/formConsts';
import { getMarginSxProps } from '../../../utils/ui';
import { useResizeObserver } from '../../../hooks/useResizeObserver';
function collectSectionExpandedState(store, atomLookup) {
	return Object.entries(atomLookup).reduce((acc, [section, atom]) => {
		acc[section] = store.get(atom);
		return acc;
	}, {});
}
export const FormLayout = forwardRef(function (props, ref) {
	const {
		children,
		mainContentGrid,
		targetHeight,
		containerRef,
		mainContentRefCallback,
		headerFragment,
		hasStackedForms,
		stackIndex,
		style
	} = props;
	const theme = useTheme();
	const store = useJotaiStore();
	const { api: contextApi } = useContext(StableGlobalContext);
	const { state: stateCache, atoms } = useContext(StableFormContext);
	const { id } = useContext(ItemMetaContext);
	const isLargeContainerAtom = atoms.isLargeContainer;
	const isLargeContainer = useAtomValue(isLargeContainerAtom);
	useImperativeHandle(ref, () => containerRef.current);
	// Restore previous scroll position if provided.
	const collapsedToCAtom = atoms.collapseToC;
	const previousScrollTopPosition = stateCache?.previousScrollTopPosition;
	useLayoutEffect(() => {
		// Only a single stacked form is rendered at a time, so the scroll position of stacked forms is stored before opening a new one for later restoration here.
		if (containerRef.current != null && previousScrollTopPosition != null) {
			// Restore the previous scroll position
			const container = getScrollContainer(containerRef.current);
			container.scrollTop = previousScrollTopPosition;
		}
		// TODO: Once mounted back, clean the state cache. Assumes everything should have grabbed the cached values by now.
		//   contextApi.deleteStateCache(stackIndex);
		return () => {
			// Getting the count directly from the store provides the latest value. React may not have been updated `stackFormCount` yet.
			const currentCount = store.get(stackFormCountAtom);
			// If the count is greater than the stackIndex, a new form is being opened, so store the scroll position before dismounting.
			if (currentCount > stackIndex) {
				contextApi.setStateCache(stackIndex, {
					collapsedToC: store.get(collapsedToCAtom),
					previousScrollTopPosition: getScrollContainer(containerRef.current).scrollTop,
					sectionExpandedState: collectSectionExpandedState(store, atoms.expandedStateBySectionId)
				});
			}
		};
	}, [
		containerRef,
		previousScrollTopPosition,
		contextApi,
		stackIndex,
		store,
		collapsedToCAtom,
		atoms.expandedStateBySectionId
	]);
	// Freeze/manage scroll when stacked forms are open, and set the --scroll-top css property for stacked
	// forms to position themselves at the right position.
	useLayoutEffect(() => {
		if (hasStackedForms) {
			const root = containerRef.current;
			const scrollContainer = getScrollContainer(root);
			// Store the current scroll position to restore (content scrolls on formMainContent)
			const scrollTop = scrollContainer.scrollTop;
			const scrollLeft = scrollContainer.scrollLeft;
			// Freeze both: formMainContent is the content scroller; formContainer hosts the absolute drawer
			// and can still scroll (header + height:100% main) if left unlocked.
			scrollContainer.style.overflow = 'hidden';
			root.style.overflow = 'hidden';
			// Restore the scroll position
			scrollContainer.scrollTop = scrollTop;
			scrollContainer.scrollLeft = scrollLeft;
			// The drawer is absolutely positioned in formContainer, so it must be offset by formContainer's own scroll.
			root.style.setProperty('--scroll-top', `${root.scrollTop}px`);
			return () => {
				scrollContainer.style.overflow = '';
				root.style.overflow = '';
				root.style.removeProperty('--scroll-top');
			};
		}
	}, [containerRef, hasStackedForms]);
	const measureContainer = useCallback(() => {
		const container = containerRef.current;
		if (!container) return;
		const rect = container.getBoundingClientRect();
		const width = rect.width;
		container.style.setProperty('--container-width', `${width}px`);
		container.style.setProperty('--container-height', `${rect.height}px`);
		store.set(isLargeContainerAtom, width >= theme.breakpoints.values.lg);
	}, [containerRef, isLargeContainerAtom, store, theme.breakpoints.values.lg]);
	// The form may swap in a brand new set of atoms without remounting (e.g. reloading after saving an amend, or
	// after a rename). The resize observer won't fire for a container that hasn't changed size, so the new
	// `isLargeContainer` atom would keep its default and the table of contents would render collapsed.
	useLayoutEffect(() => {
		measureContainer();
	}, [measureContainer]);
	// Resize observer attached to the [scroll] container
	useResizeObserver(containerRef, measureContainer);
	return _jsxs(Box, {
		ref: containerRef,
		style: style,
		'data-model-id': id,
		'data-area-id': 'formContainer',
		sx: {
			display: 'flex',
			height: targetHeight,
			flexDirection: 'column',
			position: 'relative',
			overflow: 'auto',
			...getMarginSxProps()
		},
		children: [
			_jsx(UIBlockerOverlay, {}),
			_jsxs(Paper, {
				component: 'header',
				'data-area-id': 'formHeader',
				elevation: 0,
				square: true,
				children: [headerFragment, _jsx(Divider, {})]
			}),
			_jsx(Box, {
				ref: mainContentRefCallback,
				'data-area-id': 'formMainContent',
				sx: {
					// TODO: Tabs will be done at a later phase.
					// display: activeTab === 0 ? 'inherit' : 'none',
					position: 'relative',
					height: '100%',
					px: 0,
					pt: 2,
					backgroundColor: theme.palette.background.default,
					overflow: 'auto'
				},
				children: _jsx(Container, {
					maxWidth: isLargeContainer ? 'xl' : undefined,
					children: _jsx(Grid, { container: true, spacing: 2, children: mainContentGrid })
				})
			}),
			children
		]
	});
});
function UIBlockerOverlay() {
	const stableFormContext = useContext(StableFormContext);
	const isSubmitting = useAtomValue(stableFormContext.atoms.isSubmitting);
	return _jsx(UIBlocker, { open: isSubmitting });
}
export default FormLayout;
