/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { Fragment as _Fragment, jsx as _jsx, jsxs as _jsxs } from 'react/jsx-runtime';
import FormControl from '@mui/material/FormControl';
import Box from '@mui/material/Box';
import FieldStateIndicator, { useFieldStateIndicatorProps } from './FieldStateIndicator';
import Typography from '@mui/material/Typography';
import IconButton from '@mui/material/IconButton';
import MoreVertRounded from '@mui/icons-material/MoreVertRounded';
import Collapse from '@mui/material/Collapse';
import Alert, { alertClasses } from '@mui/material/Alert';
import FormHelperText from '@mui/material/FormHelperText';
import { forwardRef, useContext, useEffect, useId, useLayoutEffect, useMemo, useRef, useState } from 'react';
import { isEmptyValue } from '../lib/validators';
import { fieldDescribedById, fieldDescriptionId, fieldErrorId, FormValidationAnnouncerContext } from '../lib/fieldA11y';
import FormLabel from '@mui/material/FormLabel';
import { FormattedMessage, useIntl } from 'react-intl';
import { HelpOutlineRounded } from '@mui/icons-material';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import Divider from '@mui/material/Divider';
import ListItemText from '@mui/material/ListItemText';
import {
	useFormApiContext,
	useItemMetaContext,
	useStableFormContext,
	useStableGlobalApiContext
} from '../lib/formsEngineContext';
import { useAtomValue, useStore as useJotaiStore } from 'jotai';
import { isScopeActive, revealField } from '../lib/formVisibility';
import { changedFieldAtom, commitFormVisibility, getAdditionalFieldIds, useStackSubmitting } from '../lib/formUtils';
import { FieldValidityMessages, translateValidityMessage } from './FieldValidityMessages';
import { FieldDescribedByProvider } from './useControlAria';
import { XmlKeys } from '../lib/formConsts';
import { mergeSx } from '../lib/mergeSx';
import EditOutlined from '@mui/icons-material/EditOutlined';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import { useDispatch } from 'react-redux';
import useSelection from '../../../hooks/useSelection';
import { pushDialog } from '../../../state/actions/dialogStack';
import { createComponentId } from '../../../utils/system';
/** Whether `node` is the button or comes after it in document order. The portal menu renders at the end of the body. */
function isButtonOrFollows(button, node) {
	return !button || node === button || Boolean(button.compareDocumentPosition(node) & Node.DOCUMENT_POSITION_FOLLOWING);
}
/** The `length/max` counter shown next to a field label, or null when there is neither. */
function createLengthBlock({ length, max }) {
	const pieces = [];
	if (length != null) {
		pieces.push(`${length}`);
	}
	if (max != null) {
		pieces.push(`/${max}`);
	}
	return pieces.length
		? _jsx(Typography, { variant: 'body2', color: 'textSecondary', children: pieces.join(''), sx: { mr: 1 } })
		: null;
}
export const FormsEngineField = forwardRef(function (props, ref) {
	const {
		children,
		field,
		max,
		min,
		length,
		action,
		htmlFor,
		controlId: controlIdProp,
		labelId,
		autoFocus,
		menu = true,
		menuOptions,
		onMenuOptionClick,
		sx,
		className
	} = props;
	const { sourceMap } = useItemMetaContext();
	const stableForm = useStableFormContext();
	const { changedFieldIds, atoms } = stableForm;
	const jotai = useJotaiStore();
	const visibility = useAtomValue(atoms.formVisibility);
	const stackSubmitting = useStackSubmitting();
	const scopeActive = isScopeActive(visibility.active);
	const formApi = useFormApiContext();
	const globalApi = useStableGlobalApiContext();
	const { formatMessage } = useIntl();
	const fieldId = field.id;
	const sourcePath = fieldId !== XmlKeys['fileName'] ? sourceMap?.[fieldId] : undefined;
	// Subscribe to the one source item's label rather than the whole `itemsByPath` slice, so unrelated item updates
	// don't re-render every field.
	const sourceLabel = useSelection((state) => (sourcePath ? state.content.itemsByPath[sourcePath]?.label : undefined));
	const editSourceLabel = formatMessage({ defaultMessage: 'Edit {item}' }, { item: sourceLabel ?? sourcePath });
	const labelRef = useRef(null);
	const menuButtonRef = useRef(undefined);
	const [openMenu, setOpenMenu] = useState(false);
	const [showHelp, setShowHelp] = useState(false);
	const generatedId = useId();
	const menuId = `${generatedId}-options-menu`;
	// Whether focus is on the Options button or on something after it (the control, the options menu, which renders
	// in a portal but is a React child). Help and the field action come before the button, and focus on them must
	// not make the button a tab stop, or Tab from Help would land on it ahead of the control.
	const [hasFocusWithin, setHasFocusWithin] = useState(false);
	// A field whose control can't take focus (read-only, disabled, Uuid, Label) has no other way in, so its button stays tabbable.
	const [hasOtherTabStop, setHasOtherTabStop] = useState(true);
	useLayoutEffect(() => {
		const root = menuButtonRef.current?.closest('[data-field-id]');
		if (!root) return undefined;
		const recheckTabStops = () =>
			setHasOtherTabStop(
				Array.from(
					root.querySelectorAll(
						'a[href], button, input:not([type="hidden"]), select, textarea, iframe, [tabindex], [contenteditable="true"]'
					)
				).some((el) => {
					// MUI Collapse hides its closed content with `visibility: hidden`, which checkVisibility() only
					// reports with `visibilityProperty`. Where the method is missing, read the computed style.
					const visible =
						el.checkVisibility?.({ visibilityProperty: true }) ?? window.getComputedStyle(el).visibility !== 'hidden';
					return (
						el !== menuButtonRef.current &&
						isButtonOrFollows(menuButtonRef.current, el) &&
						el.tabIndex >= 0 &&
						!el.matches(':disabled') &&
						visible
					);
				})
			);
		const check = () => {
			recheckTabStops();
			// Removing the focused control fires no blur, so the flag would stay set with focus elsewhere.
			const active = document.activeElement;
			if (!active || !(root.contains(active) || document.getElementById(menuId)?.contains(active))) {
				setHasFocusWithin(false);
			}
		};
		check();
		const observer = new MutationObserver(check);
		observer.observe(root, {
			subtree: true,
			childList: true,
			attributes: true,
			attributeFilter: ['disabled', 'tabindex']
		});
		return () => observer.disconnect();
	}, [menu, showHelp, menuId]);
	const customControls = useSelection((state) => state.uiConfig?.controls);
	const additionalFieldIds = useMemo(() => getAdditionalFieldIds(field, customControls), [field, customControls]);
	const hasChanges = useAtomValue(changedFieldAtom(changedFieldIds, field.id, additionalFieldIds));
	const hasHelpText = Boolean(field.helpText);
	const hasDescription = Boolean(field.description);
	const lengthBlock = createLengthBlock({ length, max });
	// The label icon and the control border share this verdict, including a control's isValid override.
	const fieldState = useFieldStateIndicatorProps(field, atoms, { isValid: props.isValid });
	const { validityData, value } = fieldState;
	const isRequired = fieldState.props.isRequired;
	const isValid = fieldState.props.isValid;
	const indicatorProps = fieldState.props;
	const dispatch = useDispatch();
	const announceValidation = useContext(FormValidationAnnouncerContext);
	// The value atom is the edit signal. Select, the rich-text iframe, pickers and the node selector
	// change it without a bubbling input event. The flag is recorded after commit, before paint, so the
	// first blur after an edit still sees it. Controller setValue and rollback tag the write and are ignored.
	const editedRef = useRef(false);
	const committedValueRef = useRef(value);
	const systemWriteRef = useRef(false);
	const fieldUpdates$ = stableForm.fieldUpdates$;
	useLayoutEffect(() => {
		if (!fieldUpdates$) return undefined;
		const subscription = fieldUpdates$.subscribe((update) => {
			if (update.fieldId !== fieldId) return;
			// The latest write decides. A same-value controller setValue or rollback still emits, and the
			// value effect does not run, so leaving the flag true would swallow the author's next edit.
			systemWriteRef.current = Boolean(update.origin);
		});
		return () => subscription.unsubscribe();
	}, [fieldUpdates$, fieldId]);
	useLayoutEffect(() => {
		if (Object.is(committedValueRef.current, value)) return;
		committedValueRef.current = value;
		if (systemWriteRef.current) {
			systemWriteRef.current = false;
			return;
		}
		editedRef.current = true;
	}, [value]);
	// The label id is the group name. A control with no label id passes the id `useFieldControlA11y` uses.
	const describedByBase = fieldDescribedById(labelId, htmlFor || controlIdProp || generatedId);
	const menuButtonId = `${generatedId}-options-button`;
	const handleCloseMenu = () => setOpenMenu(false);
	const handleRollback = () => formApi.rollbackField(field.id);
	const isInMenu = (node) => Boolean(document.getElementById(menuId)?.contains(node));
	const handleFieldFocus = (event) =>
		setHasFocusWithin(isButtonOrFollows(menuButtonRef.current, event.target) || isInMenu(event.target));
	const handleFieldBlur = (event) => {
		const next = event.relatedTarget;
		// The menu renders in a portal, so a target inside it is not a DOM descendant but still counts as inside.
		const nextNode = next instanceof Node ? next : null;
		const inside = nextNode != null && (event.currentTarget.contains(nextNode) || isInMenu(nextNode));
		setHasFocusWithin(
			nextNode != null && inside && (isButtonOrFollows(menuButtonRef.current, nextNode) || isInMenu(nextNode))
		);
		if (inside) return;
		if (isValid || validityData.state !== 'hasData') return;
		const errorText = (validityData.data?.messages ?? [])
			.map((messageData) => translateValidityMessage(messageData, formatMessage))
			.join(' ');
		if (!errorText) return;
		// Blur announces only edited fields, to cut noise while tabbing.
		// Untouched invalid fields still expose their error on focus through aria-describedby, and a failed
		// Save still announces the full error count and summary, so nothing is lost.
		if (!editedRef.current) return;
		announceValidation(formatMessage({ defaultMessage: '{field}: {error}' }, { field: field.name, error: errorText }));
	};
	useEffect(() => {
		// Offer controls the option to focus on the label when the field is rendered.
		if (autoFocus) {
			labelRef.current?.focus();
		}
	}, [autoFocus]);
	const errorShown = !isValid && validityData.state === 'hasData';
	const helpId = hasHelpText && showHelp ? `${describedByBase}-help` : undefined;
	const descriptionId = hasDescription ? fieldDescriptionId(describedByBase) : undefined;
	const errorId = errorShown ? fieldErrorId(describedByBase) : undefined;
	const describedByIds = [helpId, descriptionId, errorId].filter((id) => Boolean(id));
	return _jsx(FormControl, {
		ref: ref,
		fullWidth: true,
		error: !isValid,
		variant: 'standard',
		'data-field-id': fieldId,
		required: isRequired,
		className: className,
		onFocus: handleFieldFocus,
		onBlur: handleFieldBlur,
		sx: mergeSx({ '.MuiFormLabel-asterisk': { display: 'none' } }, sx),
		children: _jsxs(FieldDescribedByProvider, {
			value: { labelId, describedByIds },
			children: [
				_jsxs(Box, {
					sx: {
						display: 'flex',
						justifyContent: 'space-between',
						alignItems: 'center'
					},
					children: [
						_jsxs(Box, {
							sx: {
								display: 'flex',
								alignItems: 'center'
							},
							children: [
								_jsx(FormLabel, {
									htmlFor: htmlFor,
									id: labelId,
									component: 'label',
									ref: labelRef,
									tabIndex: autoFocus ? 0 : undefined,
									children: field.name
								}),
								_jsx(FieldStateIndicator, { ...indicatorProps, announce: false }),
								hasHelpText &&
									_jsx(IconButton, {
										size: 'small',
										onClick: () => setShowHelp(!showHelp),
										'aria-expanded': showHelp,
										'aria-label': formatMessage({ defaultMessage: 'Help for {fieldName}' }, { fieldName: field.name }),
										children: _jsx(HelpOutlineRounded, { fontSize: 'small' })
									})
							]
						}),
						_jsxs(Box, {
							sx: {
								display: 'flex',
								alignItems: 'center'
							},
							children: [
								lengthBlock,
								action,
								menu &&
									_jsxs(_Fragment, {
										children: [
											_jsx(IconButton, {
												size: 'small',
												id: menuButtonId,
												tabIndex: hasFocusWithin || openMenu || !hasOtherTabStop ? 0 : -1,
												ref: menuButtonRef,
												onClick: () => setOpenMenu(true),
												'aria-label': formatMessage(
													{ defaultMessage: 'Options for {fieldName}' },
													{ fieldName: field.name }
												),
												'aria-haspopup': 'menu',
												'aria-expanded': openMenu,
												'aria-controls': openMenu ? menuId : undefined,
												children: _jsx(MoreVertRounded, { fontSize: 'small' })
											}),
											_jsxs(Menu, {
												open: openMenu,
												anchorEl: menuButtonRef.current,
												onClose: handleCloseMenu,
												onClick: handleCloseMenu,
												slotProps: { list: { id: menuId, 'aria-labelledby': menuButtonId } },
												children: [
													_jsx(MenuItem, {
														onClick: () => {
															dispatch(
																pushDialog({
																	component: createComponentId('FieldInformationDialog'),
																	props: { field }
																})
															);
														},
														children: _jsx(ListItemText, {
															children: _jsx(FormattedMessage, { defaultMessage: 'Field Information' })
														})
													}),
													scopeActive &&
														_jsx(MenuItem, {
															disabled: stackSubmitting,
															onClick: () => {
																if (stackSubmitting) return;
																const reveal = revealField(jotai.get(atoms.formVisibility), field.id);
																commitFormVisibility(jotai.set, atoms, reveal.state, reveal.fieldId);
																if (stableForm.itemFormMode) jotai.set(stableForm.itemFormMode, 'full');
															},
															children: _jsx(ListItemText, {
																children: _jsx(FormattedMessage, { defaultMessage: 'View in form' })
															})
														}),
													hasChanges && [
														_jsx(Divider, {}, 'rollback-divider'),
														_jsx(
															MenuItem,
															{
																onClick: handleRollback,
																children: _jsx(ListItemText, {
																	children: _jsx(FormattedMessage, { defaultMessage: 'Rollback changes' })
																})
															},
															'rollback-action'
														)
													],
													menuOptions && _jsx(Divider, {}),
													menuOptions?.map((option, index) =>
														option === 'divider'
															? _jsx(Divider, {}, `divider_${index}`)
															: _jsx(
																	MenuItem,
																	{
																		onClick: (e) => onMenuOptionClick?.(e, option.id, handleCloseMenu),
																		children: _jsx(ListItemText, { children: option.text })
																	},
																	option.id
																)
													)
												]
											})
										]
									})
							]
						})
					]
				}),
				hasHelpText &&
					_jsx(Collapse, {
						in: showHelp,
						children: _jsx(Alert, {
							role: 'note',
							severity: 'info',
							variant: 'outlined',
							sx: { border: 'none' },
							children: _jsx(Typography, {
								variant: 'body2',
								component: 'section',
								color: 'textSecondary',
								id: helpId,
								dangerouslySetInnerHTML: { __html: field.helpText },
								sx: { 'p:first-of-type:last-of-type': { margin: 0 } }
							})
						})
					}),
				sourcePath &&
					_jsx(Alert, {
						role: 'note',
						variant: 'standard',
						severity: 'info',
						icon: _jsx(IconButton, {
							href: 'https://craftercms.com/docs/current/by-role/developer/common/content-modeling/content-inheritance.html',
							size: 'small',
							color: 'inherit',
							target: '_blank',
							component: 'a',
							'aria-label': formatMessage({ defaultMessage: 'Learn more about content inheritance' }),
							title: formatMessage({ defaultMessage: 'Learn more about content inheritance' }),
							sx: { p: 0 },
							children: _jsx(InfoOutlinedIcon, {})
						}),
						action: _jsx(_Fragment, {
							children: _jsx(IconButton, {
								color: 'inherit',
								size: 'small',
								sx: { px: 0.5, minWidth: 0 },
								onClick: () => {
									globalApi.pushForm({
										update: { path: sourcePath }
									});
								},
								'aria-label': editSourceLabel,
								title: editSourceLabel,
								children: _jsx(EditOutlined, { fontSize: 'small' })
							})
						}),
						sx: {
							px: 1,
							mb: 0.625,
							borderRadius: 5,
							alignItems: 'center',
							[`.${alertClasses.message}`]: { display: 'flex', alignItems: 'center' },
							[`.${alertClasses.action}`]: { mr: 0 },
							[`.${alertClasses.icon}`]: { mr: 1 }
						},
						children: isEmptyValue(field, value)
							? _jsx(FormattedMessage, {
									defaultMessage: 'Value is inherited from {label}',
									values: { label: sourceLabel ?? sourcePath }
								})
							: _jsx(FormattedMessage, {
									defaultMessage: 'Inherited value from {label} is overridden',
									values: { label: sourceLabel ?? sourcePath }
								})
					}),
				children,
				hasDescription && _jsx(FormHelperText, { id: descriptionId, children: field.description }),
				errorShown &&
					_jsx(Box, { id: errorId, children: _jsx(FieldValidityMessages, { messages: validityData.data?.messages }) })
			]
		})
	});
});
export default FormsEngineField;
