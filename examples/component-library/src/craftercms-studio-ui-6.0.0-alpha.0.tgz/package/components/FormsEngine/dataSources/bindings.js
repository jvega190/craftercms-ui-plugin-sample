/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * Copyright (C) 2007-2026 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
/** A copy that nothing can change: the array, each binding and its `interfaces`. */
function freezeBindings(bindings) {
	return Object.freeze(
		bindings.map((binding) => Object.freeze({ ...binding, interfaces: Object.freeze([...binding.interfaces]) }))
	);
}
function freezeBindingTable(table) {
	return Object.freeze(
		Object.fromEntries(Object.entries(table).map(([type, bindings]) => [type, freezeBindings(bindings)]))
	);
}
/**
 * Built-in control → DS binding metadata. Plugin controls do not belong here;
 * they declare `dataSourceBindings` on `PluginDescriptor.controls[type]`
 * and/or register via {@link registerControlDataSourceBindings}.
 *
 * `selection` is field-value cardinality (one selected option vs many checked
 * options). It does not encode how many data sources TB may bind; that is a
 * separate descriptor-property concern (`datasource:item` vs
 * `datasource:item:singleSelection`).
 */
export const controlDataSourceBindings = freezeBindingTable({
	'node-selector': [{ propertyName: 'itemManager', interfaces: ['item'], selection: 'multi' }],
	'image-picker': [{ propertyName: 'imageManager', interfaces: ['image'], selection: 'single' }],
	'video-picker': [{ propertyName: 'videoManager', interfaces: ['video'], selection: 'single' }],
	'transcoded-video-picker': [{ propertyName: 'videoManager', interfaces: ['transcoded-video'], selection: 'single' }],
	dropdown: [{ propertyName: 'datasource', interfaces: ['item', 'options'], selection: 'single' }],
	'checkbox-group': [{ propertyName: 'datasource', interfaces: ['item', 'options'], selection: 'multi' }],
	rte: [
		{ propertyName: 'imageManager', interfaces: ['image'], selection: 'single' },
		{ propertyName: 'videoManager', interfaces: ['video', 'transcoded-video'], selection: 'single' },
		{ propertyName: 'audioManager', interfaces: ['audio'], selection: 'single' },
		{ propertyName: 'fileManager', interfaces: ['item'], selection: 'single' }
	]
});
/** Runtime registrations for plugin / dynamically discovered control types. */
const registeredControlDataSourceBindings = new Map();
// Controls without bindings are the common case. A shared instance keeps the identity stable so
// callers keying effects on the result don't re-run on every render.
const noBindings = Object.freeze([]);
/** Type guard for plugin/control binding contributions before registry install. */
export function isDataSourceBinding(value) {
	if (!value || typeof value !== 'object') return false;
	const candidate = value;
	return (
		typeof candidate.propertyName === 'string' &&
		candidate.propertyName.length > 0 &&
		Array.isArray(candidate.interfaces) &&
		candidate.interfaces.length > 0 &&
		candidate.interfaces.every((item) => typeof item === 'string' && item.length > 0) &&
		(candidate.selection === 'single' || candidate.selection === 'multi')
	);
}
/**
 * Validates and normalizes binding contributions from plugins or control modules.
 *
 * Accepts one binding or an array; `null` / `undefined` → `[]`. Rejects partial objects so a typo’d
 * binding does not silently become “no data sources”.
 */
export function normalizeDataSourceBindings(value) {
	if (value == null) return [];
	const candidates = Array.isArray(value) ? value : [value];
	const bindings = candidates.filter(isDataSourceBinding);
	if (bindings.length !== candidates.length) {
		throw new TypeError(
			'Control dataSourceBindings must be a DataSourceBinding or DataSourceBinding[] with propertyName, interfaces, and selection.'
		);
	}
	// Frozen copies, so the plugin's own objects can't change what the registry hands out.
	return freezeBindings(bindings);
}
/**
 * Reads binding metadata from a control plugin module.
 * Supported shapes:
 * - named export `dataSourceBindings` / `dataSourceBinding`
 * - static on the default component: `Component.dataSourceBindings`
 */
export function extractDataSourceBindingsFromControlModule(module) {
	const imported = module;
	const raw =
		imported.dataSourceBindings ??
		imported.dataSourceBinding ??
		imported.default?.dataSourceBindings ??
		imported.default?.dataSourceBinding;
	return normalizeDataSourceBindings(raw);
}
/**
 * Registers DS binding metadata for a control type (plugins / dynamic types).
 *
 * Built-ins live in {@link controlDataSourceBindings}; this map is for types not in that table.
 * `registerPlugin` already calls this from `controls[type].dataSourceBindings`.
 */
export function registerControlDataSourceBindings(controlType, bindings) {
	if (!controlType) {
		throw new TypeError('registerControlDataSourceBindings requires a non-empty control type.');
	}
	registeredControlDataSourceBindings.set(controlType, normalizeDataSourceBindings(bindings));
}
/**
 * Lookup order: built-in {@link controlDataSourceBindings} → runtime plugin registrations → shared
 * empty array. Built-ins always win so plugins cannot shadow OOB control bindings.
 * The empty result is a stable frozen `[]` so effect deps do not thrash.
 *
 * Binding metadata tells FE which field properties hold DS ids and which interfaces they require.
 */
export function getControlDataSourceBindings(controlType) {
	return (
		(Object.hasOwn(controlDataSourceBindings, controlType) ? controlDataSourceBindings[controlType] : undefined) ??
		registeredControlDataSourceBindings.get(controlType) ??
		noBindings
	);
}
/**
 * Parses comma-separated DS ids from `field.properties[binding.propertyName].value`.
 * Order is authoring order; empty or non-string → `[]`.
 */
export function getFieldDataSourceIds(field, binding) {
	const value = field.properties?.[binding.propertyName]?.value;
	if (typeof value !== 'string') return [];
	return value
		.split(',')
		.map((id) => id.trim())
		.filter(Boolean);
}
/**
 * Resolves records in the exact order authored on the field. Unknown ids are
 * returned as errors instead of being silently dropped.
 */
export function resolveFieldDataSourceRecords(contentType, field, bindings) {
	const records = [];
	const recordBindings = [];
	const errors = [];
	const byId = new Map((contentType.dataSources ?? []).map((dataSource) => [dataSource.id, dataSource]));
	bindings.forEach((binding) => {
		getFieldDataSourceIds(field, binding).forEach((id) => {
			const record = byId.get(id);
			if (!record) {
				errors.push({
					code: 'unknown-id',
					dataSourceId: id,
					message: `Field "${field.id}" references unknown data source "${id}" through "${binding.propertyName}".`
				});
				return;
			}
			records.push(record);
			recordBindings.push(binding);
		});
	});
	return { records, recordBindings, errors };
}
