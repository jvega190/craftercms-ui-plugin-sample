/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { Fragment as _Fragment, jsx as _jsx, jsxs as _jsxs } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import { lazy, Suspense, useEffect, useMemo, useState } from 'react';
import ResizeableDrawer from '../ResizeableDrawer/ResizeableDrawer';
import { SidebarFooterHtml } from '../ResizeableDrawer/SidebarFooterHtml';
import { sidebarFirstRowInset, sidebarFooterPadding } from '../ResizeableDrawer/sidebarSpacing';
import {
	createHashRouter,
	createRoutesFromElements,
	Navigate,
	Outlet,
	Route,
	RouterProvider,
	useLocation
} from 'react-router';
import SiteManagement from '../SiteManagement';
import { getLauncherSectionLink, messages as launcherMessages, urlMapping } from '../LauncherSection/utils';
import SkipToMainContent, { mainLandmarkSx, STUDIO_MAIN_CONTENT_ID } from '../SkipToMainContent';
import EmptyState from '../EmptyState/EmptyState';
import { FormattedMessage, useIntl } from 'react-intl';
import { useGlobalAppState } from './GlobalAppContext';
import CrafterCMSLogo from '../../icons/CrafterCMSLogo';
import LoadingState from '../LoadingState/LoadingState';
import LauncherOpenerButton from '../LauncherOpenerButton';
import { useGlobalNavigation } from '../../hooks/useGlobalNavigation';
import { useEnv } from '../../hooks/useEnv';
import GlobalAppToolbar from '../GlobalAppToolbar';
import Skeleton from '@mui/material/Skeleton';
import { globalMenuMessages } from '../../env/i18n-legacy';
import { GlobalRoutes } from '../../env/routes';
import { studioDocumentTitle } from '../../utils/studioDocumentTitle';
import SystemIcon from '../SystemIcon';
import ApiResponseErrorState from '../ApiResponseErrorState';
const routeWrapper = (module) => ({ ...module, Component: module.default });
// Site management loaded normally above as it is usually where people first land.
const UserManagement = lazy(() => import('../UserManagement/UserManagement'));
const GroupManagement = () => import('../GroupManagement/GroupManagement').then(routeWrapper);
const AuditManagement = () => import('../AuditManagement/AuditManagement').then(routeWrapper);
const LogLevelManagement = () => import('../LogLevelManagement/LogLevelManagement').then(routeWrapper);
const LogConsole = () => import('../LogConsole/LogConsole').then(routeWrapper);
const GlobalConfigManagement = () => import('../GlobalConfigManagement/GlobalConfigManagement').then(routeWrapper);
const EncryptTool = () => import('../EncryptTool/EncryptTool').then(routeWrapper);
const TokenManagement = () => import('../TokenManagement/TokenManagement').then(routeWrapper);
const AboutCrafterCMSView = () => import('../AboutCrafterCMSView/AboutCrafterCMSView').then(routeWrapper);
const AccountManagement = lazy(() => import('../AccountManagement/AccountManagement'));
export function GlobalApp(props) {
	const { passwordRequirementsMinComplexity } = props;
	const globalNavigation = useGlobalNavigation();
	if (!globalNavigation.items) {
		return _jsx(LoadingState, { sxs: { root: { height: '100%', margin: 0 } } });
	}
	const router = createHashRouter(
		createRoutesFromElements(
			_jsxs(Route, {
				path: '/',
				element: _jsx(GlobalAppInternal, { ...props }),
				children: [
					_jsx(Route, { path: GlobalRoutes.Projects, element: _jsx(SiteManagement, {}) }),
					_jsx(Route, { path: '/sites', element: _jsx(SiteManagement, {}) }),
					_jsx(Route, {
						path: GlobalRoutes.Users,
						element: _jsx(UserManagement, { passwordRequirementsMinComplexity: passwordRequirementsMinComplexity })
					}),
					_jsx(Route, { path: GlobalRoutes.Groups, lazy: GroupManagement }),
					_jsx(Route, { path: GlobalRoutes.Audit, lazy: AuditManagement }),
					_jsx(Route, { path: GlobalRoutes.LogLevel, lazy: LogLevelManagement }),
					_jsx(Route, { path: GlobalRoutes.LogConsole, lazy: LogConsole }),
					_jsx(Route, { path: GlobalRoutes.GlobalConfig, lazy: GlobalConfigManagement }),
					_jsx(Route, { path: GlobalRoutes.EncryptTool, lazy: EncryptTool }),
					_jsx(Route, { path: GlobalRoutes.TokenManagement, lazy: TokenManagement }),
					_jsx(Route, { path: GlobalRoutes.About, lazy: AboutCrafterCMSView }),
					_jsx(Route, {
						path: GlobalRoutes.Settings,
						element: _jsx(AccountManagement, { passwordRequirementsMinComplexity: passwordRequirementsMinComplexity })
					}),
					_jsx(Route, {
						path: '/',
						element: _jsx(Navigate, { to: `${urlMapping[globalNavigation.items[0].id].replace('#', '')}` })
					}),
					_jsx(Route, { path: '*', element: _jsx(RouteNotFound, {}) })
				]
			})
		)
	);
	return _jsx(RouterProvider, { router: router });
}
function RouteNotFound() {
	const { pathname } = useLocation();
	const { formatMessage } = useIntl();
	const pageNotFound = formatMessage({ id: 'globalApp.pageNotFound', defaultMessage: 'Page not found' });
	useEffect(() => {
		document.title = studioDocumentTitle(pageNotFound);
	}, [pageNotFound]);
	return _jsxs(Box, {
		sx: {
			display: 'flex',
			flexDirection: 'column',
			height: '100%'
		},
		children: [
			_jsx(Box, { component: 'section', sx: { margin: '10px 12px 0 auto' }, children: _jsx(LauncherOpenerButton, {}) }),
			_jsx(EmptyState, {
				sxs: {
					root: {
						height: '100%',
						margin: 0
					}
				},
				title: pageNotFound,
				titleComponent: 'h1',
				subtitle: _jsx(FormattedMessage, {
					id: 'globalApp.routeNotFound',
					defaultMessage: 'Route "{pathname}" not found',
					values: { pathname }
				})
			})
		]
	});
}
function globalNavItemSelected(itemId, pathname) {
	const hash = urlMapping[itemId];
	if (!hash) {
		return false;
	}
	const path = hash.replace(/^#/, '');
	// `/sites` remains as a backwards-compatible alias of Projects.
	return pathname === path || (pathname === '/sites' && path === GlobalRoutes.Projects);
}
function GlobalSidebarNav() {
	const { items, error } = useGlobalNavigation();
	const { authoringBase } = useEnv();
	const { pathname } = useLocation();
	const { formatMessage } = useIntl();
	if (error) {
		return _jsx(ApiResponseErrorState, { error: error.response ?? error });
	}
	return _jsxs(List, {
		disablePadding: true,
		// Matches where the first Project Tools row starts (header top inset + header margin, 26px by default).
		// On the list, not the drawer, so rows still span the sidebar edges and the selected bar stays flush.
		sx: { overflow: 'auto', flex: '1 1 auto', minHeight: 0, pt: sidebarFirstRowInset },
		children: [
			!items &&
				[0, 1, 2, 3].map((i) =>
					_jsx(
						ListItem,
						{ 'aria-hidden': 'true', sx: { px: 2 }, children: _jsx(Skeleton, { width: '100%', height: 36 }) },
						i
					)
				),
			items?.map((item) => {
				const selected = globalNavItemSelected(item.id, pathname);
				const label = globalMenuMessages[item.id] ? formatMessage(globalMenuMessages[item.id]) : item.id;
				return _jsx(
					ListItem,
					{
						disablePadding: true,
						children: _jsxs(ListItemButton, {
							component: 'a',
							href: getLauncherSectionLink(item.id, authoringBase),
							selected: selected,
							'aria-current': selected ? 'page' : undefined,
							children: [
								_jsx(ListItemIcon, {
									children: _jsx(SystemIcon, { icon: item.icon, svgIconProps: { fontSize: 'small', color: 'action' } })
								}),
								_jsx(ListItemText, { primary: label })
							]
						})
					},
					item.id
				);
			}),
			_jsx(ListItem, {
				disablePadding: true,
				children: _jsxs(ListItemButton, {
					component: 'a',
					href: 'https://craftercms.com/docs',
					target: '_blank',
					rel: 'noopener noreferrer',
					children: [
						_jsx(ListItemIcon, {
							children: _jsx(SystemIcon, {
								icon: { id: 'craftercms.icons.Docs' },
								svgIconProps: { fontSize: 'small', color: 'action' }
							})
						}),
						_jsx(ListItemText, { primary: formatMessage(launcherMessages.docs) })
					]
				})
			})
		]
	});
}
export function GlobalAppInternal(props) {
	const { footerHtml } = props;
	const [width, setWidth] = useState(240);
	const [{ openSidebar }] = useGlobalAppState();
	const { items } = useGlobalNavigation();
	const { formatMessage } = useIntl();
	const location = useLocation();
	const idByPathLookup = useMemo(
		() =>
			items?.reduce((lookup, item) => {
				lookup[getLauncherSectionLink(item.id, '').replace(/^#/, '')] = item.id;
				return lookup;
			}, {}),
		[items]
	);
	useEffect(() => {
		const path = location.pathname;
		// `/` redirects to the first launcher item. Don't flash a 404 title while that settles.
		if (path === '/') {
			return;
		}
		const id = path === '/sites' ? 'home.globalMenu.sites' : idByPathLookup?.[path];
		const descriptor = id ? globalMenuMessages[id] : undefined;
		if (descriptor) {
			document.title = studioDocumentTitle(formatMessage(descriptor));
		}
	}, [formatMessage, idByPathLookup, location.pathname]);
	return _jsxs(Paper, {
		sx: { height: '100vh', width: '100%' },
		elevation: 0,
		children: [
			_jsx(SkipToMainContent, {}),
			_jsxs(ResizeableDrawer, {
				landmark: 'nav',
				landmarkLabel: formatMessage(launcherMessages.global),
				sxs: {
					drawerPaper: {
						top: '0'
					},
					drawerBody: {
						height: '100%',
						display: 'flex',
						flexDirection: 'column',
						justifyContent: 'space-between',
						overflow: 'hidden'
					}
				},
				open: openSidebar,
				width: width,
				onWidthChange: setWidth,
				children: [
					_jsx(GlobalSidebarNav, {}),
					_jsxs(Box, {
						component: 'footer',
						sx: {
							padding: sidebarFooterPadding,
							textAlign: 'center',
							flexShrink: 0
						},
						children: [
							_jsx(CrafterCMSLogo, { width: 100, sxs: { root: { margin: '0 auto 10px auto' } } }),
							_jsx(SidebarFooterHtml, { html: footerHtml })
						]
					})
				]
			}),
			_jsx(Box, {
				component: 'main',
				id: STUDIO_MAIN_CONTENT_ID,
				tabIndex: -1,
				sx: [
					mainLandmarkSx,
					{
						height: '100%',
						width: 'auto',
						marginLeft: openSidebar ? `${width}px` : 0
					},
					(theme) => ({
						transition: theme.transitions.create('margin-left', {
							easing: theme.transitions.easing.easeOut,
							duration: theme.transitions.duration.enteringScreen
						})
					})
				],
				children: _jsx(Suspense, {
					fallback: _jsxs(_Fragment, {
						children: [
							_jsx(GlobalAppToolbar, { title: _jsx(Skeleton, { width: '140px' }) }),
							_jsx(Box, {
								sx: {
									display: 'flex',
									height: '100%'
								},
								children: _jsx(LoadingState, {})
							})
						]
					}),
					children: _jsx(Outlet, {})
				})
			})
		]
	});
}
export default GlobalApp;
