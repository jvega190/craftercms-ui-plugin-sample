/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { Fragment as _Fragment, jsx as _jsx, jsxs as _jsxs } from 'react/jsx-runtime';
import Tooltip from '@mui/material/Tooltip';
import { useIntl } from 'react-intl';
import IconButton from '@mui/material/IconButton';
import CropIcon from '@mui/icons-material/Crop';
import Divider from '@mui/material/Divider';
import RotateLeftIcon from '@mui/icons-material/RotateLeft';
import RotateRightIcon from '@mui/icons-material/RotateRight';
import SaturationIcon from '@mui/icons-material/WaterDrop';
import BrightnessIcon from '@mui/icons-material/Brightness7';
import ContrastIcon from '@mui/icons-material/Contrast';
import FlipIcon from '@mui/icons-material/Flip';
import Box from '@mui/material/Box';
const shouldRenderCrop = (tools) => tools && tools.includes('crop');
const shouldRenderAdjustments = (tools) => tools && tools.includes('adjustments');
const shouldRenderRotate = (tools) => tools && tools.includes('rotate');
const shouldRenderFlip = (tools) => tools && tools.includes('flip');
/** Toolbar of actions for the image editor. Contains crop, rotate, flip and adjustments (saturation, brightness,
 * contrast), and it renders only the actions configured in the `tools` prop */
export function ActionsBar(props) {
	const { tools, currentMode, setMode: setEditorMode, onRotate, onFlip } = props;
	const { formatMessage } = useIntl();
	// MUI's `Tooltip` only copies its `title` onto the button as an `aria-label` when the title
	// is a plain string so these need to stay `formatMessage` instead of `<FormattedMessage />`
	const cropLabel = formatMessage({ defaultMessage: 'Crop' });
	const rotateLeftLabel = formatMessage({ defaultMessage: 'Rotate left' });
	const rotateRightLabel = formatMessage({ defaultMessage: 'Rotate right' });
	const flipVerticalLabel = formatMessage({ defaultMessage: 'Flip vertical' });
	const flipHorizontalLabel = formatMessage({ defaultMessage: 'Flip horizontal' });
	const saturationLabel = formatMessage({ defaultMessage: 'Saturation' });
	const brightnessLabel = formatMessage({ defaultMessage: 'Brightness' });
	const contrastLabel = formatMessage({ defaultMessage: 'Contrast' });
	return _jsxs(Box, {
		sx: {
			backgroundColor: (theme) => theme.palette.background.paper,
			p: 1,
			display: 'flex',
			gap: 3,
			justifyContent: 'center'
		},
		children: [
			shouldRenderCrop(tools) &&
				_jsx(Tooltip, {
					title: cropLabel,
					children: _jsx(IconButton, {
						color: currentMode === 'crop' ? 'primary' : 'default',
						'aria-pressed': currentMode === 'crop',
						onClick: () => setEditorMode(currentMode !== 'crop' ? 'crop' : null),
						children: _jsx(CropIcon, {})
					})
				}),
			shouldRenderRotate(tools) &&
				_jsxs(_Fragment, {
					children: [
						shouldRenderCrop(tools) &&
							_jsx(Divider, { orientation: 'vertical', flexItem: true, sx: { height: 30, alignSelf: 'center' } }),
						_jsx(Tooltip, {
							title: rotateLeftLabel,
							children: _jsx(IconButton, { onClick: () => onRotate(-90), children: _jsx(RotateLeftIcon, {}) })
						}),
						_jsx(Tooltip, {
							title: rotateRightLabel,
							children: _jsx(IconButton, { onClick: () => onRotate(90), children: _jsx(RotateRightIcon, {}) })
						})
					]
				}),
			shouldRenderFlip(tools) &&
				_jsxs(_Fragment, {
					children: [
						_jsx(Tooltip, {
							title: flipHorizontalLabel,
							children: _jsx(IconButton, { onClick: () => onFlip(true, false), children: _jsx(FlipIcon, {}) })
						}),
						_jsx(Tooltip, {
							title: flipVerticalLabel,
							children: _jsx(IconButton, {
								onClick: () => onFlip(false, true),
								children: _jsx(FlipIcon, { sx: { transform: 'rotate(90deg)' } })
							})
						})
					]
				}),
			shouldRenderAdjustments(tools) &&
				_jsxs(_Fragment, {
					children: [
						(shouldRenderCrop(tools) || shouldRenderRotate(tools) || shouldRenderFlip(tools)) &&
							_jsx(Divider, { orientation: 'vertical', flexItem: true, sx: { height: 30, alignSelf: 'center' } }),
						_jsx(Tooltip, {
							title: saturationLabel,
							children: _jsx(IconButton, {
								color: currentMode === 'saturation' ? 'primary' : 'default',
								'aria-pressed': currentMode === 'saturation',
								onClick: () => setEditorMode(currentMode !== 'saturation' ? 'saturation' : null),
								children: _jsx(SaturationIcon, {})
							})
						}),
						_jsx(Tooltip, {
							title: brightnessLabel,
							children: _jsx(IconButton, {
								color: currentMode === 'brightness' ? 'primary' : 'default',
								'aria-pressed': currentMode === 'brightness',
								onClick: () => setEditorMode(currentMode !== 'brightness' ? 'brightness' : null),
								children: _jsx(BrightnessIcon, {})
							})
						}),
						_jsx(Tooltip, {
							title: contrastLabel,
							children: _jsx(IconButton, {
								color: currentMode === 'contrast' ? 'primary' : 'default',
								'aria-pressed': currentMode === 'contrast',
								onClick: () => setEditorMode(currentMode !== 'contrast' ? 'contrast' : null),
								children: _jsx(ContrastIcon, {})
							})
						})
					]
				})
		]
	});
}
export default ActionsBar;
