/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import { get, getGlobalHeaders, post, postJSON } from '../utils/ajax';
import { catchError, map, switchMap } from 'rxjs/operators';
import { of, from } from 'rxjs';
import { toQueryString } from '../utils/object';
import { XSRF_TOKEN_HEADER_NAME } from '../utils/constants';
/**
 * @deprecated Please note API deprecation for Crafter v4.0.0+
 **/
export function fetchSSOLogoutURL() {
	return get('/studio/api/2/users/me/logout/sso/url').pipe(map((response) => response?.response));
}
export function login(credentials) {
	// Regular post works fine, but fetch provides the redirect: 'manual' option which cancels the 302
	// that's useless for when doing the async style login.
	return from(
		fetch('/studio/login', {
			method: 'POST',
			cache: 'no-cache',
			credentials: 'include',
			headers: {
				'Content-Type': 'application/x-www-form-urlencoded',
				...getGlobalHeaders()
			},
			redirect: 'manual',
			body: toQueryString({ username: credentials.username, password: credentials.password }, { prefix: '' })
		})
	).pipe(
		// With Spring 6, the XSRF token cookie is only removed but not written on the login post,
		// so we need to do it "manually" after login by requesting a page that does write it.
		switchMap(() => from(fetch('/studio', { method: 'GET', cache: 'no-cache', credentials: 'include' }))),
		// We can't check if login failed when using redirect: 'manual'. So we call obtainAuthToken to verify the session.
		switchMap(() => obtainAuthToken()),
		map(() => true)
	);
}
export function sendPasswordRecovery(username) {
	return get(`/studio/api/2/users/forgot_password?username=${username}`).pipe(
		map((response) => response?.response?.response),
		catchError((error) => {
			throw error.response?.response ?? error;
		})
	);
}
export function setPassword(token, password, confirmation = password) {
	return password !== confirmation
		? of('Password and confirmation mismatch').pipe(
				map((msg) => {
					throw new Error(msg);
				})
			)
		: postJSON(`/studio/api/2/users/set_password`, {
				token,
				new: password
			}).pipe(
				map(({ response }) => {
					if (response.user == null) {
						throw new Error('Expired or incorrect token');
					}
					return response.user;
				})
			);
}
export function validatePasswordResetToken(token) {
	return get(`/studio/api/2/users/validate_token?token=${token}`).pipe(
		map(() => true),
		catchError((error) => {
			if (error.status === 401) return of(false);
			else throw new Error(error.response);
		})
	);
}
/**
 * Gets new tokens. `sessionExpiresAt` is the earliest time at which the session may expire (absent if there are no time
 * limits shorter than 20 hours) and `canExtendSession` tells if staying signed in would move it.
 **/
export function obtainAuthToken() {
	return get('/studio/refresh.json').pipe(map(toAuthTokenResponse));
}
/**
 * Gets new tokens and restarts the time limits of the session. Unlike the token refresh, this is a POST as it changes
 * state, so it requires the XSRF token.
 **/
export function extendSession(xsrfToken) {
	return post('/studio/refresh.json', null, { [XSRF_TOKEN_HEADER_NAME]: xsrfToken }).pipe(map(toAuthTokenResponse));
}
function toAuthTokenResponse(response) {
	const auth = response?.response;
	return {
		token: auth.token,
		expiresAt: new Date(auth.expiresAt).getTime(),
		sessionExpiresAt: auth.sessionExpiresAt ? new Date(auth.sessionExpiresAt).getTime() : null,
		canExtendSession: auth.canExtendSession
	};
}
export function fetchAuthenticationType() {
	return get('/studio/authType.json').pipe(map((response) => response?.response?.authType?.toLowerCase() ?? 'db'));
}
