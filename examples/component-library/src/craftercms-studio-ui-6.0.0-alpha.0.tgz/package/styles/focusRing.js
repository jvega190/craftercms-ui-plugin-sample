/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * Copyright (C) 2007-2026 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
export const focusRingColor = {
	light: '#0068DA',
	dark: '#54A6FF'
};
/** Outline width, in px. */
export const focusRingWidth = 2;
/** Gap between the control and the ring, in px. Inset rings use the negative value. */
export const focusRingOffset = 2;
export function getFocusRingColor(mode) {
	return focusRingColor[mode === 'dark' ? 'dark' : 'light'];
}
/**
 * The MUI v9 `focusVisible` theme value. MUI applies it to `.Mui-focusVisible` on every ButtonBase-based
 * component and insets it on the ones that clip (Tab, MenuItem, ListItemButton, CardActionArea).
 * There is no boxShadow, so MUI keeps its own halo on filled Alert, AppBar and Snackbar children.
 */
export function getFocusVisible(mode) {
	return {
		outlineStyle: 'solid',
		outlineColor: getFocusRingColor(mode),
		outlineWidth: focusRingWidth,
		outlineOffset: focusRingOffset
	};
}
/**
 * Spread into the options passed to createTheme(). CrafterThemeProvider is the only caller: the guest theme
 * does not use it, because a ring on every guest MUI control would sit on an unknown authored page. Guest
 * controls that need a ring call `focusRingStyles` directly with `halo`.
 */
export function getFocusRingThemeOptions(mode) {
	return { focusVisible: getFocusVisible(mode) };
}
/**
 * The ring as plain CSS, for elements that are not ButtonBase: the skip link, main, tree items, grid rows
 * and cells, native video, buttons and iframes. Put it under the element's own focus selector.
 */
export function focusRingStyles(theme, options = {}) {
	const { inset = false, halo = false, important = false, shadow } = options;
	const flag = important ? ' !important' : '';
	const shadows = [halo && !inset ? `0 0 0 ${focusRingOffset}px ${theme.palette.background.paper}` : null, shadow]
		.filter(Boolean)
		.join(', ');
	return {
		outline: `${focusRingWidth}px solid ${getFocusRingColor(theme.palette.mode)}${flag}`,
		outlineOffset: `${inset ? -focusRingOffset : focusRingOffset}px${flag}`,
		...(shadows && { boxShadow: `${shadows}${flag}` })
	};
}
/**
 * The same ring as an sx callback: `sx={{ '&:focus-visible': getFocusRingSx({ inset: true }) }}`.
 */
export function getFocusRingSx(options) {
	return (theme) => focusRingStyles(theme, options);
}
