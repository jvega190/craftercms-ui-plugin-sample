/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * Copyright (C) 2007-2026 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
/**
 * Fraction of the token lifetime at which it is refreshed.
 */
export const refreshAtFactor = 0.5;
/**
 * The server removes expired sessions once a minute, so they can outlive `sessionExpiresAt` by up to that long.
 */
export const sessionCleanupGraceMs = 61 * 1000;
/**
 * How long before the warning is due the session is checked, so the check has landed (and any activity extended the
 * session) before tabs decide whether to open the warning, which would otherwise open and close right away.
 */
export const sessionWarningCheckpointLeadMs = 5000;
/**
 * Delay before the next token refresh: the regular one, or sooner to check the session right before the warning is due
 * (so tabs warn based on up to date information, as the session may have been extended by activity) and right after it
 * should have expired.
 */
export function getNextRefreshDelay(current, refreshInterval, warningLeadTimeMs, now = Date.now()) {
	if (current.sessionExpiresAt) {
		const checkpoints = [
			current.sessionExpiresAt - warningLeadTimeMs - sessionWarningCheckpointLeadMs,
			current.sessionExpiresAt + sessionCleanupGraceMs
		].filter((checkpoint) => checkpoint > now);
		if (checkpoints.length) {
			return Math.min(refreshInterval, checkpoints[0] - now);
		}
	}
	return refreshInterval;
}
/**
 * Number of consecutive failed requests after which requests are not retried until one succeeds.
 */
export const maxRetries = 3;
/**
 * Serializes the requests for new tokens, so the warning checkpoint and an extension requested by the user don't
 * overlap. An extension requested while another request is in flight runs as soon as that one finishes, so a click on
 * "Stay signed in" is never dropped.
 */
export function createAuthTokenQueue(callbacks) {
	let isRetrieving = false;
	let isRetrievingExtend = false;
	let pendingExtendXsrfToken;
	// Consecutive failures, reset whenever a request succeeds or the session is gone
	let retries = 0;
	const toPromise = (request) =>
		request instanceof Promise
			? request
			: new Promise((resolve, reject) => request.subscribe({ next: resolve, error: reject }));
	const runPendingExtend = () => {
		const xsrfToken = pendingExtendXsrfToken;
		pendingExtendXsrfToken = undefined;
		if (xsrfToken) {
			retrieve(xsrfToken);
		}
	};
	const retrieve = (extendXsrfToken) => {
		if (isRetrieving) {
			if (extendXsrfToken) {
				if (isRetrievingExtend) {
					// Two extensions in a row would use two of the limited extensions, and the first one is enough
					callbacks.log('The session extension already in flight will extend the session');
					return;
				}
				callbacks.log('Request in flight, the session extension will run after it');
				pendingExtendXsrfToken = extendXsrfToken;
			}
			return;
		}
		isRetrieving = true;
		isRetrievingExtend = extendXsrfToken != null;
		toPromise(extendXsrfToken != null ? callbacks.extend(extendXsrfToken) : callbacks.obtain()).then(
			(token) => {
				isRetrieving = false;
				isRetrievingExtend = false;
				retries = 0;
				if (token) {
					// A failing callback must not look like a failed request, nor stop the queue
					try {
						callbacks.onToken(token);
					} catch (callbackError) {
						callbacks.log(`Token callback failed: ${callbackError}`);
					}
				} else {
					pendingExtendXsrfToken = undefined;
					callbacks.onUnauthenticated();
				}
				runPendingExtend();
			},
			// The rejection handler as the second argument (not a catch), so an exception thrown by the callbacks is
			// not treated as a failed request
			(error) => {
				isRetrieving = false;
				isRetrievingExtend = false;
				if (error?.status === 401) {
					// The session is gone, so there is nothing to extend
					retries = 0;
					pendingExtendXsrfToken = undefined;
					callbacks.onUnauthenticated();
				} else {
					retries++;
					callbacks.onError(error);
					runPendingExtend();
				}
			}
		);
	};
	return {
		retrieve,
		isRetrieving: () => isRetrieving,
		getPendingExtend: () => pendingExtendXsrfToken,
		clearPendingExtend: () => (pendingExtendXsrfToken = undefined),
		getRetries: () => retries,
		shouldRetry: () => retries < maxRetries
	};
}
