/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * Copyright (C) 2007-2026 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
/**
 * What the dialog did, from the close and minimize checkboxes. Close wins.
 * A save with neither checkbox reports `save` (the form stayed open).
 */
export function contentFormSaveAction(flags) {
	return flags.close ? 'saveAndClose' : flags.minimize ? 'saveAndMinimize' : 'save';
}
function selectedFieldList(value) {
	return value?.length ? [...value] : undefined;
}
/**
 * Edit and change-template follow-ups. The form already announces a draft, so that
 * save skips the success notification. The other work (refresh, caller callback) still runs.
 */
export function saveSuccessFollowUps(draft, notification, followUps) {
	return draft === true ? [...followUps] : [notification, ...followUps];
}
/**
 * Maps a content-form launch onto Forms Engine props. Field scope is applied by the
 * form's visibility model (`fieldIds` / `repeatIndex`); this function does not look
 * at the content type.
 */
export function formsEnginePropsFromLaunch(props) {
	const fieldIds = selectedFieldList(props.selectedFields);
	const targeting = {
		readonly: props.readonly ?? false,
		...(fieldIds ? { fieldIds } : {}),
		...(props.index !== undefined && props.index !== '' ? { repeatIndex: props.index } : {})
	};
	if (props.isNewContent) {
		return { ...targeting, create: { path: props.path, contentTypeId: props.contentTypeId ?? '' } };
	}
	if (props.isEmbedded || props.modelId) {
		return { ...targeting, update: { path: props.path, modelId: props.modelId } };
	}
	return { ...targeting, update: { path: props.path, changeTypeId: props.changeTemplate } };
}
