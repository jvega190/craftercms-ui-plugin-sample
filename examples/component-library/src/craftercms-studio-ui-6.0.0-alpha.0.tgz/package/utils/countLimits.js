/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * Copyright (C) 2007-2026 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
/** Virtual runtime keys. Type Builder 2 must not write these back into form-definition XML. */
export const virtualCountValidationIds = ['minCount', 'maxCount'];
const repeatMaxDefault = '*';
/**
 * The item-count storage contract.
 * Repeat: element wins over the same-named property. Save writes both, min as `int` (default `0`)
 * and max as `string` (default `*`). Node selector: `minSize` / `maxSize` properties only; a missing
 * property stays missing. Checkbox group: `minSize` constraint, no maximum; the editor shows
 * `minCount` (blank when unset, including a stored 0) and save writes the constraint only for a
 * positive integer.
 */
export const countLimitStorage = {
	repeat: {
		type: 'repeat',
		stripConstraints: ['required'],
		min: {
			kind: 'min',
			name: 'minOccurs',
			sources: ['element', 'property'],
			propertyType: 'int',
			ensureProperty: true
		},
		max: {
			kind: 'max',
			name: 'maxOccurs',
			sources: ['element', 'property'],
			propertyType: 'string',
			ensureProperty: true
		}
	},
	'node-selector': {
		type: 'node-selector',
		stripConstraints: [],
		min: { kind: 'min', name: 'minSize', sources: ['property'] },
		max: { kind: 'max', name: 'maxSize', sources: ['property'] }
	},
	'checkbox-group': {
		type: 'checkbox-group',
		stripConstraints: [],
		min: {
			kind: 'min',
			name: 'minSize',
			sources: ['constraint'],
			editorFromVirtual: true,
			editorUnset: '',
			writeConstraintWhenPositive: true,
			constraintType: 'int'
		}
	}
};
/** The storage entry for a control type, or undefined when that control has no item-count limits. */
export function getCountLimitStorage(fieldType) {
	// Own keys only. `constructor` and `toString` are on the prototype, not controls.
	if (!fieldType || !Object.hasOwn(countLimitStorage, fieldType)) return undefined;
	return countLimitStorage[fieldType];
}
/** Constraint names the validations loop must not copy onto the content field (checkbox `minSize`). */
export function countLimitValidationKeys(storage) {
	if (!storage) return [];
	return [storage.min, storage.max].flatMap((bound) => (bound?.sources.includes('constraint') ? [bound.name] : []));
}
/** True when save must rebuild virtual minCount/maxCount from the editor field. */
export function storageRefreshesVirtualCount(storage) {
	if (!storage) return false;
	return [storage.min, storage.max].some(
		(bound) => bound != null && (bound.editorFromVirtual || bound.sources.includes('constraint'))
	);
}
function readBoundSource(bound, source) {
	if (!bound) return {};
	let element;
	let fallback;
	let sawFallback = false;
	for (const slot of bound.sources) {
		if (slot === 'element') {
			element = source.element(bound.name);
			continue;
		}
		// One fallback slot. The first non-element source in `sources` is that slot.
		if (!sawFallback) {
			fallback = slot === 'property' ? source.property(bound.name) : source.constraint(bound.name);
			sawFallback = true;
		}
	}
	return { element, fallback };
}
/** Parse one control's stored bounds into runtime limits. No entry means the field is unchanged. */
export function countLimitsFromLegacy(storage, source, context) {
	const min = readBoundSource(storage.min, source);
	const max = readBoundSource(storage.max, source);
	return countLimitsFromStorage(
		{
			minElement: min.element,
			minProperty: min.fallback,
			maxElement: max.element,
			maxProperty: max.fallback
		},
		context
	);
}
/** Properties to rewrite after parse so the Type Builder form shows the element-winning value. */
export function countLimitPropertyWrites(storage, limits) {
	const writes = [];
	for (const bound of [storage.min, storage.max]) {
		if (!bound?.sources.includes('property')) continue;
		writes.push({
			name: bound.name,
			kind: bound.kind,
			limit: bound.kind === 'min' ? limits.minCount : limits.maxCount,
			ensure: Boolean(bound.ensureProperty),
			type: bound.propertyType
		});
	}
	return writes;
}
/** Editor fields filled from virtual minCount/maxCount. Empty when the property copy is enough. */
export function countLimitEditorOverrides(storage, validations) {
	if (!storage) return {};
	const values = {};
	for (const bound of [storage.min, storage.max]) {
		if (!bound?.editorFromVirtual) continue;
		const raw = bound.kind === 'min' ? validations?.minCount?.value : validations?.maxCount?.value;
		const limit = countLimitValue(raw);
		values[bound.name] = limit == null ? (bound.editorUnset ?? '') : limit;
	}
	return values;
}
/** Runtime limits from editor fields that are not stored as properties (checkbox `minSize`). */
export function countLimitsFromEditorValues(storage, values) {
	const minIsVirtual =
		storage.min != null && (storage.min.editorFromVirtual || storage.min.sources.includes('constraint'));
	const maxIsVirtual =
		storage.max != null && (storage.max.editorFromVirtual || storage.max.sources.includes('constraint'));
	return countLimitsFromStorage({
		minProperty: minIsVirtual ? values[storage.min.name] : undefined,
		maxProperty: maxIsVirtual ? values[storage.max.name] : undefined
	});
}
/**
 * XML for one control's limits. Element and property values are the TB1 strings, including the
 * defaults when the editor value is blank. A constraint is included only for a positive integer.
 */
export function writeCountLimitXml(storage, field) {
	const elements = {};
	const properties = {};
	const constraints = [];
	for (const bound of [storage.min, storage.max]) {
		if (!bound) continue;
		if (bound.sources.includes('element') || (bound.sources.includes('property') && bound.propertyType)) {
			const raw = field.properties?.[bound.name]?.value;
			const parsed = countLimitsFromStorage(bound.kind === 'min' ? { minElement: raw } : { maxElement: raw });
			const limit = bound.kind === 'min' ? parsed.minCount : parsed.maxCount;
			const text = String(itemCountEditorValue(limit, bound.kind, bound.propertyType ?? 'string'));
			if (bound.sources.includes('element')) elements[bound.name] = text;
			if (bound.propertyType) properties[bound.name] = { name: bound.name, type: bound.propertyType, value: text };
		}
		if (bound.writeConstraintWhenPositive) {
			const raw = bound.kind === 'min' ? field.validations?.minCount?.value : field.validations?.maxCount?.value;
			const minimum = countLimitValue(raw);
			if (minimum != null) constraints.push({ name: bound.name, value: minimum, type: bound.constraintType ?? 'int' });
		}
	}
	return { elements, properties, stripConstraints: storage.stripConstraints, constraints };
}
function countLimits(minCount, maxCount) {
	return {
		...(minCount != null ? { minCount } : {}),
		...(maxCount != null ? { maxCount } : {})
	};
}
/**
 * Storage → runtime limits. The same rules for every control.
 * Pass `context` so an unusable value with no fallback logs a warning.
 */
export function countLimitsFromStorage(storage, context) {
	const min = resolveStoredBound(storage.minElement, storage.minProperty, false);
	const max = resolveStoredBound(storage.maxElement, storage.maxProperty, true);
	if (context) {
		if (min.unusable) warnUnusableCountLimit('min', context);
		if (max.unusable) warnUnusableCountLimit('max', context);
	}
	return countLimits(min.limit, max.limit);
}
/** The role and partner declared on an `itemCount` validation, or undefined when the value is not that spec. */
export function readItemCountEditorSpec(value) {
	if (!value || typeof value !== 'object') return undefined;
	const role = value.role;
	if (role !== 'min' && role !== 'max') return undefined;
	const partner = value.partner;
	return typeof partner === 'string' && partner !== '' ? { role, partner } : { role };
}
/** Type Builder minimum. Blank and 0 mean no minimum. Any other value must be a non-negative integer. */
export function isItemCountMinEditorValue(value) {
	if (isBlankCount(value)) return true;
	return readOccursNumber(value) != null;
}
/**
 * Type Builder maximum. Blank and `*` mean no maximum. A stored 0 is unlimited, but the
 * editor must not accept 0: the value has to be an integer of 1 or more.
 */
export function isItemCountMaxEditorValue(value) {
	if (isBlankCount(value) || isUnlimitedStar(value)) return true;
	const parsed = readOccursNumber(value);
	return parsed != null && parsed >= 1;
}
/** True when either side is unset, or the minimum is not greater than the maximum. */
export function isItemCountRangeValid(min, max) {
	const minLimit = countLimitValue(min);
	const maxLimit = countLimitValue(max);
	if (minLimit == null || maxLimit == null) return true;
	return minLimit <= maxLimit;
}
/**
 * Value Type Builder shows for one bound. Every control uses this.
 * An unset limit, including a stored 0, is the unlimited token: `0` for a minimum,
 * blank for an int maximum, and `*` for any other maximum. A positive limit is kept.
 */
export function itemCountEditorValue(limit, kind, storedType) {
	if (kind === 'min') return limit ?? 0;
	if (storedType === 'int') return limit == null ? '' : limit;
	return limit == null ? repeatMaxDefault : String(limit);
}
/**
 * Values the repeat editor shows. No minimum is `0`. No maximum is `*`.
 * Save writes these (stringified) as both the element and the property.
 */
export function repeatLimitEditorValues(limits) {
	return {
		minOccurs: itemCountEditorValue(limits.minCount, 'min', 'int'),
		maxOccurs: itemCountEditorValue(limits.maxCount, 'max', 'string')
	};
}
/** TB1 storage strings for a repeat, including the defaults when the editor value is blank. */
export function repeatOccursXmlValues(min, max) {
	const editor = repeatLimitEditorValues(countLimitsFromStorage({ minElement: min, maxElement: max }));
	return { minOccurs: String(editor.minOccurs), maxOccurs: editor.maxOccurs };
}
/**
 * Virtual `minCount` / `maxCount` value, for every control.
 * Null, undefined, blank, `*` and 0 are unlimited. A positive integer is a limit.
 * Do not test the result with truthiness: unlimited is `undefined`, never `0`.
 */
export function countLimitValue(value) {
	const parsed = readOccursNumber(value);
	if (parsed == null || parsed === 0) return undefined;
	return parsed;
}
/** @see countLimitValue */
export function readNumericLimit(value) {
	return countLimitValue(value);
}
/**
 * Add is allowed while the count is below the max, including when the repeat is empty.
 * A missing max ("unlimited") never disables Add. Readonly always does.
 */
export function isRepeatAddDisabled(readonly, count, maxCount) {
	if (readonly) return true;
	const max = readNumericLimit(maxCount);
	return max != null && count >= max;
}
/** Minimum a repeat enforces. No stored minimum (blank or 0) is 0. Required is not a minimum. */
export function getRepeatMinimum(minCount) {
	return readNumericLimit(minCount) ?? 0;
}
/**
 * Delete is disabled when the count is at or below {@link getRepeatMinimum}.
 * Readonly always disables removal.
 */
export function isRepeatRemoveDisabled(readonly, count, minCount) {
	if (readonly) return true;
	return count <= getRepeatMinimum(minCount);
}
/**
 * Count may equal the min or the max. Only a count outside that range is invalid.
 * A missing max does not apply an upper bound. A minimum or maximum of 0 is unlimited.
 */
export function getRepeatOccurrenceViolations(count, minCount, maxCount) {
	const violations = [];
	const min = readNumericLimit(minCount);
	const max = readNumericLimit(maxCount);
	if (min != null && count < min) violations.push({ kind: 'min', limit: min });
	if (max != null && count > max) violations.push({ kind: 'max', limit: max });
	return violations;
}
/**
 * What an occurrence violation means for a field's marker, when both limits report at level `required`
 * (see assignCountLimits): a missing minimum is the required prompt, a reached maximum is not. `min` wins
 * when both are present, so a range that is somehow short and full still reads as required. The Experience
 * Builder zone marker uses this because the level alone cannot tell the two apart.
 */
export function occurrenceViolationKind(violations) {
	const ids = violations.map(({ id }) => id);
	if (ids.includes('minCount')) return 'required';
	if (ids.includes('maxCount')) return 'maxCount';
	return null;
}
/** Element wins when usable. Blank and invalid fall back to the property. 0 and `*` (max) are unlimited. */
function resolveStoredBound(element, property, allowStar) {
	const top = classifyCountToken(element, allowStar);
	if (top === 'limit') return { limit: readOccursNumber(element), unusable: false };
	if (top === 'unlimited') return { unusable: false };
	const fallback = classifyCountToken(property, allowStar);
	if (fallback === 'limit') return { limit: readOccursNumber(property), unusable: false };
	if (fallback === 'unlimited') return { unusable: false };
	return { unusable: top === 'invalid' || fallback === 'invalid' };
}
function classifyCountToken(value, allowStar) {
	if (isBlankCount(value)) return 'missing';
	if (allowStar && isUnlimitedStar(value)) return 'unlimited';
	const parsed = readOccursNumber(value);
	if (parsed == null) return 'invalid';
	if (parsed === 0) return 'unlimited';
	return 'limit';
}
function isBlankCount(value) {
	if (value == null) return true;
	return typeof value === 'string' && value.trim() === '';
}
function isUnlimitedStar(value) {
	return typeof value === 'string' && value.trim() === '*';
}
function warnUnusableCountLimit(bound, context) {
	const contentTypeId = context.contentTypeId || 'unknown';
	const fieldId = context.fieldId || 'unknown';
	console.warn(
		`[parseLegacyFormDef] Unusable ${bound} item-count on content type "${contentTypeId}" field "${fieldId}". The limit was left unset.`
	);
}
/** A non-negative integer, or null. 0 is included so callers can decide whether it means unlimited. */
function readOccursNumber(value) {
	if (typeof value === 'number') {
		return Number.isInteger(value) && value >= 0 ? value : null;
	}
	if (typeof value !== 'string') return null;
	const text = value.trim();
	return /^\d+$/.test(text) ? Number.parseInt(text, 10) : null;
}
